## 2 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 9V45 96-Core Processor (4) | 144.66 | 57.17 | 87.11 | 1832/1832 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 7763 64-Core Processor (4) | 251.47 | 92.90 | 132.99 | 1832/1832 |
| after | 43736250019/1/132879382569 (exit-1) | 8a18672992559a9088d2527a71de265522e7f84f | 9ba119ba96fa4544cea8889a2c809e9d01e65a84 | AMD EPYC 9V74 80-Core Processor (4) | 175.11 | 56.47 | 109.47 | 1831/1832 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 110.05 | 87.11–132.99 | 45.88 |
| after | 109.47 | 109.47–109.47 | 0.00 |

Difference, after − before: -0.58 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -0.52 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 24414.5 | 0.0 | 6603.0 | 24253.0 | 0.0 | 5676.0 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 240.5 | 0.0 | 5.0 | 247.0 | 0.0 | 5.2 |
| onepipeline::commandstep::run | wait | 13.0 | 163.0 | 8.3 | 13.0 | 139.0 | 8.0 |
| onepipeline::dispatchenv::run | wait | 81.0 | 313.0 | 12.3 | 82.0 | 270.0 | 10.1 |
| onepipeline::driver::attach | sleep | 168609.0 | 0.0 | 9003.1 | 147985.0 | 0.0 | 7975.5 |
| onepipeline::driver::confirm_driving | sleep | 1346.5 | 0.0 | 70.0 | 1298.0 | 0.0 | 67.3 |
| onepipeline::driver::submit_offered | sleep | 5267.5 | 0.0 | 273.3 | 5010.0 | 0.0 | 262.2 |
| onepipeline::hooks::run | wait | 65.0 | 834.0 | 39.7 | 65.0 | 751.0 | 38.2 |
| onepipeline::planedit::run | wait | 30.0 | 620.0 | 12.4 | 30.0 | 501.0 | 14.9 |
| onepipeline::sys::gone_within | sleep | 54.5 | 0.0 | 1.1 | 49.0 | 0.0 | 0.1 |
| onepipeline::vcs::follow | sleep | 232763.0 | 0.0 | 5559.8 | 208483.0 | 0.0 | 5025.3 |
| onevcs::git::PipeCapture::start | sleep | 0.0 | 0.0 | 0.0 | 1381519.0 | 0.0 | 19949.4 |
| onevcs::git::PipeRead::await_readable | sleep | 2081824.5 | 0.0 | 24334.2 | 0.0 | 0.0 | 0.0 |
| onevcs::git::bounded | wait | 383607.5 | 1649484.5 | 18341.0 | 378744.0 | 1516335.0 | 15885.4 |
| onevcs::pool::maintain::run | wait | 19.0 | 1613.5 | 24.8 | 19.0 | 1601.0 | 24.8 |
| onevcs::probe::read | wait | 379.0 | 1000.0 | 13.1 | 377.0 | 870.0 | 9.7 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 15.5 | 18.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 34.5 | 36.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 4.0 | 4.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 9.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |

### Tests

1832 e2e tests passed in a before run.
- before inventory-1: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after exit-1: 1831 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed and not passed again: none.
