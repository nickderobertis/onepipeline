## 3 before run(s) against 2 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| before | 43736273251/1/132879453312 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 7763 64-Core Processor (4) | 176.69 | 131.14 | 41.73 | 2155/2155 |
| after | 43736257614/1/132879405862 (adaptive-1) | f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7 | 7c1a2c4daae604222efab39cf976a6b9258b3f8c | AMD EPYC 9V45 96-Core Processor (4) | 117.44 | 76.13 | 39.23 | 2155/2155 |
| after | 43758902628/1/132949007160 (adaptive-2) | 1c9812957a60e44e4357116128eeb69723c3acce | 45363fbb55df1fda289eeca78bb9de14624652c5 | Intel(R) Xeon(R) 6975P-C (4) | 116.47 | 76.77 | 37.72 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 40.23 | 37.92–41.73 | 3.81 |
| after | 38.48 | 37.72–39.23 | 1.51 |

Difference, after − before: -1.76 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -1.58 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25243.0 | 0.0 | 2273.8 | 25070.5 | 0.0 | 2231.2 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1727.3 | 0.0 | 34.7 | 1742.5 | 0.0 | 35.0 |
| onepipeline::commandstep::run | wait | 18.0 | 214.0 | 9.9 | 18.0 | 212.0 | 9.8 |
| onepipeline::dispatchenv::run | wait | 97.0 | 313.0 | 11.1 | 97.0 | 311.0 | 11.0 |
| onepipeline::driver::attach | sleep | 38535.3 | 0.0 | 1931.0 | 71337.0 | 0.0 | 1805.8 |
| onepipeline::driver::confirm_driving | sleep | 1439.7 | 0.0 | 72.2 | 4490.0 | 0.0 | 31.6 |
| onepipeline::driver::submit_offered | sleep | 4237.0 | 0.0 | 212.2 | 6353.0 | 0.0 | 204.1 |
| onepipeline::hooks::run | wait | 111.7 | 832.3 | 36.2 | 111.5 | 831.0 | 36.1 |
| onepipeline::planedit::run | wait | 32.0 | 461.3 | 8.7 | 32.0 | 462.0 | 8.7 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.3 | 6.9 | 78.0 | 213.5 | 6.9 |
| onepipeline::sys::gone_within | sleep | 2684.0 | 0.0 | 53.9 | 2660.0 | 0.0 | 53.4 |
| onepipeline::vcs::follow | sleep | 48495.7 | 0.0 | 975.2 | 47952.5 | 0.0 | 951.9 |
| onevcs::git::bounded | wait | 365183.0 | 879835.0 | 1339.3 | 364588.0 | 860789.0 | 1135.7 |
| onevcs::pool::maintain::run | wait | 35.0 | 2463.7 | 24.2 | 32.0 | 2447.5 | 24.1 |
| onevcs::probe::read | wait | 350.3 | 747.0 | 0.7 | 351.0 | 769.0 | 0.9 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after adaptive-1: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after adaptive-2: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
