## 2 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| after | 43736273251/1/132879453312 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 7763 64-Core Processor (4) | 176.69 | 131.14 | 41.73 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 39.49 | 37.92–41.06 | 3.14 |
| after | 41.73 | 41.73–41.73 | 0.00 |

Difference, after − before: 2.24 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 2.02 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25264.5 | 0.0 | 2228.0 | 25200.0 | 0.0 | 2365.3 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1729.0 | 0.0 | 34.7 | 1724.0 | 0.0 | 34.6 |
| onepipeline::commandstep::run | wait | 18.0 | 213.5 | 9.9 | 18.0 | 215.0 | 10.0 |
| onepipeline::dispatchenv::run | wait | 97.0 | 311.0 | 10.9 | 97.0 | 317.0 | 11.4 |
| onepipeline::driver::attach | sleep | 37015.5 | 0.0 | 1854.5 | 41575.0 | 0.0 | 2084.0 |
| onepipeline::driver::confirm_driving | sleep | 1436.0 | 0.0 | 72.0 | 1447.0 | 0.0 | 72.6 |
| onepipeline::driver::submit_offered | sleep | 4243.0 | 0.0 | 212.5 | 4225.0 | 0.0 | 211.7 |
| onepipeline::hooks::run | wait | 111.5 | 831.5 | 36.1 | 112.0 | 834.0 | 36.3 |
| onepipeline::planedit::run | wait | 32.0 | 461.0 | 8.6 | 32.0 | 462.0 | 8.7 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.0 | 6.9 | 78.0 | 215.0 | 7.0 |
| onepipeline::sys::gone_within | sleep | 2692.0 | 0.0 | 54.0 | 2668.0 | 0.0 | 53.6 |
| onepipeline::vcs::follow | sleep | 45581.0 | 0.0 | 916.1 | 54325.0 | 0.0 | 1093.4 |
| onevcs::git::bounded | wait | 364937.5 | 871189.5 | 1249.7 | 365674.0 | 897126.0 | 1518.6 |
| onevcs::pool::maintain::run | wait | 35.0 | 2458.5 | 24.2 | 35.0 | 2474.0 | 24.4 |
| onevcs::probe::read | wait | 353.0 | 738.5 | 0.6 | 345.0 | 764.0 | 1.0 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after base-1: 2154 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
