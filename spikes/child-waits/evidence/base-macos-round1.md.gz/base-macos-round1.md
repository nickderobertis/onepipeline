## 2 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 201.81 | 92.98 | 90.11 | 2121/2121 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 198.48 | 85.46 | 94.38 | 2121/2121 |
| after | 43736273251/1/132879453345 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | Apple M1 (Virtual) (3) | 156.54 | 55.82 | 82.26 | 2121/2121 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 92.24 | 90.11–94.38 | 4.26 |
| after | 82.26 | 82.26–82.26 | 0.00 |

Difference, after − before: -9.98 min — decided: non-overlapping ranges and mean difference outside both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -8.98 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25382.5 | 0.0 | 5679.6 | 25494.0 | 0.0 | 5176.3 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 378.0 | 0.0 | 37.1 | 350.0 | 0.0 | 36.7 |
| onepipeline::commandstep::run | wait | 18.0 | 107.5 | 12.0 | 18.0 | 105.0 | 11.7 |
| onepipeline::dispatchenv::run | wait | 97.0 | 689.0 | 76.4 | 97.0 | 611.0 | 67.4 |
| onepipeline::driver::attach | sleep | 28624.5 | 0.0 | 3790.2 | 25902.0 | 0.0 | 3462.7 |
| onepipeline::driver::confirm_driving | sleep | 1410.0 | 0.0 | 185.1 | 1377.0 | 0.0 | 179.6 |
| onepipeline::driver::submit_offered | sleep | 2167.0 | 0.0 | 277.7 | 2068.0 | 0.0 | 269.9 |
| onepipeline::hooks::run | wait | 112.0 | 471.5 | 46.0 | 112.0 | 476.0 | 44.9 |
| onepipeline::planedit::run | wait | 32.0 | 149.0 | 11.4 | 32.0 | 141.0 | 11.0 |
| onepipeline::stopguard::consult | wait | 78.0 | 177.5 | 13.3 | 78.0 | 176.0 | 13.0 |
| onepipeline::sys::gone_within | sleep | 912.0 | 0.0 | 87.7 | 922.0 | 0.0 | 90.9 |
| onepipeline::vcs::follow | sleep | 24738.5 | 0.0 | 2585.1 | 20926.0 | 0.0 | 2205.0 |
| onevcs::git::bounded | wait | 375517.0 | 775344.5 | 4498.2 | 370540.0 | 757686.0 | 3525.6 |
| onevcs::pool::maintain::run | wait | 35.0 | 615.5 | 26.5 | 34.0 | 569.0 | 25.9 |
| onevcs::probe::read | wait | 360.0 | 727.5 | 6.0 | 358.0 | 716.0 | 2.8 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.5 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2121 e2e tests passed in a before run.
- before inventory-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after base-1: 2121 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
