## 3 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 9V45 96-Core Processor (4) | 144.66 | 57.17 | 87.11 | 1832/1832 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 7763 64-Core Processor (4) | 251.47 | 92.90 | 132.99 | 1832/1832 |
| before | 43736273251/1/132879453337 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 9V74 80-Core Processor (4) | 171.91 | 68.60 | 102.62 | 1830/1832 |
| after | 43736257614/1/132879405490 (adaptive-1) | f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7 | 7c1a2c4daae604222efab39cf976a6b9258b3f8c | INTEL(R) XEON(R) PLATINUM 8573C (4) | 215.60 | 67.90 | 137.71 | 1831/1832 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 107.58 | 87.11–132.99 | 45.88 |
| after | 137.71 | 137.71–137.71 | 0.00 |

Difference, after − before: 30.14 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 27.12 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 24391.7 | 0.0 | 6370.5 | 24351.0 | 0.0 | 7512.2 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 241.3 | 0.0 | 5.0 | 240.0 | 0.0 | 5.1 |
| onepipeline::commandstep::run | wait | 13.0 | 160.0 | 8.2 | 13.0 | 164.0 | 8.6 |
| onepipeline::dispatchenv::run | wait | 81.3 | 309.3 | 12.1 | 81.0 | 343.0 | 13.9 |
| onepipeline::driver::attach | sleep | 165102.7 | 0.0 | 8781.3 | 239799.0 | 0.0 | 10534.7 |
| onepipeline::driver::confirm_driving | sleep | 1333.0 | 0.0 | 69.2 | 4914.0 | 0.0 | 56.0 |
| onepipeline::driver::submit_offered | sleep | 5189.7 | 0.0 | 268.2 | 7517.0 | 0.0 | 282.6 |
| onepipeline::hooks::run | wait | 65.0 | 837.3 | 39.9 | 65.0 | 862.0 | 41.8 |
| onepipeline::planedit::run | wait | 30.0 | 611.0 | 12.2 | 30.0 | 646.0 | 13.1 |
| onepipeline::sys::gone_within | sleep | 55.0 | 0.0 | 1.2 | 55.0 | 0.0 | 1.2 |
| onepipeline::vcs::follow | sleep | 231658.7 | 0.0 | 5469.4 | 206679.0 | 0.0 | 6599.1 |
| onevcs::git::PipeRead::await_readable | sleep | 2025139.3 | 0.0 | 23516.9 | 2599066.0 | 0.0 | 30450.8 |
| onevcs::git::bounded | wait | 382513.3 | 1604084.0 | 17574.7 | 387311.0 | 1946434.0 | 22901.4 |
| onevcs::pool::maintain::run | wait | 19.0 | 1614.7 | 24.8 | 18.0 | 1610.0 | 24.9 |
| onevcs::probe::read | wait | 379.0 | 966.7 | 12.2 | 364.0 | 998.0 | 14.6 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 14.3 | 22.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 34.3 | 36.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 4.0 | 4.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |

### Tests

1832 e2e tests passed in a before run.
- before inventory-1: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 1830 passed in the tier; failed in the tier, passed on the job's re-run: boundary::an_unusable_attempt_budget_falls_back_rather_than_disabling_the_recovery, store::a_project_larger_than_one_page_is_read_to_its_end; failed and not passed again: none.
- after adaptive-1: 1831 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed and not passed again: none.
