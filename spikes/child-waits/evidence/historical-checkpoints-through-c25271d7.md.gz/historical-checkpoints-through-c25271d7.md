## Current handoff — only R2/macOS remains

E/A complete. R has two Linux/Windows points, both undecided; R1/macOS is complete and R2/macOS remains in flight. Own open PR only#1641/run43775937612. R1#1615 fully read/closed. No combination indicated by the completed E/A comparisons. Exactly two after points per platform, no third; producer remains frozen4ee92293. Next collection no earlier than03:11UTC. Earlier handoffs below are historical.

## Current handoff — Linux complete for every option; only three R points remain

R/Linux now has exactly two after points, mean40.57versus40.23minutes, undecided. All E/A/R Linux comparisons are complete and undecided. E/A are complete on every platform without any decided attributable saving, so no combination is indicated. Remaining data: R1/macOS and R2/Windows/macOS, all last seen running. Own open PRs only #1615/run43736265323 and #1641/run43775937612. Base,E1,A1,E2,A2 are fully read and closed. Exactly2after/platform, no third; producer frozen4ee92293. Next collection no earlier than02:34UTC. Earlier pending-R/Linux summaries are historical.

## Current handoff — E and A complete; only R data remains

E and A each have exactly two after points on every platform. E/Linux and Windows are undecided; E/macOS is not comparable for attribution. A is undecided on every platform, with mixed Mac hardware. Neither option has a decided attributable saving, so the “more than one saves” condition for a combination is not met; R alone cannot trigger that condition. No combination is planned from this record’s evidence.

A2#1636 is fully read/closed, its local demonstration branch deleted. Only R1#1615/run43736265323 and R2#1641/run43775937612 remain open. R1/macOS and R2’s three platform points remain to collect; latest snapshot has all of them running. Base,E1,A1,E2,A2 are fully read and closed. Producer frozen4ee92293, exactly2after/platform, no third. Next collection no earlier than02:17UTC. Earlier open-A2 and pending-A comparisons are historical.

## Current handoff — E complete, no attributable decided E saving

E has exactly two after points on every platform. Linux38.62versus40.23minutes is undecided; Windows123.83versus107.58 is undecided; macOS60.57versus88.92 has an arithmetic difference but both M2/5-core after points are not comparable to M1/3-core before points for attribution (a66). E therefore supplies no decided attributable saving for a combination. E2#1637 is fully read/closed and its local demonstration branch deleted.

A/Linux and Windows have two points, both undecided; A2/macOS remains running. R1/macOS remains running; R2/Linux and Windows run while macOS is queued. Own open PRs now #1615/run43736265323,#1636/run43758902628,#1641/run43775937612. Remaining platform points: A2/macOS, R1/macOS and R2’s three platforms. No third run is authorized; producer remains frozen4ee92293. Next collection no earlier than01:58UTC. All earlier open-E2 handoffs are historical.

## Current handoff — read pause ended, evidence published

At00:53UTC Nov16 the allowance recovered to4,984core/4,893GraphQL. Pending evidence was published through7da20a80; session tree is clean. Latest collection0053 produced no new completed point; A2/macOS has started. Remaining data: E2/Windows; A2/macOS; R1/macOS; R2/Linux,Windows,macOS. Own open PRs/ids remain #1615/43736265323,#1636/43758902628,#1637/43765240430,#1641/43775937612. Closed and fully read: base#1616,E1#1613,A1#1614. Current two-point comparisons: E/Linux undecided; E/macOS not comparable for attribution (both M2/5versus M1/3before); A/Linux and Windows undecided. No combination is justified. Exactly2after/platform, no third; producer remains frozen4ee92293. Continue15minute collection, next no earlier than01:09UTC. Earlier pause/pending-publication notes are historical and superseded by this handoff.

## Current handoff — read pause a80; E/Linux two points complete

E/Linux now has two after points38.62versus40.23minutes, undecided. E/macOS’s two points remain not comparable for attribution. A/Linux and Windows have two points, both undecided. Remaining platform data: E2/Windows, A2/macOS, R1/macOS and R2/Linux/Windows/macOS. Own open PRs/ids: #1615/43736265323,#1636/43758902628,#1637/43765240430,#1641/43775937612. R2’s executed SHA is now confirmed by its cancelled lint log; its two judged failures are inherited main-diff findings outside this spike’s changes, recorded below. No producer or enforcement edit is made.

Primary core allowance fell to2,496; a80 keeps this worker’s working floor2,500, allowed one specific R2lint-log read, then requires holding until00:52:49UTC reset. New evidence is committed locally and the authoring report rendered; remote publication waits for that reset. Exactly2after/platform, no third; producer remains frozen4ee92293. Earlier next-poll notes are superseded by this read pause.

## Current handoff — E/macOS has two points, both not comparable for attribution

E/macOS now has exactly two after points, mean60.57versus88.92minutes. Both after points are M2Pro/5cores versus M1/3-core baselines, so a66 requires no attributable saving claim despite the arithmetic verdict. A/Linux and Windows also have two points and remain undecided. Remaining data: E2/Linux and Windows; A2/macOS queued; R1/macOS running; R2’s three platforms (Linux/Windows running, macOS queued). Own open PRs remain #1615/run43736265323,#1636/run43758902628,#1637/run43765240430,#1641/run43775937612. Exactly2after/platform, producer frozen4ee92293, no third. Next collection no earlier than00:12UTC Nov16. Earlier summaries are historical where superseded.

## Current handoff — all second-round demonstrations opened

At23:37UTC the shared plan inventory dropped to six open -demo- PRs (#1628 had closed). Under a71 the prepared R2 was pushed and opened as [#1641](https://github.com/nickderobertis/onepipeline/pull/1641), run **43775937612**, head **e156f19aa0d669eee79490ce7c49096b45ffcef2**. Its initial merge candidate **bd062baf4539baa3ac21165b20fb0580cd25df72**, captured before changing the session base, has parents39498db2e1db78c3ad6a8cc2ddbc024cb369fc98 and the head. Executed GITHUB_SHA awaits a completed log. Candidate workflow/Cargo/no-op src blobs are the identical db2bbe081a7b9319eb38bd014e72350b389e8b01 / d95eed3341f21cfccf8e0fc309d3904325998617 / 563b327b22f01e50c02c8743ef5dc6cfdd9894ec, verified by git fetch/rev-parse. Local R slice/count fold and prepared diff/format checks passed before this start; producer remains frozen4ee92293. No push will touch R2 while its run is active.

Own open demonstrations now: R1#1615/run43736265323(macOS has started), A2#1636/run43758902628(macOS queued; Linux/Windows collected), E2#1637/run43765240430(platforms running), R2#1641/run43775937612(initially queued). E1/A1/base are fully read and closed. All required individual second-round demonstrations are now started; no third runs are prepared or authorized. A/Linux and Windows each have two points, both undecided. E1/macOS is hardware-confounded under a66. Remaining data: E2’s three platform points, A2/macOS, R1/macOS and R2’s three platform points; then assess whether more than one option has a decided attributable saving before any combination. Next collection no earlier than23:55UTC. Earlier blocked-R2 handoffs are historical.

## Current handoff — A/Linux and Windows have two points; R2 still held

A now has exactly two after points on Linux and Windows. Linux38.48 versus40.23minutes and Windows116.45 versus107.58 both remain undecided; Windows’s second point is below the overall before mean, so a61’s conditional likely-slower label is not triggered. A2/macOS remains queued. E2’s three platform jobs are running; R1/macOS remains queued. At23:21UTC the observed shared plan count remained seven, so R2 is still local/unpushed under a71. Own open PRs remain #1615/run43736265323, #1636/run43758902628, #1637/run43765240430. Next status/capacity check no earlier than23:37UTC. Producer frozen4ee92293, exactly2after/platform, no third. Earlier summaries are historical where superseded by the two-point results.

## Current handoff — A/Linux has two points; cap still full

A/Linux now has its required two after points, mean38.48minutes against three-before40.23; difference remains undecided. Other platform repetitions remain pending. At22:49UTC the plan count was still seven, so R2 remains local/unpushed under a71. Own open PRs: R1#1615/run43736265323 (macOS queued), A2#1636/run43758902628 (Linux collected, Windows running, macOS queued), E2#1637/run43765240430 (platform jobs running). E1/A1/base are fully read and closed. Exactly2after/platform, producer frozen4ee92293, no third run. Next status/capacity check no earlier than23:05UTC. Earlier round-one summary rows are historical where superseded by this two-point Linux result.

## Current handoff — A1 closed; R2 blocked by shared cap (a71)

A1 #1614 is fully read/closed. Own open PRs are R1#1615/run43736265323, A2#1636/run43758902628, E2#1637/run43765240430. R2 remains locally prepared at e156f19aa0d669eee79490ce7c49096b45ffcef2, not pushed/opened. The capacity check after A1 closed found seven plan -demo- heads still open: #1637,#1636,#1635(engine2),#1634/#1633(git1),#1628(engine1),#1615. The guard refused an eighth; manager a71 says wait, recheck every15minutes and open R2 immediately once under7. No sibling evidence or PR was changed. Next combined status/capacity check will be no earlier than22:33UTC. All prepared producer code remains frozen4ee92293; exactly2after/platform, no third.

## Round-one comparison collected so far

All before means below use inventory43684231509 attempts1/2 plus disabled-base43736273251. Each after cell is only **one** hosted point; the second point is still required under a61. Values are read from the quoted three-before fold outputs below, with each row linking the after job. The typical-PR column is the observed after-minus-before difference scaled by0.9; it is provisional arithmetic, not an attributable saving or cost forecast. No option currently justifies a combination.

| Option/platform, after job | Before mean min | After min | After-minus-before min | Typical-PR delta min | Interpretation |
|---|---:|---:|---:|---:|---|
| [E/linux 132879382741](https://github.com/nickderobertis/onepipeline/actions/runs/43736250019/job/132879382741) | 40.23 | 39.93 | -0.30 | -0.27 | Undecided inside a side’s spread |
| [E/windows 132879382569](https://github.com/nickderobertis/onepipeline/actions/runs/43736250019/job/132879382569) | 107.58 | 109.47 | 1.90 | 1.71 | Undecided inside a side’s spread |
| [E/macos 132879382738](https://github.com/nickderobertis/onepipeline/actions/runs/43736250019/job/132879382738) | 88.92 | 59.61 | -29.31 | -26.38 | Arithmetic decided; hardware not comparable for attribution (a66) |
| [A/linux 132879405862](https://github.com/nickderobertis/onepipeline/actions/runs/43736257614/job/132879405862) | 40.23 | 39.23 | -1.00 | -0.90 | Undecided inside a side’s spread |
| [A/windows 132879405490](https://github.com/nickderobertis/onepipeline/actions/runs/43736257614/job/132879405490) | 107.58 | 137.71 | 30.14 | 27.12 | Undecided inside a side’s spread |
| [A/macos 132879405816](https://github.com/nickderobertis/onepipeline/actions/runs/43736257614/job/132879405816) | 88.92 | 94.21 | 5.30 | 4.77 | Undecided inside a side’s spread |
| [R/linux 132879430099](https://github.com/nickderobertis/onepipeline/actions/runs/43736265323/job/132879430099) | 40.23 | 37.42 | -2.81 | -2.53 | Undecided inside a side’s spread |
| [R/windows 132879429855](https://github.com/nickderobertis/onepipeline/actions/runs/43736265323/job/132879429855) | 107.58 | 146.59 | 39.02 | 35.11 | Undecided inside a side’s spread |

R/macOS job132879430106 remains pending; no figure is invented. E/macOS is M2Pro/5cores versus all M1/3-core before points; A/macOS matches M1/3cores. Every row’s named test proof and any own-rerun recovery appear in the detailed evidence sections. Source of this table: printed fold output files listed in the row construction, read on ff55e535; no new timing measurement was performed.

## Current handoff — E1 closed, E2 opened

E1 #1613 is fully read and closed. E2 [#1637](https://github.com/nickderobertis/onepipeline/pull/1637), run **43765240430**, is opened on prepared head **76e124ef58e4d67fef8db8657478eae38fffedbb**. Initial candidate **82b1540c1a151fbdb249216b6e5c38be9b5b0fa4** was fetched before a newer session push, with parents233371f09adec1b6bbe0cdc2fd6fb872d1760992 and the head; executed GITHUB_SHA awaits a completed log. The frozen producer is unchanged; common workflow/dependency/src blobs remain the same. No future push will touch E2 while running.

Current open own demonstrations: A1 #1614/run43736257614 (macOS pending), R1 #1615/run43736265323 (macOS queued), A2 #1636/run43758902628 (platform jobs pending), E2 #1637/run43765240430. R2 remains local/unpushed until the next a63 slot. Exactly two after runs/platform, no third. E1/macOS’s large numerical difference is hardware-confounded under a66 and not an attributable saving. All currently collected named tests passed in main or their listed own reruns. Next status collection no earlier than21:55UTC. Earlier handoffs are historical.

## A2 executed identity confirmed — lint job evidence

[Run 43758902628, lint job 132949007120](https://github.com/nickderobertis/onepipeline/actions/runs/43758902628/job/132949007120) completed 2026-11-15 21:11:35 UTC. Its checkout fetch confirms full GITHUB_SHA **1c9812957a60e44e4357116128eeb69723c3acce**, head 45363fbb55df1fda289eeca78bb9de14624652c5, base dff249e77452e6e6de367f712f8a80cbfac6f537; the previously captured candidate is now verified as executed. Workflow blob db2bbe081a7b9319eb38bd014e72350b389e8b01. Full 54-task lint selection is archived. Nx stored zero entries/bytes, replayed zero; no Actions-cache save entry. Platform cache audits remain pending until those jobs finish.

This hosted run’s judged tier, at 21:11:21.4994403Z, reports `40 rules: 26 passed, 0 failed, 8 skipped, 6 not relevant`, history 20261115T211121Z-54388. It judged against origin/main 41416e1475b68354723305b7a9ca7471596f7718. This is additional green judged evidence on demonstration head 45363fbb, not a claim that the earlier bounded local reader findings disappeared. Those three limitations remain documented under a46. The only failing job step was `Lint the PR title`: the deliberately required `DO NOT MERGE:` title is not a Conventional Commit. No title/enforcement change is made; this demonstration never merges. Formatting/affected deterministic lint and the hosted judged step succeeded.

Source: log fetched once after the 21:24 UTC status collection, parsed by `jobFacts` on dab49d5b; full log and facts are archived as adaptive-2-lint.log.gz / adaptive-2-lint-facts.json.gz. Each cache/setup action span is listed below (not transfer-only time). No platform completion was newly collected at 21:24 UTC; next status poll no earlier than 21:39 UTC. Earlier pending-identity notes are historical and superseded by this confirmation.

| Step | Restore observation | Action seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.005 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 62.932 |
| actions/cache/restore@v4 | miss | 0.358 |
| actions/setup-node@v4 | no restore | 1.035 |
| actions/setup-python@v5 | miss | 20.318 |
| astral-sh/setup-uv@v6 | no restore | 3.574 |

## Current handoff — 2026-11-15 20:56 UTC

E/A/R round-one Linux and Windows points are now collected and folded. Every current difference remains undecided; no saving or combination is approved by the evidence. All baseline names passed in main tiers or their listed own reruns, with the documented overwritten Linux profile reconciliation. Still pending: E/macOS and A/macOS running, R/macOS queued; A2 run **43758902628**, PR #1636, Linux/Windows running and macOS queued. Three round-one PRs remain open; base #1616 is fully read/closed. A2 head 45363fbb55df1fda289eeca78bb9de14624652c5; its original merge candidate, captured before any newer session push, is 1c9812957a60e44e4357116128eeb69723c3acce with parents dff249e77452e6e6de367f712f8a80cbfac6f537 and the head. Executed checkout GITHUB_SHA awaits a completed job log, so it is not yet asserted. Candidate workflow/Cargo/src blobs equal the round-one blobs, verified by git fetch and rev-parse after reset.

Exactly two after runs/platform under a61; producer frozen at 4ee92293. A2 was authorized against a63’s reported free slot; E2/R2 await released slots. Read allowance recovered at 20:52 UTC to 4,981 core / 4,538 GraphQL. Per a64, next status collection no earlier than 21:08 UTC; fetch completed logs/artifacts once. Earlier handoffs are historical.

## Current handoff — A2 opened under a64

[Draft demonstration #1636](https://github.com/nickderobertis/onepipeline/pull/1636) is open for adaptive round two, head 45363fbb55df1fda289eeca78bb9de14624652c5, from session parent dff249e7. It is the remaining A repeat, not a third run. Local real-binary slice/count fold passed before it. Workflow, Cargo and no-op src blobs are byte-identical to round one: db2bbe081a7b9319eb38bd014e72350b389e8b01 / d95eed3341f21cfccf8e0fc309d3904325998617 / 563b327b22f01e50c02c8743ef5dc6cfdd9894ec. Producer bytes remain frozen at 4ee92293; only the demonstration selector is `adaptive`. `git diff --check` and `cargo fmt --all -- --check` passed before committing demonstration 45363fbb. No push will touch that branch during its hosted run.

Manager a64 explicitly authorized creation despite the read pause, then requires **no further hosted reads until the 20:52 UTC reset**, followed by status polling no more often than every fifteen minutes and fetching each finished job’s log/artifact once. Accordingly the new run id/GITHUB_SHA have not been read yet; they will be recorded after reset. This is an identified evidence gap under the read pause, not an invented identity. E/A/R round-one PRs #1613–#1615 remain open; base #1616 is read/closed. A2 was authorized for the reported free slot under a63; that statement was the manager’s inventory, not an independently measured cap total. E2 and R2 await released slots. Session worktree is clean, with demonstration local branch retained only until its eventual close. Earlier handoffs are historical.

## Round-two preparation — a63 and local trace, 2026-11-15 20:34 UTC

Manager a63 supersedes a0 with a cap of seven demonstration PRs across this plan’s three spikes, counting heads under `nick/process-launch-speed-2026-11-14/` containing `-demo-`; session drafts do not count. It authorizes the currently free slot for A’s decisive second Windows point, then further round-two demonstrations as round-one PRs are read and closed. This supersedes the earlier side-by-side round start rule. The held-release timeout is a known load-sensitive journey that passed on its own rerun; no unsupported root cause is inferred.

Before opening A2, on a5abb07a (producer bytes unchanged from 4ee92293), the real binary slice passed: `ONEPIPELINE_SPIKE_CHILD_WAITS=adaptive ONEPIPELINE_TEST_PROFILE_DIR=$ONEPIPELINE_NODE_SCRATCH_DIR/round2-local-adaptive ONEPIPELINE_LAUNCH_TRACE=$ONEPIPELINE_NODE_SCRATCH_DIR/round2-local-adaptive/launch RUSTFLAGS="-D warnings" just test-e2e "test(=views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice)"`. Nextest run 8de26198-b803-4b08-aa47-1e5015375349: one test passed. The recorded profiles/traces were folded locally with the branch’s exported `readJob` / `foldJob`; the count-only output (round2-local-adaptive-counts.json.gz) records five CLI launches and real adaptive wait events. Local elapsed times are not used for comparison.

At the post-slice allowance check core was 2,439 (<2,500 reserve), GraphQL 2,330, so job/artifact/PR reads paused until reset (20:52:22 UTC) or a manager ruling on demonstration creation’s preliminary reads. A2 will be prepared locally without pushing an in-flight branch; the manager was asked over c-773c8a71bee630e534c6a958451a72d5. No new hosted run is claimed yet.

## Current binding plan update — a61, received 2026-11-15 20:29 UTC

Manager ruling a61 relays the user’s decision: **exactly two hosted after runs per platform for every option and the combination, with no third run anywhere**, against the inventory’s two baseline points plus comparable #1616. This supersedes all earlier three-after-run requirements and historical remaining-work notes in this report. Keep producer 4ee92293 frozen and collect the remaining repeat; no investigation-driven repair from one point inside the spread. If the second A/Windows point is also adverse, report A as likely slower on Windows with attribution unestablished, include the wait/count evidence, and exclude A from the combination. This dispatch follows a61; it does not alter code to chase the first point.

Current evidence: one Linux after point each for E/A/R, one Windows after point each for E/A, none yet collected for macOS. Four jobs remain pending. E/A/R demonstrations remain open; base #1616 is closed. No second round has started. All current differences remain undecided. Earlier handoffs below are historical and superseded on repetition count by a61.

## Current handoff — 2026-11-15 20:20 UTC

A/Windows is now collected. E/A/R Linux and E/A Windows each have one after point. All differences remain undecided; A/Windows is an adverse first point requiring the manager’s repair-versus-freeze decision, with wait counts and recovery evidence preserved below. Four platform jobs remain pending: E/macOS, A/macOS and R/Windows running, R/macOS queued. Base #1616 is fully read/closed and included as the third before point. E/A/R PRs remain open; no new round started. Required after repetitions remain incomplete. Producer frozen at 4ee92293, reader 327d8551 unchanged. Earlier handoffs are historical.

## Current handoff — 2026-11-15 20:03 UTC

Base #1616 is fully read and closed (branch deleted), with its comparable point added to the before side. E/A/R #1613/#1614/#1615 remain open; last read has E/macOS queued, A/Windows and A/macOS running, R/Windows running and R/macOS queued. No later rounds opened. E/A/R Linux and E/Windows are collected; all differences remain undecided even with the extra base point. Producer remains frozen at 4ee92293. Required repetitions remain incomplete. Earlier handoffs below are historical.

## Current handoff — 2026-11-15 19:58 UTC

The rate allowance recovered at 19:52 UTC (4,970 core / 4,455 GraphQL); collection resumed. E/Windows is collected and folded, while the three completed base jobs are still downloading/auditing. E/A/R Linux remain the only other collected platform points. All four demonstrations remain open; no later round has started. E/Windows had one main-tier timeout that passed the job’s own rerun, documented below. No saving is established; required repetitions remain incomplete. Producer 4ee92293 is frozen, reader source 327d8551 has 23 passing command tests and three bounded judged-reader limitations retained under a46. Earlier handoffs below are historical.

## Current handoff — 2026-11-15 19:34 UTC

Evidence is committed and published through 80aacfd4. Round-1 E/A/R Linux jobs are collected: e2e means for their single after points are 39.93027 / 39.23223 / 37.42190 minutes, versus the approved two-point Linux before mean 39.48736 minutes. Every difference remains undecided within the before spread; these are not established savings. The detailed job, artifact and fold citations below support these figures. Each main tier passed all 2,155 named tests; overall jobs failed, including the existing vendored patch-pin coverage refusal. At the last collection (19:21 UTC), nine platform jobs remained pending across the four demonstrations. No demonstration has been closed or newly opened.

At 19:32 UTC, `gh api rate_limit` reported 2,278 core requests and 2,393 GraphQL points remaining. Collection is paused below the mandated 2,500 core reserve, and the manager has been notified (correlation c-233bb6d7c54dfbc23c311ff136ef73be). No further job/artifact/PR reads are being made until recovery. Keep all four inherited runs alive per c12.0. The next free slots still belong to git-reads and engine-startup under c11.2/a33.

Local status: frozen producer 4ee92293; final reader source 327d8551; 23 command tests pass. Producer judged lint passed; the bounded final reader judgment retains three explicitly documented findings under a46 and is not claimed green. Required hosted repetitions and final comparison are still incomplete. The following recovery notes are historical; later dated evidence sections supersede their then-current statuses.

## Initial recovery checkpoint (historical)

Handoff 2026-11-15: round 1 in flight, no completed test-platform measurement collected yet. Four inherited PRs: #1613 exit run 43736250019 head 9ba119ba96fa4544cea8889a2c809e9d01e65a84; #1614 adaptive run 43736257614 head 7c1a2c4daae604222efab39cf976a6b9258b3f8c; #1615 relaunch run 43736265323 head c22459bfda17d6a6ad10e322ff607e70eb56a68e; #1616 base run 43736273251 head 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1. Each has Linux/Windows running and macOS queued at recovery inspection. Do not push to any while in flight. Manager rulings c11.2/c12.0 retain all four, with no cancellation; next free plan slots go to git-reads and engine-startup before this spike starts another round. Base #1616 is an extra before point only if comparable, not a replacement for the approved inventory baseline.

Before side: inventory run 43684231509 attempts 1 and 2, head 36237191db78133b709b3d893ccc11d91d2a5272, GITHUB_SHA 37341b0a57e77d18f6db6c11c1b32d7b30fb8dac, workflow blob db2bbe081a7b9319eb38bd014e72350b389e8b01. Optimized dependencies and byte-identical no-behaviour src edit are present in demonstrations. Baseline evidence is under spikes/launch-inventory/evidence and inventory scratch 1794352-0. Current round uses the measurement.diff cache-read-only trust env override and depsopt.diff inherited from the prior spike.

Remaining: read completed full platform jobs/artifacts; audit workflow blobs, full Nx selections, cache restores and zero writes; fold each platform with inventory points and comparable extra base; get at least three after runs per option/platform under capacity rulings, then combine only options with decided savings (R needs its own saving to join); prove named test outcome equivalence and list recoveries; quote assertions before/after for all changed test bodies and classify behavior proofs; complete wait/count, coverage, adoption and release evidence; finish deterministic and judged diff lint and scoped Rust verification. No savings claim is made yet.

Local verification on 0e1af3e7: six child-waits fold command tests pass. The added spread-case test was first observed failing on a60112d7 with test-only additions (46.50 minutes difference incorrectly labelled decided against a 90-minute spread), then passes after the fix. Biome check over the fold, its test and npm/project.json passed. llmlint deterministic validation excluding vendor/** passed before this fix, and judged diff lint is in progress; neither is claimed final yet. Recovered prior local all-option slice on cabae915 passed 45/45 tests (slice-all.log in scratch 3469976-0), timings not used. That earlier Rust slice predates this retry’s selector validation/type change; its valid-option runtime behavior is preserved, but a new local slice including maintenance/review guards is in progress.

Coverage manager ruling a27: report merged Linux coverage as not produced where the existing vendored-patch-pin refusal makes Nx skip the merge; quote actual job lines once collected, retain unchanged 95.74 LCOV floor, change no test/workflow to force it. List new and stopped branches for implementation follow-through.

Access: host gh login, read-only API; primary remaining at first recovery read 4,906 core / 4,555 GraphQL. Stop reads below 2,500 / 2,000. No new hosted runs, cache writes/deletions or demonstration pushes started by this retry so far.

## Executed round-1 identities (read from each lint job's checkout fetch, checked with git rev-parse on the fetched merge)

| Option | Run | PR | GITHUB_SHA | Head SHA | Executed ci.yml blob |
| --- | --- | --- | --- | --- | --- |
| exit | 43736250019 | 1613 | 8a18672992559a9088d2527a71de265522e7f84f | 9ba119ba96fa4544cea8889a2c809e9d01e65a84 | db2bbe081a7b9319eb38bd014e72350b389e8b01 |
| adaptive | 43736257614 | 1614 | f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7 | 7c1a2c4daae604222efab39cf976a6b9258b3f8c | db2bbe081a7b9319eb38bd014e72350b389e8b01 |
| relaunch | 43736265323 | 1615 | 7b56610e75bdec33e277d44b3e442521f35fe0bb | c22459bfda17d6a6ad10e322ff607e70eb56a68e | db2bbe081a7b9319eb38bd014e72350b389e8b01 |
| base | 43736273251 | 1616 | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | db2bbe081a7b9319eb38bd014e72350b389e8b01 |

No demonstration branch was pushed during these runs. The workflow blob is byte-identical to the inventory baseline's read-only measurement workflow. This is evidence of the configured save guards, not yet a claim that every still-running job's final cache report has been read.

## Effort and release/adoption path (design estimates, not measured minutes)

E: two repository implementation dispatches, onevcs first then onepipeline. onevcs owns platform exit notification and pipe capture (vendor/onevcs/src/{git.rs,probe.rs,pool/maintain.rs,spike_waits.rs} in this prototype). onepipeline changes src/{agentgraph.rs,commandstep.rs,dispatchenv.rs,hooks.rs,planedit.rs,stopguard.rs,sys.rs}. For the contract-preserving implementation path, onevcs keeps its repository-child wait primitive private and onepipeline places its engine-child primitive inside the existing private sys layer; the shared doc-hidden experiment selector/helper API never ships. Release onevcs as a perf/fix patch; onepipeline moves its resolved onevcs dependency to that release (Cargo.lock only when the existing caret requirement permits it; raise the workspace floor only if needed), removes the measurement path patch, integrates its private engine waits, then releases a perf patch. If instead a new shared public onevcs helper is desired, it first requires that contract owner’s proposal/approval and a feat/minor release; no such public interface is approved by this spike. oneagentgraph needs no change/release for this prototype. No journey-body change is selected by E. Existing command arguments, exit handling, timeouts/cancellation, process groups, detached drivers and stdio capture remain asserted by the same tests; readiness can be observed sooner. Fallback paths for unavailable handles/pidfds retain a bounded sleep and need platform-specific production coverage.

A: one onepipeline implementation dispatch, src/{driver.rs,vcs.rs} and tests/e2e/harness.rs. Private backoff/selection helpers currently live in the measurement-only vendor/onevcs/src/spike_waits.rs; when implementing A alone, move that private arithmetic into onepipeline rather than publishing the measurement switch as an API. onepipeline runtime changes take a perf patch; the harness-only portion needs no release, is adopted with the repo commit. No onevcs or oneagentgraph release is needed with that placement. A includes short-then-capped file polls and a park/unpark notification of the follower thread's completion, not solely changed intervals. Event/deadline conditions are retained, including store-cost predicates left at their existing quarter-second-or-longer cadence. It adds earlier looks and a wake token; proof-sensitive interval/backoff/write-back journeys require full-run verification.

R: one onepipeline test-only implementation dispatch across tests/e2e/{adoption.rs,adoption_check.rs,command_step.rs,harness.rs,landing.rs,live_edit.rs,readjust.rs,shipped.rs,unwatched.rs,views.rs}. No repository needs a release; adopting its test commit suffices. It reuses a settled/held run's whole JSON reading for different nodes, or the successful event-poll reading for subsequent assertions, instead of another identical CLI command. Every remaining command still starts a real fresh binary. No assertion is intentionally removed or weakened; values now come from that same stable reading. It proves less repeated independent invocation count by design: the discarded read's second fresh process is no longer separately exercised. That trade is explicit for design review; all named outcome, argument/exit, detached-driver, concurrency, timing and stdio assertions remain as quoted in the journey audit. It is not a blanket claim that snapshot reuse would be safe during arbitrary concurrent state changes. R joins a combination only if its own hosted measurements show a decided saving (a25).

Combination: E's onevcs patch must be available before the consuming onepipeline perf patch; A shares that onepipeline implementation, and R is an optional separately approved test commit. Measurement scripts, trace switches and vendored snapshots never ship.

## Source coverage paths introduced or no longer traversed with the switches selected

E newly enters onevcs::spike_waits::{await_child_exit,await_pid_exit,await_pid,wait_handle}, including Linux pidfd_open/poll/close, macOS kqueue/EVFILT_PROC/kevent/close, Windows process handles/WaitForSingleObject/OpenProcess/CloseHandle and platform-error sleep fallbacks. Its calls are added in onevcs::git::wait_for_exit, onevcs::probe::exited_within, onevcs::pool::maintain::exited_within and the onepipeline run/consult/stop/gone_within functions named above. Selected E bypasses their old sleep or await_an_ending arms on the successful notification path; timeout, signal, read error and cancellation branches remain. Windows PipeCapture::start newly enters the Condvar branch and PipeCapture::finish signals it; the old Windows PipeRead::await_readable sleep is bypassed there (Unix readable-pipe waiting is unchanged).

A newly enters driver::attach_pause's backoff arm and onevcs::spike_waits::backoff (2ms first in driver), harness::spike_variant::pause (1ms first for intervals below 250ms), and vcs::follow's park_timeout plus Follower::finish's unpark. It bypasses fixed sleeps at those sites, resetting backoff when the journal grows. The unselected branches remain available through the demonstration switch; choosing the option does not prove their coverage. Existing large-interval harness polling remains unchanged.

R newly enters harness::World::until_read's retained-reading arm; command_step::Results::{of,already,node}; adoption::node_in; readjust::{results_of,outcomes_of,outcome_in}; and the reused status/reading arms shown in the journey audit. It stops executing the redundant world.run/status/results/runs/unwatched invocations at those specific call sites, so those extra subprocesses' startup and teardown paths are exercised fewer times. It does not remove the binary's command handlers from the selected journeys: each still invokes the corresponding read at least once. No measured coverage percentage is inferred from that source analysis.


## Journey assertion audit (prototype cabae915; R test bodies unchanged at af3fdcd9)

Every before function is read with `git show 13eb521a:tests/e2e/FILE.rs`; every after function with `git show af3fdcd9:tests/e2e/FILE.rs`. Full bodies are quoted with a brace scanner that skips strings/raw strings/comments, including every assertion, argument/exit/stdio check and event predicate. Helper assertion bodies follow the tests. These are source comparisons; they do not substitute for hosted passed-test evidence.

### `adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/adoption.rs`):

```rust

fn a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once() {
    let host = HeldHost::new("adoption-held-landing");
    let world = &host.world;
    let (base_before, checkout_before) = host.bases();
    let commits_before = host.consumer.base_commits(world).len();

    let (run, reference) = start_held(&host, "adoption-held-landing", Some("crate"));

    // (2) Held, under its own status and word, and only after its judge accepted
    // the work: the dispatch that ran is the one that succeeded.
    let settled = settlement_of(world, &run, "consumer");
    assert_eq!(
        settled["payload"]["status"], "complete-but-held",
        "{settled}"
    );
    assert_eq!(
        settled["payload"]["outcome"], "held-for-release",
        "{settled}"
    );
    let branch = branch_of(world, &run, "consumer");
    let head = settled["payload"]["head"]
        .as_str()
        .unwrap_or_else(|| panic!("the held settlement names no commit: {settled}"))
        .to_owned();
    let detail = format!(
        "complete, and held unlanded: awaiting the crate release of github.com/owner/engine, \
         kept on {branch} at {head} (pushed); it lands when that release arrives"
    );
    assert_eq!(settled["payload"]["detail"], json!(detail), "{settled}");
    let awaited = json!([{"producer": "github.com/owner/engine", "target": "crate"}]);
    assert_eq!(settled["payload"]["awaiting"], awaited, "{settled}");
    assert_eq!(settled["payload"]["remote"], "pushed", "{settled}");
    assert_eq!(tasks_of(world, "consumer").len(), 1);
    // The commit is on the consumer's origin under that branch, and it carries the
    // pin to the producer's branch.
    assert_eq!(
        host.on_origin(&format!("refs/heads/{branch}")).as_deref(),
        Some(head.as_str()),
        "the held branch is not on the consumer's origin at its commit"
    );
    assert_eq!(
        host.origin_git(&["show", &format!("{head}:pin.md")]).trim(),
        pin(&format!("{{ branch = \"{reference}\" }}"))
    );
    // Nothing landed, nothing ran the merge path, and no change request opened.
    assert_eq!(host.bases(), (base_before.clone(), checkout_before.clone()));
    assert_eq!(host.pushes(), 0, "the merge path ran at the hold");
    assert!(
        world.changes_opened().is_empty(),
        "{:?}",
        world.changes_opened()
    );
    assert!(
        !gh_calls(world)
            .iter()
            .any(|call| call.first().map(String::as_str) == Some("pr")
                && call.get(1).map(String::as_str) == Some("create")),
        "a change request was opened: {:?}",
        gh_calls(world)
    );
    assert!(
        !dispatched(world, &run, "follower"),
        "a dependent started on held work"
    );
    // Every reader says the same: `status --json` reports it held with that detail
    // and what it awaits as data, the run is neither settled nor dead, and
    // `unpublished` counts the branch as owed.
    let entry = reading_node(world, &run, "consumer");
    assert_eq!(entry["status"], "complete-but-held", "{entry}");
    assert_eq!(entry["outcome"], "held-for-release", "{entry}");
    assert_eq!(entry["detail"], json!(detail), "{entry}");
    assert_eq!(entry["awaiting"], awaited, "{entry}");
    let reading = world.run(&["status", &run, "--json"]).json();
    assert_eq!(reading["ending"], Value::Null, "{reading}");
    assert_ne!(reading["word"], "SETTLED", "{reading}");
    assert_ne!(reading["word"], "DRIVER DEAD", "{reading}");
    // Every node is listed, in plan order: the producer done on its landing, and the
    // dependent pending with nothing recorded for it.
    let listed: Vec<&str> = reading["nodes"]
        .as_array()
        .expect("the reading lists its nodes")
        .iter()
        .filter_map(|entry| entry["id"].as_str())
        .collect();
    assert_eq!(listed, [ENGINE, "consumer", "follower"], "{reading}");
    let producer = reading_node(world, &run, ENGINE);
    assert_eq!(producer["status"], "done", "{producer}");
    assert_eq!(producer["outcome"], "merged", "{producer}");
    assert!(producer.get("awaiting").is_none(), "{producer}");
    assert_eq!(
        reading_node(world, &run, "follower"),
        json!({"id": "follower", "status": "pending", "outcome": null, "detail": null})
    );
    world
        .run(&["status", &run])
        .exited(0)
        .out_has(&format!("consumer: complete-but-held — {detail}"))
        .out_has("neither stalled nor finished")
        .out_lacks("SETTLED");
    assert!(
        host.unpublished().contains(&branch),
        "`unpublished` does not count the held branch: {:?}",
        host.unpublished()
    );
    // The plan of record carries it as work still in hand.
    world.until_store("the store to carry the held node as in progress", |world| {
        world
            .store_tasks(&format!("plans:{}", project_id(&run)))
            .iter()
            .any(|task| {
                task["item"]["metadata"]["onepipeline.id"] == "consumer"
                    && task["item"]["status"]["category"] == "in-progress"
            })
    });

    // (3) A release of the producer's **other** target lifts nothing: the probe that
    // answers it is not the one this node awaits, however many polls go by.
    releases_at(&host.bindings_answer, "0.1.0");
    let asked = world.probe_runs("crate");
    world.until("the awaited target to be asked again", |world| {
        world.probe_runs("crate") >= asked + 2
    });
    assert!(world.events_of(&run, "release-adopted").is_empty());
    assert_eq!(
        settled_status(world, &run, "consumer").as_deref(),
        Some("complete-but-held")
    );
    assert_eq!(tasks_of(world, "consumer").len(), 1);
    assert_eq!(host.bases(), (base_before.clone(), checkout_before.clone()));
    assert_eq!(host.pushes(), 0);
    assert!(!dispatched(world, &run, "follower"));
    assert!(host.unpublished().contains(&branch));

    // (4) The awaited target releases. The worker put back on the branch is told
    // which version, and rewrites the pin to it on top of the held commit.
    world.script("consumer.work", &pin("\"0.2.0\""));
    // The re-dispatch is held open once it starts, so the reading of a node that has
    // left its held settlement can be read: no `consumer.go` until it is.
    std::fs::remove_file(world.fakes.join("consumer.go")).expect("the first hold's release");
    releases_at(&host.crate_answer, "0.2.0");
    world.until("the consumer to be re-dispatched", |world| {
        tasks_of(world, "consumer").len() == 2
    });
    // Back at work, it is no longer reported with the words or the wait of the
    // settlement it has left.
    let running = reading_node(world, &run, "consumer");
    assert_eq!(running["status"], "running", "{running}");
    assert_eq!(running["detail"], Value::Null, "{running}");
    assert!(running.get("awaiting").is_none(), "{running}");
    world.release("consumer.go");
    world.until("the consumer to land", |world| {
        settled_status(world, &run, "consumer").as_deref() == Some("done")
    });
    assert_eq!(world.events_of(&run, "release-adopted").len(), 1);
    let tasks = tasks_of(world, "consumer");
    assert_eq!(tasks.len(), 2, "{tasks:?}");
    assert!(
        tasks[1].contains("github.com/owner/engine — crate 0.2.0"),
        "the re-dispatch was not told which version arrived:\n{}",
        tasks[1]
    );
    assert_eq!(
        branch_of(world, &run, "consumer"),
        branch,
        "the release cut a second branch beside the held one"
    );

    // (5) One local-direct landing commit: the previous base plus exactly the
    // branch's net changes, its pin naming the released version.
    let landed = settlement_of(world, &run, "consumer");
    assert_eq!(landed["payload"]["landing"], "landed", "{landed}");
    assert!(landed["payload"].get("awaiting").is_none(), "{landed}");
    let commits = host.consumer.base_commits(world);
    assert_eq!(commits.len(), commits_before + 1, "{commits:?}");
    let base_before = base_before.expect("the consumer's origin had a base");
    assert_eq!(
        host.origin_git(&["rev-parse", "main~1"]).trim(),
        base_before,
        "the landing is not one commit on the previous base"
    );
    assert_eq!(
        host.origin_git(&["diff", "--name-status", &base_before, "main"])
            .trim(),
        "A\tpin.md",
        "the landing carries more or less than the branch's net change"
    );
    assert_eq!(
        host.consumer.base_file("pin.md").as_deref().map(str::trim),
        Some(pin("\"0.2.0\"").as_str()),
        "the landed pin does not name the released version"
    );
    // The re-dispatch committed on top of the held commit, rather than beside it.
    let tip = landed["payload"]["head"]
        .as_str()
        .unwrap_or_else(|| panic!("the landing names no branch tip: {landed}"))
        .to_owned();
    assert_ne!(
        tip, head,
        "the re-dispatch committed nothing on the held branch"
    );
    // Read in the publication checkout, where a session hands its branch back: a
    // local-direct landing squashes the branch onto the base and pushes the base.
    let checkout = |args: &[&str]| crate::harness::git(world, &host.consumer.checkout, args);
    checkout(&["merge-base", "--is-ancestor", &head, &tip]);
    assert_eq!(
        checkout(&["show", &format!("{tip}:pin.md")]).trim(),
        pin("\"0.2.0\"")
    );
    assert_eq!(
        checkout(&["rev-parse", &format!("{tip}^{{tree}}")]).trim(),
        host.origin_git(&["rev-parse", "main^{tree}"]).trim(),
        "the landing's tree is not the branch's"
    );
    assert_eq!(
        host.pushes(),
        1,
        "the merge path did not run exactly once, at landing"
    );
    // The time it spent held, from its settlement to the release re-dispatching it,
    // is booked to the release wait of its one change.
    let telemetry = world
        .run(&["telemetry", &run, "--changes", "--json"])
        .exited(0)
        .json();
    let change = telemetry["changes"]
        .as_array()
        .and_then(|changes| changes.iter().find(|change| change["node"] == "consumer"))
        .unwrap_or_else(|| panic!("the change telemetry has no consumer: {telemetry}"))
        .clone();
    assert!(
        change["segments"]["release_wait"].as_f64().unwrap_or(0.0) >= 1.0,
        "the held change's wait is not booked to the release: {change}"
    );
    assert!(
        !host.unpublished().contains(&branch),
        "`unpublished` still counts a landed branch"
    );
    world.until("the dependent to run and the run to settle", |world| {
        world.run(&["status", &run, "--json"]).json()["word"] == "SETTLED"
    });
    assert!(dispatched(world, &run, "follower"));
}

```

After (af3fdcd9, `tests/e2e/adoption.rs`):

```rust

fn a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once() {
    let host = HeldHost::new("adoption-held-landing");
    let world = &host.world;
    let (base_before, checkout_before) = host.bases();
    let commits_before = host.consumer.base_commits(world).len();

    let (run, reference) = start_held(&host, "adoption-held-landing", Some("crate"));

    // (2) Held, under its own status and word, and only after its judge accepted
    // the work: the dispatch that ran is the one that succeeded.
    let settled = settlement_of(world, &run, "consumer");
    assert_eq!(
        settled["payload"]["status"], "complete-but-held",
        "{settled}"
    );
    assert_eq!(
        settled["payload"]["outcome"], "held-for-release",
        "{settled}"
    );
    let branch = branch_of(world, &run, "consumer");
    let head = settled["payload"]["head"]
        .as_str()
        .unwrap_or_else(|| panic!("the held settlement names no commit: {settled}"))
        .to_owned();
    let detail = format!(
        "complete, and held unlanded: awaiting the crate release of github.com/owner/engine, \
         kept on {branch} at {head} (pushed); it lands when that release arrives"
    );
    assert_eq!(settled["payload"]["detail"], json!(detail), "{settled}");
    let awaited = json!([{"producer": "github.com/owner/engine", "target": "crate"}]);
    assert_eq!(settled["payload"]["awaiting"], awaited, "{settled}");
    assert_eq!(settled["payload"]["remote"], "pushed", "{settled}");
    assert_eq!(tasks_of(world, "consumer").len(), 1);
    // The commit is on the consumer's origin under that branch, and it carries the
    // pin to the producer's branch.
    assert_eq!(
        host.on_origin(&format!("refs/heads/{branch}")).as_deref(),
        Some(head.as_str()),
        "the held branch is not on the consumer's origin at its commit"
    );
    assert_eq!(
        host.origin_git(&["show", &format!("{head}:pin.md")]).trim(),
        pin(&format!("{{ branch = \"{reference}\" }}"))
    );
    // Nothing landed, nothing ran the merge path, and no change request opened.
    assert_eq!(host.bases(), (base_before.clone(), checkout_before.clone()));
    assert_eq!(host.pushes(), 0, "the merge path ran at the hold");
    assert!(
        world.changes_opened().is_empty(),
        "{:?}",
        world.changes_opened()
    );
    assert!(
        !gh_calls(world)
            .iter()
            .any(|call| call.first().map(String::as_str) == Some("pr")
                && call.get(1).map(String::as_str) == Some("create")),
        "a change request was opened: {:?}",
        gh_calls(world)
    );
    assert!(
        !dispatched(world, &run, "follower"),
        "a dependent started on held work"
    );
    // Every reader says the same: `status --json` reports it held with that detail
    // and what it awaits as data, the run is neither settled nor dead, and
    // `unpublished` counts the branch as owed.
    // Measurement only (spike-child-waits, never lands): under the re-launch
    // prototype one reading answers for every node, since nothing moves until the
    // release below.
    let once = crate::harness::spike_variant::relaunch()
        .then(|| world.run(&["status", &run, "--json"]).json());
    let node_of = |node: &str| match &once {
        Some(reading) => node_in(reading, node),
        None => reading_node(world, &run, node),
    };
    let entry = node_of("consumer");
    assert_eq!(entry["status"], "complete-but-held", "{entry}");
    assert_eq!(entry["outcome"], "held-for-release", "{entry}");
    assert_eq!(entry["detail"], json!(detail), "{entry}");
    assert_eq!(entry["awaiting"], awaited, "{entry}");
    let reading = once
        .clone()
        .unwrap_or_else(|| world.run(&["status", &run, "--json"]).json());
    assert_eq!(reading["ending"], Value::Null, "{reading}");
    assert_ne!(reading["word"], "SETTLED", "{reading}");
    assert_ne!(reading["word"], "DRIVER DEAD", "{reading}");
    // Every node is listed, in plan order: the producer done on its landing, and the
    // dependent pending with nothing recorded for it.
    let listed: Vec<&str> = reading["nodes"]
        .as_array()
        .expect("the reading lists its nodes")
        .iter()
        .filter_map(|entry| entry["id"].as_str())
        .collect();
    assert_eq!(listed, [ENGINE, "consumer", "follower"], "{reading}");
    let producer = node_of(ENGINE);
    assert_eq!(producer["status"], "done", "{producer}");
    assert_eq!(producer["outcome"], "merged", "{producer}");
    assert!(producer.get("awaiting").is_none(), "{producer}");
    assert_eq!(
        node_of("follower"),
        json!({"id": "follower", "status": "pending", "outcome": null, "detail": null})
    );
    world
        .run(&["status", &run])
        .exited(0)
        .out_has(&format!("consumer: complete-but-held — {detail}"))
        .out_has("neither stalled nor finished")
        .out_lacks("SETTLED");
    assert!(
        host.unpublished().contains(&branch),
        "`unpublished` does not count the held branch: {:?}",
        host.unpublished()
    );
    // The plan of record carries it as work still in hand.
    world.until_store("the store to carry the held node as in progress", |world| {
        world
            .store_tasks(&format!("plans:{}", project_id(&run)))
            .iter()
            .any(|task| {
                task["item"]["metadata"]["onepipeline.id"] == "consumer"
                    && task["item"]["status"]["category"] == "in-progress"
            })
    });

    // (3) A release of the producer's **other** target lifts nothing: the probe that
    // answers it is not the one this node awaits, however many polls go by.
    releases_at(&host.bindings_answer, "0.1.0");
    let asked = world.probe_runs("crate");
    world.until("the awaited target to be asked again", |world| {
        world.probe_runs("crate") >= asked + 2
    });
    assert!(world.events_of(&run, "release-adopted").is_empty());
    assert_eq!(
        settled_status(world, &run, "consumer").as_deref(),
        Some("complete-but-held")
    );
    assert_eq!(tasks_of(world, "consumer").len(), 1);
    assert_eq!(host.bases(), (base_before.clone(), checkout_before.clone()));
    assert_eq!(host.pushes(), 0);
    assert!(!dispatched(world, &run, "follower"));
    assert!(host.unpublished().contains(&branch));

    // (4) The awaited target releases. The worker put back on the branch is told
    // which version, and rewrites the pin to it on top of the held commit.
    world.script("consumer.work", &pin("\"0.2.0\""));
    // The re-dispatch is held open once it starts, so the reading of a node that has
    // left its held settlement can be read: no `consumer.go` until it is.
    std::fs::remove_file(world.fakes.join("consumer.go")).expect("the first hold's release");
    releases_at(&host.crate_answer, "0.2.0");
    world.until("the consumer to be re-dispatched", |world| {
        tasks_of(world, "consumer").len() == 2
    });
    // Back at work, it is no longer reported with the words or the wait of the
    // settlement it has left.
    let running = reading_node(world, &run, "consumer");
    assert_eq!(running["status"], "running", "{running}");
    assert_eq!(running["detail"], Value::Null, "{running}");
    assert!(running.get("awaiting").is_none(), "{running}");
    world.release("consumer.go");
    world.until("the consumer to land", |world| {
        settled_status(world, &run, "consumer").as_deref() == Some("done")
    });
    assert_eq!(world.events_of(&run, "release-adopted").len(), 1);
    let tasks = tasks_of(world, "consumer");
    assert_eq!(tasks.len(), 2, "{tasks:?}");
    assert!(
        tasks[1].contains("github.com/owner/engine — crate 0.2.0"),
        "the re-dispatch was not told which version arrived:\n{}",
        tasks[1]
    );
    assert_eq!(
        branch_of(world, &run, "consumer"),
        branch,
        "the release cut a second branch beside the held one"
    );

    // (5) One local-direct landing commit: the previous base plus exactly the
    // branch's net changes, its pin naming the released version.
    let landed = settlement_of(world, &run, "consumer");
    assert_eq!(landed["payload"]["landing"], "landed", "{landed}");
    assert!(landed["payload"].get("awaiting").is_none(), "{landed}");
    let commits = host.consumer.base_commits(world);
    assert_eq!(commits.len(), commits_before + 1, "{commits:?}");
    let base_before = base_before.expect("the consumer's origin had a base");
    assert_eq!(
        host.origin_git(&["rev-parse", "main~1"]).trim(),
        base_before,
        "the landing is not one commit on the previous base"
    );
    assert_eq!(
        host.origin_git(&["diff", "--name-status", &base_before, "main"])
            .trim(),
        "A\tpin.md",
        "the landing carries more or less than the branch's net change"
    );
    assert_eq!(
        host.consumer.base_file("pin.md").as_deref().map(str::trim),
        Some(pin("\"0.2.0\"").as_str()),
        "the landed pin does not name the released version"
    );
    // The re-dispatch committed on top of the held commit, rather than beside it.
    let tip = landed["payload"]["head"]
        .as_str()
        .unwrap_or_else(|| panic!("the landing names no branch tip: {landed}"))
        .to_owned();
    assert_ne!(
        tip, head,
        "the re-dispatch committed nothing on the held branch"
    );
    // Read in the publication checkout, where a session hands its branch back: a
    // local-direct landing squashes the branch onto the base and pushes the base.
    let checkout = |args: &[&str]| crate::harness::git(world, &host.consumer.checkout, args);
    checkout(&["merge-base", "--is-ancestor", &head, &tip]);
    assert_eq!(
        checkout(&["show", &format!("{tip}:pin.md")]).trim(),
        pin("\"0.2.0\"")
    );
    assert_eq!(
        checkout(&["rev-parse", &format!("{tip}^{{tree}}")]).trim(),
        host.origin_git(&["rev-parse", "main^{tree}"]).trim(),
        "the landing's tree is not the branch's"
    );
    assert_eq!(
        host.pushes(),
        1,
        "the merge path did not run exactly once, at landing"
    );
    // The time it spent held, from its settlement to the release re-dispatching it,
    // is booked to the release wait of its one change.
    let telemetry = world
        .run(&["telemetry", &run, "--changes", "--json"])
        .exited(0)
        .json();
    let change = telemetry["changes"]
        .as_array()
        .and_then(|changes| changes.iter().find(|change| change["node"] == "consumer"))
        .unwrap_or_else(|| panic!("the change telemetry has no consumer: {telemetry}"))
        .clone();
    assert!(
        change["segments"]["release_wait"].as_f64().unwrap_or(0.0) >= 1.0,
        "the held change's wait is not booked to the release: {change}"
    );
    assert!(
        !host.unpublished().contains(&branch),
        "`unpublished` still counts a landed branch"
    );
    world.until("the dependent to run and the run to settle", |world| {
        world.run(&["status", &run, "--json"]).json()["word"] == "SETTLED"
    });
    assert!(dispatched(world, &run, "follower"));
}

```

### `adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/adoption.rs`):

```rust

fn a_node_settled_at_a_change_request_reads_landed_in_every_surface() {
    a_stated_landing_reads_landed_in_every_surface(
        "adoption-stated-change",
        Spelling::ChangeRequest,
    );
}

fn a_stated_landing_reads_landed_in_every_surface(name: &str, spelling: Spelling) {
    let world = watching(name);
    world.write_graphs();
    let (engine_repo, _consumer) = two_repositories(&world);
    the_engine_publishes_by_opening_a_change(&world);

    // `landed` opens the change request that carries the work, and `broken` is the
    // node whose record goes stale: its dispatch opens a change request of its own
    // that nobody merges, so the run records it done and unlanded on a branch the
    // work never reached a base from. `hold` keeps the run driven throughout.
    let mut landed = engine();
    landed["id"] = json!("landed");
    let mut broken = engine();
    broken["id"] = json!("broken");
    broken["deps"] = json!(["landed"]);
    world.script("hold.wait", "hold");
    let run = start(&world, name, vec![landed, broken, agent("hold", &[])]);
    world.until("the broken node to settle", |world| {
        settled_status(world, &run, "broken") == Some("done".to_owned())
    });
    let superseded = change_url_of(&world, &run, "broken");
    let project = format!("plans:{}", project_id(name));
    let board = |world: &World| {
        world
            .store_tasks(&project)
            .into_iter()
            .find(|task| task["item"]["metadata"]["onepipeline.id"] == "broken")
            .map(|task| task["item"]["metadata"].clone())
    };
    world.until_store("the superseded change to reach the board", |world| {
        board(world).is_some_and(|metadata| {
            metadata["onepipeline.landing"] == "unlanded"
                && metadata["onepipeline.change_url"] == json!(superseded)
        })
    });

    // A person merges the work — `landed`'s change — and every surface is read
    // before the manager states it, so what moves afterwards is the statement alone.
    let branch = branch_of(&world, &run, "landed");
    let landing = match spelling {
        Spelling::Commit => squash_land(&world, &engine_repo.checkout, &branch),
        Spelling::ChangeRequest => {
            land(&world, &engine_repo.checkout, &branch);
            change_url_of(&world, &run, "landed")
        }
    };
    let before = world.run(&["results", &run]);
    before.exited(0);
    assert!(
        line_about(&before.stdout, "broken").contains("NOT landed"),
        "the superseded branch was not read as unlanded before the statement:\n{}",
        before.stdout
    );
    let counted = not_landed_in_listing(&world, &run);
    assert!(
        counted >= 1,
        "the listing counted no unlanded work before the statement"
    );

    // Settled again at the outcome it already holds: stating where the work landed
    // is a correction, not a duplicate.
    let settled = world.run_with_stdin(
        &["reply", &run],
        &json!({"version": onepipeline::channel::REPLY_ENVELOPE_VERSION, "commands": [{
            "op": "settle", "id": "broken", "outcome": "done",
            "evidence": "the work merged in the other change; this node's own was superseded",
            "landing": landing,
        }]})
        .to_string(),
    );
    settled.exited(0).out_has("\"applied\"");
    // No release is declared for this repository, so there is no release to warn of.
    settled.err_lacks("release baseline");

    // `results`: landed, on the stated tier, at the stated reference — and no
    // verdict read off the superseded branch beside it.
    let stated = format!(
        "landed on its base — {}: stated from evidence at {landing}",
        tier_of(spelling)
    );
    world.until("results to read the stated landing", |world| {
        let results = world.run(&["results", &run]);
        line_about(&results.stdout, "broken").contains(&stated)
    });
    let results = world.run(&["results", &run]);
    let line = line_about(&results.stdout, "broken");
    for contradiction in ["NOT landed", "UNDECIDED", "the run observed"] {
        assert!(
            !line.contains(contradiction),
            "the stated landing was contradicted by `{contradiction}`: {line}"
        );
    }

    // `status`: not counted as work that has not landed, nor as undecided.
    let status = world.run(&["status", &run]);
    status.exited(0);
    assert!(
        !status.stdout.lines().any(|line| {
            (line.contains("have not landed") || line.contains("could not decide"))
                && line.contains("broken")
        }),
        "status counts a node settled at its landing as outstanding:\n{}",
        status.stdout
    );

    // `runs`, served off the summary document: one fewer node not landed.
    world.until("the listing to count the stated landing", |world| {
        not_landed_in_listing(world, &run) == counted - 1
    });

    // The board: the same interpretation, with the tier and the stated reference in
    // place of the superseded change the run had recorded.
    world.until_store("the stated landing to reach the board", |world| {
        board(world).is_some_and(|metadata| {
            let referenced = match spelling {
                Spelling::Commit => {
                    metadata["onepipeline.landing_commit"] == json!(landing)
                        && metadata.get("onepipeline.change_url").is_none()
                }
                Spelling::ChangeRequest => metadata["onepipeline.change_url"] == json!(landing),
            };
            metadata["onepipeline.landing"] == "landed"
                && metadata["onepipeline.landing_evidence"] == tier_of(spelling)
                && referenced
        })
    });
    assert_ne!(landing, superseded);

    world.release("hold.go");
    world.until("the run to settle", |world| {
        world.run_file(&run, "result.json").is_file()
    });
    // And the run's own result, written as it closed, says the same.
    let result = world.run_json(&run, "result.json");
    let settled = result["nodes"]
        .as_array()
        .and_then(|nodes| nodes.iter().find(|node| node["id"] == "broken"))
        .unwrap_or_else(|| panic!("the result names no broken node: {result}"));
    assert_eq!(settled["landing"], json!("landed"), "{settled}");
}

```

After (af3fdcd9, `tests/e2e/adoption.rs`):

```rust

fn a_node_settled_at_a_change_request_reads_landed_in_every_surface() {
    a_stated_landing_reads_landed_in_every_surface(
        "adoption-stated-change",
        Spelling::ChangeRequest,
    );
}

fn a_stated_landing_reads_landed_in_every_surface(name: &str, spelling: Spelling) {
    let world = watching(name);
    world.write_graphs();
    let (engine_repo, _consumer) = two_repositories(&world);
    the_engine_publishes_by_opening_a_change(&world);

    // `landed` opens the change request that carries the work, and `broken` is the
    // node whose record goes stale: its dispatch opens a change request of its own
    // that nobody merges, so the run records it done and unlanded on a branch the
    // work never reached a base from. `hold` keeps the run driven throughout.
    let mut landed = engine();
    landed["id"] = json!("landed");
    let mut broken = engine();
    broken["id"] = json!("broken");
    broken["deps"] = json!(["landed"]);
    world.script("hold.wait", "hold");
    let run = start(&world, name, vec![landed, broken, agent("hold", &[])]);
    world.until("the broken node to settle", |world| {
        settled_status(world, &run, "broken") == Some("done".to_owned())
    });
    let superseded = change_url_of(&world, &run, "broken");
    let project = format!("plans:{}", project_id(name));
    let board = |world: &World| {
        world
            .store_tasks(&project)
            .into_iter()
            .find(|task| task["item"]["metadata"]["onepipeline.id"] == "broken")
            .map(|task| task["item"]["metadata"].clone())
    };
    world.until_store("the superseded change to reach the board", |world| {
        board(world).is_some_and(|metadata| {
            metadata["onepipeline.landing"] == "unlanded"
                && metadata["onepipeline.change_url"] == json!(superseded)
        })
    });

    // A person merges the work — `landed`'s change — and every surface is read
    // before the manager states it, so what moves afterwards is the statement alone.
    let branch = branch_of(&world, &run, "landed");
    let landing = match spelling {
        Spelling::Commit => squash_land(&world, &engine_repo.checkout, &branch),
        Spelling::ChangeRequest => {
            land(&world, &engine_repo.checkout, &branch);
            change_url_of(&world, &run, "landed")
        }
    };
    let before = world.run(&["results", &run]);
    before.exited(0);
    assert!(
        line_about(&before.stdout, "broken").contains("NOT landed"),
        "the superseded branch was not read as unlanded before the statement:\n{}",
        before.stdout
    );
    let counted = not_landed_in_listing(&world, &run);
    assert!(
        counted >= 1,
        "the listing counted no unlanded work before the statement"
    );

    // Settled again at the outcome it already holds: stating where the work landed
    // is a correction, not a duplicate.
    let settled = world.run_with_stdin(
        &["reply", &run],
        &json!({"version": onepipeline::channel::REPLY_ENVELOPE_VERSION, "commands": [{
            "op": "settle", "id": "broken", "outcome": "done",
            "evidence": "the work merged in the other change; this node's own was superseded",
            "landing": landing,
        }]})
        .to_string(),
    );
    settled.exited(0).out_has("\"applied\"");
    // No release is declared for this repository, so there is no release to warn of.
    settled.err_lacks("release baseline");

    // `results`: landed, on the stated tier, at the stated reference — and no
    // verdict read off the superseded branch beside it.
    let stated = format!(
        "landed on its base — {}: stated from evidence at {landing}",
        tier_of(spelling)
    );
    let results = world.until_read(
        "results to read the stated landing",
        false,
        |world| world.run(&["results", &run]),
        |results| line_about(&results.stdout, "broken").contains(&stated),
    );
    let line = line_about(&results.stdout, "broken");
    for contradiction in ["NOT landed", "UNDECIDED", "the run observed"] {
        assert!(
            !line.contains(contradiction),
            "the stated landing was contradicted by `{contradiction}`: {line}"
        );
    }

    // `status`: not counted as work that has not landed, nor as undecided.
    let status = world.run(&["status", &run]);
    status.exited(0);
    assert!(
        !status.stdout.lines().any(|line| {
            (line.contains("have not landed") || line.contains("could not decide"))
                && line.contains("broken")
        }),
        "status counts a node settled at its landing as outstanding:\n{}",
        status.stdout
    );

    // `runs`, served off the summary document: one fewer node not landed.
    world.until("the listing to count the stated landing", |world| {
        not_landed_in_listing(world, &run) == counted - 1
    });

    // The board: the same interpretation, with the tier and the stated reference in
    // place of the superseded change the run had recorded.
    world.until_store("the stated landing to reach the board", |world| {
        board(world).is_some_and(|metadata| {
            let referenced = match spelling {
                Spelling::Commit => {
                    metadata["onepipeline.landing_commit"] == json!(landing)
                        && metadata.get("onepipeline.change_url").is_none()
                }
                Spelling::ChangeRequest => metadata["onepipeline.change_url"] == json!(landing),
            };
            metadata["onepipeline.landing"] == "landed"
                && metadata["onepipeline.landing_evidence"] == tier_of(spelling)
                && referenced
        })
    });
    assert_ne!(landing, superseded);

    world.release("hold.go");
    world.until("the run to settle", |world| {
        world.run_file(&run, "result.json").is_file()
    });
    // And the run's own result, written as it closed, says the same.
    let result = world.run_json(&run, "result.json");
    let settled = result["nodes"]
        .as_array()
        .and_then(|nodes| nodes.iter().find(|node| node["id"] == "broken"))
        .unwrap_or_else(|| panic!("the result names no broken node: {result}"));
    assert_eq!(settled["landing"], json!("landed"), "{settled}");
}

```

### `adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/adoption.rs`):

```rust

fn a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface() {
    a_stated_landing_reads_landed_in_every_surface("adoption-stated-squash", Spelling::Commit);
}

fn a_stated_landing_reads_landed_in_every_surface(name: &str, spelling: Spelling) {
    let world = watching(name);
    world.write_graphs();
    let (engine_repo, _consumer) = two_repositories(&world);
    the_engine_publishes_by_opening_a_change(&world);

    // `landed` opens the change request that carries the work, and `broken` is the
    // node whose record goes stale: its dispatch opens a change request of its own
    // that nobody merges, so the run records it done and unlanded on a branch the
    // work never reached a base from. `hold` keeps the run driven throughout.
    let mut landed = engine();
    landed["id"] = json!("landed");
    let mut broken = engine();
    broken["id"] = json!("broken");
    broken["deps"] = json!(["landed"]);
    world.script("hold.wait", "hold");
    let run = start(&world, name, vec![landed, broken, agent("hold", &[])]);
    world.until("the broken node to settle", |world| {
        settled_status(world, &run, "broken") == Some("done".to_owned())
    });
    let superseded = change_url_of(&world, &run, "broken");
    let project = format!("plans:{}", project_id(name));
    let board = |world: &World| {
        world
            .store_tasks(&project)
            .into_iter()
            .find(|task| task["item"]["metadata"]["onepipeline.id"] == "broken")
            .map(|task| task["item"]["metadata"].clone())
    };
    world.until_store("the superseded change to reach the board", |world| {
        board(world).is_some_and(|metadata| {
            metadata["onepipeline.landing"] == "unlanded"
                && metadata["onepipeline.change_url"] == json!(superseded)
        })
    });

    // A person merges the work — `landed`'s change — and every surface is read
    // before the manager states it, so what moves afterwards is the statement alone.
    let branch = branch_of(&world, &run, "landed");
    let landing = match spelling {
        Spelling::Commit => squash_land(&world, &engine_repo.checkout, &branch),
        Spelling::ChangeRequest => {
            land(&world, &engine_repo.checkout, &branch);
            change_url_of(&world, &run, "landed")
        }
    };
    let before = world.run(&["results", &run]);
    before.exited(0);
    assert!(
        line_about(&before.stdout, "broken").contains("NOT landed"),
        "the superseded branch was not read as unlanded before the statement:\n{}",
        before.stdout
    );
    let counted = not_landed_in_listing(&world, &run);
    assert!(
        counted >= 1,
        "the listing counted no unlanded work before the statement"
    );

    // Settled again at the outcome it already holds: stating where the work landed
    // is a correction, not a duplicate.
    let settled = world.run_with_stdin(
        &["reply", &run],
        &json!({"version": onepipeline::channel::REPLY_ENVELOPE_VERSION, "commands": [{
            "op": "settle", "id": "broken", "outcome": "done",
            "evidence": "the work merged in the other change; this node's own was superseded",
            "landing": landing,
        }]})
        .to_string(),
    );
    settled.exited(0).out_has("\"applied\"");
    // No release is declared for this repository, so there is no release to warn of.
    settled.err_lacks("release baseline");

    // `results`: landed, on the stated tier, at the stated reference — and no
    // verdict read off the superseded branch beside it.
    let stated = format!(
        "landed on its base — {}: stated from evidence at {landing}",
        tier_of(spelling)
    );
    world.until("results to read the stated landing", |world| {
        let results = world.run(&["results", &run]);
        line_about(&results.stdout, "broken").contains(&stated)
    });
    let results = world.run(&["results", &run]);
    let line = line_about(&results.stdout, "broken");
    for contradiction in ["NOT landed", "UNDECIDED", "the run observed"] {
        assert!(
            !line.contains(contradiction),
            "the stated landing was contradicted by `{contradiction}`: {line}"
        );
    }

    // `status`: not counted as work that has not landed, nor as undecided.
    let status = world.run(&["status", &run]);
    status.exited(0);
    assert!(
        !status.stdout.lines().any(|line| {
            (line.contains("have not landed") || line.contains("could not decide"))
                && line.contains("broken")
        }),
        "status counts a node settled at its landing as outstanding:\n{}",
        status.stdout
    );

    // `runs`, served off the summary document: one fewer node not landed.
    world.until("the listing to count the stated landing", |world| {
        not_landed_in_listing(world, &run) == counted - 1
    });

    // The board: the same interpretation, with the tier and the stated reference in
    // place of the superseded change the run had recorded.
    world.until_store("the stated landing to reach the board", |world| {
        board(world).is_some_and(|metadata| {
            let referenced = match spelling {
                Spelling::Commit => {
                    metadata["onepipeline.landing_commit"] == json!(landing)
                        && metadata.get("onepipeline.change_url").is_none()
                }
                Spelling::ChangeRequest => metadata["onepipeline.change_url"] == json!(landing),
            };
            metadata["onepipeline.landing"] == "landed"
                && metadata["onepipeline.landing_evidence"] == tier_of(spelling)
                && referenced
        })
    });
    assert_ne!(landing, superseded);

    world.release("hold.go");
    world.until("the run to settle", |world| {
        world.run_file(&run, "result.json").is_file()
    });
    // And the run's own result, written as it closed, says the same.
    let result = world.run_json(&run, "result.json");
    let settled = result["nodes"]
        .as_array()
        .and_then(|nodes| nodes.iter().find(|node| node["id"] == "broken"))
        .unwrap_or_else(|| panic!("the result names no broken node: {result}"));
    assert_eq!(settled["landing"], json!("landed"), "{settled}");
}

```

After (af3fdcd9, `tests/e2e/adoption.rs`):

```rust

fn a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface() {
    a_stated_landing_reads_landed_in_every_surface("adoption-stated-squash", Spelling::Commit);
}

fn a_stated_landing_reads_landed_in_every_surface(name: &str, spelling: Spelling) {
    let world = watching(name);
    world.write_graphs();
    let (engine_repo, _consumer) = two_repositories(&world);
    the_engine_publishes_by_opening_a_change(&world);

    // `landed` opens the change request that carries the work, and `broken` is the
    // node whose record goes stale: its dispatch opens a change request of its own
    // that nobody merges, so the run records it done and unlanded on a branch the
    // work never reached a base from. `hold` keeps the run driven throughout.
    let mut landed = engine();
    landed["id"] = json!("landed");
    let mut broken = engine();
    broken["id"] = json!("broken");
    broken["deps"] = json!(["landed"]);
    world.script("hold.wait", "hold");
    let run = start(&world, name, vec![landed, broken, agent("hold", &[])]);
    world.until("the broken node to settle", |world| {
        settled_status(world, &run, "broken") == Some("done".to_owned())
    });
    let superseded = change_url_of(&world, &run, "broken");
    let project = format!("plans:{}", project_id(name));
    let board = |world: &World| {
        world
            .store_tasks(&project)
            .into_iter()
            .find(|task| task["item"]["metadata"]["onepipeline.id"] == "broken")
            .map(|task| task["item"]["metadata"].clone())
    };
    world.until_store("the superseded change to reach the board", |world| {
        board(world).is_some_and(|metadata| {
            metadata["onepipeline.landing"] == "unlanded"
                && metadata["onepipeline.change_url"] == json!(superseded)
        })
    });

    // A person merges the work — `landed`'s change — and every surface is read
    // before the manager states it, so what moves afterwards is the statement alone.
    let branch = branch_of(&world, &run, "landed");
    let landing = match spelling {
        Spelling::Commit => squash_land(&world, &engine_repo.checkout, &branch),
        Spelling::ChangeRequest => {
            land(&world, &engine_repo.checkout, &branch);
            change_url_of(&world, &run, "landed")
        }
    };
    let before = world.run(&["results", &run]);
    before.exited(0);
    assert!(
        line_about(&before.stdout, "broken").contains("NOT landed"),
        "the superseded branch was not read as unlanded before the statement:\n{}",
        before.stdout
    );
    let counted = not_landed_in_listing(&world, &run);
    assert!(
        counted >= 1,
        "the listing counted no unlanded work before the statement"
    );

    // Settled again at the outcome it already holds: stating where the work landed
    // is a correction, not a duplicate.
    let settled = world.run_with_stdin(
        &["reply", &run],
        &json!({"version": onepipeline::channel::REPLY_ENVELOPE_VERSION, "commands": [{
            "op": "settle", "id": "broken", "outcome": "done",
            "evidence": "the work merged in the other change; this node's own was superseded",
            "landing": landing,
        }]})
        .to_string(),
    );
    settled.exited(0).out_has("\"applied\"");
    // No release is declared for this repository, so there is no release to warn of.
    settled.err_lacks("release baseline");

    // `results`: landed, on the stated tier, at the stated reference — and no
    // verdict read off the superseded branch beside it.
    let stated = format!(
        "landed on its base — {}: stated from evidence at {landing}",
        tier_of(spelling)
    );
    let results = world.until_read(
        "results to read the stated landing",
        false,
        |world| world.run(&["results", &run]),
        |results| line_about(&results.stdout, "broken").contains(&stated),
    );
    let line = line_about(&results.stdout, "broken");
    for contradiction in ["NOT landed", "UNDECIDED", "the run observed"] {
        assert!(
            !line.contains(contradiction),
            "the stated landing was contradicted by `{contradiction}`: {line}"
        );
    }

    // `status`: not counted as work that has not landed, nor as undecided.
    let status = world.run(&["status", &run]);
    status.exited(0);
    assert!(
        !status.stdout.lines().any(|line| {
            (line.contains("have not landed") || line.contains("could not decide"))
                && line.contains("broken")
        }),
        "status counts a node settled at its landing as outstanding:\n{}",
        status.stdout
    );

    // `runs`, served off the summary document: one fewer node not landed.
    world.until("the listing to count the stated landing", |world| {
        not_landed_in_listing(world, &run) == counted - 1
    });

    // The board: the same interpretation, with the tier and the stated reference in
    // place of the superseded change the run had recorded.
    world.until_store("the stated landing to reach the board", |world| {
        board(world).is_some_and(|metadata| {
            let referenced = match spelling {
                Spelling::Commit => {
                    metadata["onepipeline.landing_commit"] == json!(landing)
                        && metadata.get("onepipeline.change_url").is_none()
                }
                Spelling::ChangeRequest => metadata["onepipeline.change_url"] == json!(landing),
            };
            metadata["onepipeline.landing"] == "landed"
                && metadata["onepipeline.landing_evidence"] == tier_of(spelling)
                && referenced
        })
    });
    assert_ne!(landing, superseded);

    world.release("hold.go");
    world.until("the run to settle", |world| {
        world.run_file(&run, "result.json").is_file()
    });
    // And the run's own result, written as it closed, says the same.
    let result = world.run_json(&run, "result.json");
    let settled = result["nodes"]
        .as_array()
        .and_then(|nodes| nodes.iter().find(|node| node["id"] == "broken"))
        .unwrap_or_else(|| panic!("the result names no broken node: {result}"));
    assert_eq!(settled["landing"], json!("landed"), "{settled}");
}

```

### `adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/adoption_check.rs`):

```rust

fn every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired() {
    let (world, script, _) = world("adoption-check-edits", false);
    let mut parked = lifecycle("requeued", &["engine"]);
    parked["parked"] = json!(true);
    parked["consumes"] = json!({"engine": "crate"});
    let mut rewired = lifecycle("rewired", &[]);
    rewired["parked"] = json!(true);
    rewired["adoption"] = json!("published");
    let mut rewired_fast = lifecycle("rewired-fast", &[]);
    rewired_fast["parked"] = json!(true);
    // In the producer's own repository, which is no release wait until a `requeue`
    // moves it.
    let mut moved = lifecycle("moved", &["engine"]);
    moved["parked"] = json!(true);
    moved["repo"] = json!("engine");
    moved["adoption"] = json!("published");
    let mut promoted = lifecycle("promoted", &["engine"]);
    promoted["parked"] = json!(true);
    let mut drifting = lifecycle("drifting", &["engine"]);
    drifting["parked"] = json!(true);
    drifting["consumes"] = json!({"engine": "crate"});
    world.script("flaky.fail", "1");
    world.script("engine.wait", "hold");
    let run = "edited";
    let path = world.plan(
        run,
        &plan_of(
            run,
            vec![
                engine(),
                agent("flaky", &[]),
                parked,
                rewired,
                rewired_fast,
                moved,
                promoted,
                drifting,
            ],
        ),
    );
    world.run(&["start", &path, "--detach"]).exited(0);
    world.until("the node to retry to fail", |world| {
        world.events_of(run, "node-settled").iter().any(|event| {
            event["labels"]["node"] == "flaky" && event["payload"]["status"] == "failed"
        })
    });

    let published = one_rule(&world, &["--adoption", "published"], "published-no-target");
    let undeclared = one_rule(
        &world,
        &["--consumes", "wheel"],
        "consumes-undeclared-target",
    );
    let reply = |command: Value| {
        world.run_with_stdin(
            &["reply", run],
            &json!({"version": 2, "commands": [command]}).to_string(),
        )
    };
    let committed = |world: &World| world.events_of(run, "edit-committed").len();

    // (the edit refused, the line it is refused with, the same edit repaired)
    let edits = [
        (
            json!({"op": "add", "node": consumer("added", json!({"adoption": "published"}))}),
            line("added", "adoption", "published-no-target", &published),
            json!({"op": "add", "node": consumer("added",
                json!({"adoption": "published", "consumes": {"engine": "crate"}}))}),
        ),
        (
            json!({"op": "retry", "id": "flaky", "node": consumer("retried",
                json!({"consumes": {"engine": "wheel"}}))}),
            line(
                "retried",
                "consumes",
                "consumes-undeclared-target",
                &undeclared,
            ),
            json!({"op": "retry", "id": "flaky", "node": consumer("retried",
                json!({"consumes": {"engine": "crate"}}))}),
        ),
        (
            json!({"op": "requeue", "id": "requeued", "amend": {"consumes": {"engine": "wheel"}}}),
            line(
                "requeued",
                "consumes",
                "consumes-undeclared-target",
                &undeclared,
            ),
            json!({"op": "requeue", "id": "requeued", "amend": {"adoption": "published"}}),
        ),
        (
            json!({"op": "requeue", "id": "promoted", "amend": {"adoption": "published"}}),
            line("promoted", "adoption", "published-no-target", &published),
            json!({"op": "requeue", "id": "promoted",
                "amend": {"adoption": "published", "consumes": {"engine": "crate"}}}),
        ),
        (
            json!({"op": "requeue", "id": "moved", "amend": {"repo": "service"}}),
            line("moved", "adoption", "published-no-target", &published),
            json!({"op": "requeue", "id": "moved",
                "amend": {"repo": "service", "consumes": {"engine": "crate"}}}),
        ),
        (
            json!({"op": "reparent", "id": "rewired", "deps": ["engine"]}),
            line("rewired", "adoption", "published-no-target", &published),
            json!({"op": "reparent", "id": "rewired-fast", "deps": ["engine"]}),
        ),
    ];
    for (refused, said, repaired) in edits {
        let before = committed(&world);
        let status = world.run(&["status", run, "--json"]).json();
        reply(refused.clone()).exited(REFUSED).err_has(&said);
        assert_eq!(committed(&world), before, "a refused {refused} committed");
        assert_eq!(
            world.run(&["status", run, "--json"]).json()["nodes"],
            status["nodes"],
            "a refused {refused} changed the run"
        );
        reply(repaired.clone()).exited(0).err_lacks("onevcs:");
        world.until("the repaired edit to commit", |world| {
            committed(world) == before + 1
        });
    }

    // The host's declaration moves under the run: `engine` now releases `wheel`, so the
    // `added` node consuming `crate` can no longer complete.
    world.releases(&releasing(&script, "wheel", false));
    let stranded = one_rule(
        &world,
        &["--consumes", "crate"],
        "consumes-undeclared-target",
    );
    let before = committed(&world);
    reply(json!({"op": "add", "node": agent("unrelated", &[])}))
        .exited(0)
        .err_lacks("onevcs:");
    world.until("the unrelated add to commit", |world| {
        committed(world) == before + 1
    });
    // The added node runs to `done` on its own; snapshot the run only once it has, so
    // the comparison below sees what the refused edits did and not the driver's progress.
    world.until("the unrelated node to finish", |world| {
        world.run(&["status", run, "--json"]).json()["nodes"]
            .as_array()
            .is_some_and(|nodes| {
                nodes
                    .iter()
                    .any(|node| node["id"] == "unrelated" && node["status"] == "done")
            })
    });
    let status = world.run(&["status", run, "--json"]).json();
    reply(json!({"op": "reparent", "id": "added", "deps": ["engine"]}))
        .exited(REFUSED)
        .err_has(&line(
            "added",
            "consumes",
            "consumes-undeclared-target",
            &stranded,
        ));
    // A requeue stating only the publication policy is asked about too, and the
    // drifted `consumes` it carries refuses it.
    reply(json!({"op": "requeue", "id": "drifting", "amend": {"merge_policy": "change-auto"}}))
        .exited(REFUSED)
        .err_has(&line(
            "drifting",
            "consumes",
            "consumes-undeclared-target",
            &stranded,
        ));
    assert_eq!(committed(&world), before + 1, "a refused edit committed");
    assert_eq!(
        world.run(&["status", run, "--json"]).json()["nodes"],
        status["nodes"],
        "a refused edit changed the run"
    );
}

```

After (af3fdcd9, `tests/e2e/adoption_check.rs`):

```rust

fn every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired() {
    let (world, script, _) = world("adoption-check-edits", false);
    let mut parked = lifecycle("requeued", &["engine"]);
    parked["parked"] = json!(true);
    parked["consumes"] = json!({"engine": "crate"});
    let mut rewired = lifecycle("rewired", &[]);
    rewired["parked"] = json!(true);
    rewired["adoption"] = json!("published");
    let mut rewired_fast = lifecycle("rewired-fast", &[]);
    rewired_fast["parked"] = json!(true);
    // In the producer's own repository, which is no release wait until a `requeue`
    // moves it.
    let mut moved = lifecycle("moved", &["engine"]);
    moved["parked"] = json!(true);
    moved["repo"] = json!("engine");
    moved["adoption"] = json!("published");
    let mut promoted = lifecycle("promoted", &["engine"]);
    promoted["parked"] = json!(true);
    let mut drifting = lifecycle("drifting", &["engine"]);
    drifting["parked"] = json!(true);
    drifting["consumes"] = json!({"engine": "crate"});
    world.script("flaky.fail", "1");
    world.script("engine.wait", "hold");
    let run = "edited";
    let path = world.plan(
        run,
        &plan_of(
            run,
            vec![
                engine(),
                agent("flaky", &[]),
                parked,
                rewired,
                rewired_fast,
                moved,
                promoted,
                drifting,
            ],
        ),
    );
    world.run(&["start", &path, "--detach"]).exited(0);
    world.until("the node to retry to fail", |world| {
        world.events_of(run, "node-settled").iter().any(|event| {
            event["labels"]["node"] == "flaky" && event["payload"]["status"] == "failed"
        })
    });

    let published = one_rule(&world, &["--adoption", "published"], "published-no-target");
    let undeclared = one_rule(
        &world,
        &["--consumes", "wheel"],
        "consumes-undeclared-target",
    );
    let reply = |command: Value| {
        world.run_with_stdin(
            &["reply", run],
            &json!({"version": 2, "commands": [command]}).to_string(),
        )
    };
    let committed = |world: &World| world.events_of(run, "edit-committed").len();

    // (the edit refused, the line it is refused with, the same edit repaired)
    let edits = [
        (
            json!({"op": "add", "node": consumer("added", json!({"adoption": "published"}))}),
            line("added", "adoption", "published-no-target", &published),
            json!({"op": "add", "node": consumer("added",
                json!({"adoption": "published", "consumes": {"engine": "crate"}}))}),
        ),
        (
            json!({"op": "retry", "id": "flaky", "node": consumer("retried",
                json!({"consumes": {"engine": "wheel"}}))}),
            line(
                "retried",
                "consumes",
                "consumes-undeclared-target",
                &undeclared,
            ),
            json!({"op": "retry", "id": "flaky", "node": consumer("retried",
                json!({"consumes": {"engine": "crate"}}))}),
        ),
        (
            json!({"op": "requeue", "id": "requeued", "amend": {"consumes": {"engine": "wheel"}}}),
            line(
                "requeued",
                "consumes",
                "consumes-undeclared-target",
                &undeclared,
            ),
            json!({"op": "requeue", "id": "requeued", "amend": {"adoption": "published"}}),
        ),
        (
            json!({"op": "requeue", "id": "promoted", "amend": {"adoption": "published"}}),
            line("promoted", "adoption", "published-no-target", &published),
            json!({"op": "requeue", "id": "promoted",
                "amend": {"adoption": "published", "consumes": {"engine": "crate"}}}),
        ),
        (
            json!({"op": "requeue", "id": "moved", "amend": {"repo": "service"}}),
            line("moved", "adoption", "published-no-target", &published),
            json!({"op": "requeue", "id": "moved",
                "amend": {"repo": "service", "consumes": {"engine": "crate"}}}),
        ),
        (
            json!({"op": "reparent", "id": "rewired", "deps": ["engine"]}),
            line("rewired", "adoption", "published-no-target", &published),
            json!({"op": "reparent", "id": "rewired-fast", "deps": ["engine"]}),
        ),
    ];
    for (refused, said, repaired) in edits {
        let before = committed(&world);
        let status = world.run(&["status", run, "--json"]).json();
        reply(refused.clone()).exited(REFUSED).err_has(&said);
        assert_eq!(committed(&world), before, "a refused {refused} committed");
        assert_eq!(
            world.run(&["status", run, "--json"]).json()["nodes"],
            status["nodes"],
            "a refused {refused} changed the run"
        );
        reply(repaired.clone()).exited(0).err_lacks("onevcs:");
        world.until("the repaired edit to commit", |world| {
            committed(world) == before + 1
        });
    }

    // The host's declaration moves under the run: `engine` now releases `wheel`, so the
    // `added` node consuming `crate` can no longer complete.
    world.releases(&releasing(&script, "wheel", false));
    let stranded = one_rule(
        &world,
        &["--consumes", "crate"],
        "consumes-undeclared-target",
    );
    let before = committed(&world);
    reply(json!({"op": "add", "node": agent("unrelated", &[])}))
        .exited(0)
        .err_lacks("onevcs:");
    world.until("the unrelated add to commit", |world| {
        committed(world) == before + 1
    });
    // The added node runs to `done` on its own; snapshot the run only once it has, so
    // the comparison below sees what the refused edits did and not the driver's progress.
    let status = world
        .until_read(
            "the unrelated node to finish",
            false,
            |world| world.run(&["status", run, "--json"]),
            |read| {
                read.json()["nodes"].as_array().is_some_and(|nodes| {
                    nodes
                        .iter()
                        .any(|node| node["id"] == "unrelated" && node["status"] == "done")
                })
            },
        )
        .json();
    reply(json!({"op": "reparent", "id": "added", "deps": ["engine"]}))
        .exited(REFUSED)
        .err_has(&line(
            "added",
            "consumes",
            "consumes-undeclared-target",
            &stranded,
        ));
    // A requeue stating only the publication policy is asked about too, and the
    // drifted `consumes` it carries refuses it.
    reply(json!({"op": "requeue", "id": "drifting", "amend": {"merge_policy": "change-auto"}}))
        .exited(REFUSED)
        .err_has(&line(
            "drifting",
            "consumes",
            "consumes-undeclared-target",
            &stranded,
        ));
    assert_eq!(committed(&world), before + 1, "a refused edit committed");
    assert_eq!(
        world.run(&["status", run, "--json"]).json()["nodes"],
        status["nodes"],
        "a refused edit changed the run"
    );
}

```

### `command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/command_step.rs`):

```rust

fn a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents() {
    let world = World::new("command-step-fails");
    let failing = script(
        &world,
        "fail",
        "echo 'checked 4 of 5 things' >&2\necho 'the fifth broke: no config' >&2\nexit 3",
    );
    let project = world.plan(
        "commandfails",
        &plan_of(
            "commandfails",
            vec![command("check", &[], &failing), agent("after", &["check"])],
        ),
    );
    world.run(&["start", &project, "--attach"]).settled();
    let run = "commandfails";
    let read = world.run(&["results", run, "--json"]);
    let document: Value = serde_json::from_str(&read.stdout).expect("results --json is JSON");
    assert_eq!(document["schema_version"], stated("results_schema_version"));
    let settled = result(&world, run, "check");
    assert_eq!(settled["status"], "failed", "{settled}");
    assert_eq!(
        settled["outcome"],
        json!(word("outcomes", "failed")),
        "{settled}"
    );
    let detail = settled["detail"].as_str().expect("a detail");
    assert!(detail.contains("status 3"), "{detail}");
    assert!(detail.contains("the fifth broke: no config"), "{detail}");
    assert!(
        !dispatched(&world, run, "after"),
        "a dependent of a failed command ran"
    );
    assert_ne!(result(&world, run, "after")["status"], "done");
}

```

After (af3fdcd9, `tests/e2e/command_step.rs`):

```rust

fn a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents() {
    let world = World::new("command-step-fails");
    let failing = script(
        &world,
        "fail",
        "echo 'checked 4 of 5 things' >&2\necho 'the fifth broke: no config' >&2\nexit 3",
    );
    let project = world.plan(
        "commandfails",
        &plan_of(
            "commandfails",
            vec![command("check", &[], &failing), agent("after", &["check"])],
        ),
    );
    world.run(&["start", &project, "--attach"]).settled();
    let run = "commandfails";
    let read = world.run(&["results", run, "--json"]);
    let document: Value = serde_json::from_str(&read.stdout).expect("results --json is JSON");
    assert_eq!(document["schema_version"], stated("results_schema_version"));
    let results = Results::already(&world, run, &document);
    let settled = results.node("check");
    assert_eq!(settled["status"], "failed", "{settled}");
    assert_eq!(
        settled["outcome"],
        json!(word("outcomes", "failed")),
        "{settled}"
    );
    let detail = settled["detail"].as_str().expect("a detail");
    assert!(detail.contains("status 3"), "{detail}");
    assert!(detail.contains("the fifth broke: no config"), "{detail}");
    assert!(
        !dispatched(&world, run, "after"),
        "a dependent of a failed command ran"
    );
    assert_ne!(results.node("after")["status"], "done");
}

```

### `command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/command_step.rs`):

```rust

fn a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end() {
    let world = World::new("command-step-timeout");
    let pid = at(&world, "sleeper.pid");
    let child = at(&world, "sleeper.child");
    // It waits on a child of its own, so what is stopped is a tree and not one process.
    let sleeper = script(
        &world,
        "sleeper",
        &format!("echo $$ > '{pid}'\nsleep 60 &\necho $! > '{child}'\nwait"),
    );
    let patient = script(&world, "patient", "sleep 4\necho finished");
    let mut bounded = command("bounded", &[], &sleeper);
    bounded["timeout_seconds"] = json!(2);
    let project = world.plan(
        "commandtimeout",
        &plan_of(
            "commandtimeout",
            vec![bounded, command("unbounded", &[], &patient)],
        ),
    );
    let started = std::time::Instant::now();
    world.run(&["start", &project, "--attach"]).settled();
    let run = "commandtimeout";
    assert!(
        started.elapsed() < std::time::Duration::from_secs(50),
        "the run waited out the command rather than its timeout"
    );
    let timed_out = result(&world, run, "bounded");
    assert_eq!(timed_out["status"], "failed", "{timed_out}");
    assert_eq!(
        timed_out["outcome"],
        json!(word("outcomes", "timed_out")),
        "{timed_out}"
    );
    assert!(
        world
            .events_of(run, "command-exited")
            .iter()
            .any(|event| event["labels"]["node"] == "bounded"
                && event["payload"]["ending"] == "timed-out"
                && listed("endings", "timed-out")),
        "{}",
        world.dump()
    );
    assert_eq!(result(&world, run, "unbounded")["status"], "done");
    for process in ["sleeper.pid", "sleeper.child"] {
        assert!(
            !still_running(&world, process),
            "the command's {process} outlived its timeout"
        );
    }
}

```

After (af3fdcd9, `tests/e2e/command_step.rs`):

```rust

fn a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end() {
    let world = World::new("command-step-timeout");
    let pid = at(&world, "sleeper.pid");
    let child = at(&world, "sleeper.child");
    // It waits on a child of its own, so what is stopped is a tree and not one process.
    let sleeper = script(
        &world,
        "sleeper",
        &format!("echo $$ > '{pid}'\nsleep 60 &\necho $! > '{child}'\nwait"),
    );
    let patient = script(&world, "patient", "sleep 4\necho finished");
    let mut bounded = command("bounded", &[], &sleeper);
    bounded["timeout_seconds"] = json!(2);
    let project = world.plan(
        "commandtimeout",
        &plan_of(
            "commandtimeout",
            vec![bounded, command("unbounded", &[], &patient)],
        ),
    );
    let started = std::time::Instant::now();
    world.run(&["start", &project, "--attach"]).settled();
    let run = "commandtimeout";
    assert!(
        started.elapsed() < std::time::Duration::from_secs(50),
        "the run waited out the command rather than its timeout"
    );
    let results = Results::of(&world, run);
    let timed_out = results.node("bounded");
    assert_eq!(timed_out["status"], "failed", "{timed_out}");
    assert_eq!(
        timed_out["outcome"],
        json!(word("outcomes", "timed_out")),
        "{timed_out}"
    );
    assert!(
        world
            .events_of(run, "command-exited")
            .iter()
            .any(|event| event["labels"]["node"] == "bounded"
                && event["payload"]["ending"] == "timed-out"
                && listed("endings", "timed-out")),
        "{}",
        world.dump()
    );
    assert_eq!(results.node("unbounded")["status"], "done");
    for process in ["sleeper.pid", "sleeper.child"] {
        assert!(
            !still_running(&world, process),
            "the command's {process} outlived its timeout"
        );
    }
}

```

### `command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/command_step.rs`):

```rust

fn a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed() {
    let world = World::new("command-step-endings");
    let launch_dir = world.root.join("launched-here");
    std::fs::create_dir_all(&launch_dir).expect("a launch directory");
    let cwd = at(&world, "chatty.cwd");
    let chatty = script(
        &world,
        "chatty",
        &format!(
            "pwd > '{cwd}'\necho 'EARLY-MARKER' >&2\n\
             i=0; while [ $i -lt 100 ]; do echo 'padding padding padding padding padding' >&2; \
             i=$((i+1)); done\necho 'LATE-MARKER' >&2\nexit 1"
        ),
    );
    // A program named relative to the launch directory is the file beside the launch.
    let beside = posix_script(&launch_dir, "beside", "echo 'ran beside the launch'");
    let mut nodes = vec![
        command("missing", &[], &world.root.join("no-such-program")),
        command("chatty", &[], &chatty),
        json!({"id": "relative", "kind": "command", "command": [format!(
            "./{}",
            beside.file_name().expect("a file").to_string_lossy()
        )]}),
    ];
    if cfg!(unix) {
        nodes.push(command(
            "signalled",
            &[],
            &script(&world, "signalled", "kill -9 $$"),
        ));
    }
    let project = world.plan("commandendings", &plan_of("commandendings", nodes));
    world
        .run_from(&launch_dir, &["start", &project, "--attach"])
        .settled();
    let run = "commandendings";
    let failed = word("outcomes", "failed");

    let missing = result(&world, run, "missing");
    assert_eq!(missing["outcome"], json!(failed), "{missing}");
    assert!(
        missing["detail"]
            .as_str()
            .expect("a detail")
            .contains("could not be started"),
        "{missing}"
    );
    assert!(listed("endings", "not-started"));
    assert!(world
        .events_of(run, "command-exited")
        .iter()
        .any(|event| event["labels"]["node"] == "missing"
            && event["payload"]["ending"] == "not-started"));

    assert_eq!(result(&world, run, "relative")["status"], "done");
    let said = result(&world, run, "chatty");
    let detail = said["detail"].as_str().expect("a detail");
    assert_eq!(said["outcome"], json!(failed), "{said}");
    assert!(detail.contains("LATE-MARKER"), "{detail}");
    assert!(
        !detail.contains("EARLY-MARKER"),
        "the detail kept more than the end of stderr: {detail}"
    );
    let log = std::fs::read_to_string(log_of(&world, run, "chatty")).expect("its log");
    assert!(
        log.contains("EARLY-MARKER") && log.contains("LATE-MARKER"),
        "{log}"
    );
    #[cfg(unix)]
    {
        let ran_in = std::fs::read_to_string(world.root.join("chatty.cwd")).expect("its cwd");
        assert_eq!(
            std::fs::canonicalize(ran_in.trim()).expect("a directory"),
            std::fs::canonicalize(&launch_dir).expect("a directory"),
            "the command did not run from the launch directory"
        );
        let signalled = result(&world, run, "signalled");
        assert_eq!(signalled["outcome"], json!(failed), "{signalled}");
        assert!(
            signalled["detail"]
                .as_str()
                .expect("a detail")
                .contains("ended by a signal"),
            "{signalled}"
        );
    }
}

```

After (af3fdcd9, `tests/e2e/command_step.rs`):

```rust

fn a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed() {
    let world = World::new("command-step-endings");
    let launch_dir = world.root.join("launched-here");
    std::fs::create_dir_all(&launch_dir).expect("a launch directory");
    let cwd = at(&world, "chatty.cwd");
    let chatty = script(
        &world,
        "chatty",
        &format!(
            "pwd > '{cwd}'\necho 'EARLY-MARKER' >&2\n\
             i=0; while [ $i -lt 100 ]; do echo 'padding padding padding padding padding' >&2; \
             i=$((i+1)); done\necho 'LATE-MARKER' >&2\nexit 1"
        ),
    );
    // A program named relative to the launch directory is the file beside the launch.
    let beside = posix_script(&launch_dir, "beside", "echo 'ran beside the launch'");
    let mut nodes = vec![
        command("missing", &[], &world.root.join("no-such-program")),
        command("chatty", &[], &chatty),
        json!({"id": "relative", "kind": "command", "command": [format!(
            "./{}",
            beside.file_name().expect("a file").to_string_lossy()
        )]}),
    ];
    if cfg!(unix) {
        nodes.push(command(
            "signalled",
            &[],
            &script(&world, "signalled", "kill -9 $$"),
        ));
    }
    let project = world.plan("commandendings", &plan_of("commandendings", nodes));
    world
        .run_from(&launch_dir, &["start", &project, "--attach"])
        .settled();
    let run = "commandendings";
    let failed = word("outcomes", "failed");

    let results = Results::of(&world, run);
    let missing = results.node("missing");
    assert_eq!(missing["outcome"], json!(failed), "{missing}");
    assert!(
        missing["detail"]
            .as_str()
            .expect("a detail")
            .contains("could not be started"),
        "{missing}"
    );
    assert!(listed("endings", "not-started"));
    assert!(world
        .events_of(run, "command-exited")
        .iter()
        .any(|event| event["labels"]["node"] == "missing"
            && event["payload"]["ending"] == "not-started"));

    assert_eq!(results.node("relative")["status"], "done");
    let said = results.node("chatty");
    let detail = said["detail"].as_str().expect("a detail");
    assert_eq!(said["outcome"], json!(failed), "{said}");
    assert!(detail.contains("LATE-MARKER"), "{detail}");
    assert!(
        !detail.contains("EARLY-MARKER"),
        "the detail kept more than the end of stderr: {detail}"
    );
    let log = std::fs::read_to_string(log_of(&world, run, "chatty")).expect("its log");
    assert!(
        log.contains("EARLY-MARKER") && log.contains("LATE-MARKER"),
        "{log}"
    );
    #[cfg(unix)]
    {
        let ran_in = std::fs::read_to_string(world.root.join("chatty.cwd")).expect("its cwd");
        assert_eq!(
            std::fs::canonicalize(ran_in.trim()).expect("a directory"),
            std::fs::canonicalize(&launch_dir).expect("a directory"),
            "the command did not run from the launch directory"
        );
        let signalled = results.node("signalled");
        assert_eq!(signalled["outcome"], json!(failed), "{signalled}");
        assert!(
            signalled["detail"]
                .as_str()
                .expect("a detail")
                .contains("ended by a signal"),
            "{signalled}"
        );
    }
}

```

### `command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/command_step.rs`):

```rust

fn a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before() {
    let world = World::new("command-step-unchanged");
    let config = world.root.join("launch-13.json");
    std::fs::write(
        &config,
        json!({"schema_version": 13, "node_sets": ["members.worker.agent.model=node"]}).to_string(),
    )
    .expect("the launch config is written");
    let project = world.plan(
        "unchanged",
        &plan_of(
            "unchanged",
            vec![
                agent("build", &[]),
                human("approve", &["build"]),
                agent("ship", &["approve"]),
            ],
        ),
    );
    world
        .run(&[
            "start",
            &project,
            "--detach",
            "--launch-config",
            &config.display().to_string(),
        ])
        .exited(0);
    let run = "unchanged";
    world.until("the run to pause on the approval", |world| {
        settled_as(world, run, "approve", "waiting")
            && world.run(&["status", run]).stdout.contains("PAUSED")
    });
    assert!(settled_as(&world, run, "build", "done"));
    assert!(!dispatched(&world, run, "ship"));
    world.run(&["attest", run, "approve"]).exited(0);
    world.run(&["adopt", run]).exited(0);
    for node in ["build", "approve", "ship"] {
        assert_eq!(result(&world, run, node)["status"], "done", "{node}");
    }
    let kinds = world.kinds(run);
    assert!(
        !kinds.iter().any(|kind| kind.starts_with("command-")),
        "{kinds:?}"
    );
    assert!(world
        .run_json(run, "launch.json")
        .get("plan_edit_hook")
        .is_none());
}

```

After (af3fdcd9, `tests/e2e/command_step.rs`):

```rust

fn a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before() {
    let world = World::new("command-step-unchanged");
    let config = world.root.join("launch-13.json");
    std::fs::write(
        &config,
        json!({"schema_version": 13, "node_sets": ["members.worker.agent.model=node"]}).to_string(),
    )
    .expect("the launch config is written");
    let project = world.plan(
        "unchanged",
        &plan_of(
            "unchanged",
            vec![
                agent("build", &[]),
                human("approve", &["build"]),
                agent("ship", &["approve"]),
            ],
        ),
    );
    world
        .run(&[
            "start",
            &project,
            "--detach",
            "--launch-config",
            &config.display().to_string(),
        ])
        .exited(0);
    let run = "unchanged";
    world.until("the run to pause on the approval", |world| {
        settled_as(world, run, "approve", "waiting")
            && world.run(&["status", run]).stdout.contains("PAUSED")
    });
    assert!(settled_as(&world, run, "build", "done"));
    assert!(!dispatched(&world, run, "ship"));
    world.run(&["attest", run, "approve"]).exited(0);
    world.run(&["adopt", run]).exited(0);
    let results = Results::of(&world, run);
    for node in ["build", "approve", "ship"] {
        assert_eq!(results.node(node)["status"], "done", "{node}");
    }
    let kinds = world.kinds(run);
    assert!(
        !kinds.iter().any(|kind| kind.starts_with("command-")),
        "{kinds:?}"
    );
    assert!(world
        .run_json(run, "launch.json")
        .get("plan_edit_hook")
        .is_none());
}

```

### `landing::the_counting_views_report_what_a_read_taken_now_says`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/landing.rs`):

```rust

fn the_counting_views_report_what_a_read_taken_now_says() {
    let Fixture { world, run } = fixture("landing-counts");

    // `goals` and `runs` are the summary line; `status` carries it too, above its
    // own per-node lines.
    for view in [
        world.run(&["goals", &run]),
        world.run(&["runs"]),
        world.run(&["status", &run]),
    ] {
        view.exited(0);
        assert!(
            view.stdout.contains("2 not landed, 1 landing undecided"),
            "the count carries the settlement's answer rather than a read:\n{}",
            view.stdout
        );
    }
    let status = world.run(&["status", &run]);
    status.exited(0);
    status.out_has("2 node(s) have not landed: landed-in-part, still-open");
    status.out_has("1 node(s) whose landing this host could not decide: merged-quietly");
    // The three that landed are on neither line.
    for landed in [RECORDED_LANDED, "merged-since", "failed-but-landed"] {
        assert!(
            !status.stdout.contains(landed),
            "{landed} is on its base and is still reported as outstanding:\n{}",
            status.stdout
        );
    }
}

```

After (af3fdcd9, `tests/e2e/landing.rs`):

```rust

fn the_counting_views_report_what_a_read_taken_now_says() {
    let Fixture { world, run } = fixture("landing-counts");

    // `goals` and `runs` are the summary line; `status` carries it too, above its
    // own per-node lines.
    let mut views = vec![
        world.run(&["goals", &run]),
        world.run(&["runs"]),
        world.run(&["status", &run]),
    ];
    for view in &views {
        view.exited(0);
        assert!(
            view.stdout.contains("2 not landed, 1 landing undecided"),
            "the count carries the settlement's answer rather than a read:\n{}",
            view.stdout
        );
    }
    // Measurement only (spike-child-waits, never lands): under the re-launch prototype
    // the `status` read above is the one these lines are asserted on.
    let status = if crate::harness::spike_variant::relaunch() {
        views.pop().expect("the status read")
    } else {
        world.run(&["status", &run])
    };
    status.exited(0);
    status.out_has("2 node(s) have not landed: landed-in-part, still-open");
    status.out_has("1 node(s) whose landing this host could not decide: merged-quietly");
    // The three that landed are on neither line.
    for landed in [RECORDED_LANDED, "merged-since", "failed-but-landed"] {
        assert!(
            !status.stdout.contains(landed),
            "{landed} is on its base and is still reported as outstanding:\n{}",
            status.stdout
        );
    }
}

```

### `live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/live_edit.rs`):

```rust

fn a_run_wide_set_edit_is_replayed_when_a_driver_adopts() {
    let world = World::new("edit-sets-adopt");
    world.script("held.wait", "hold");
    let path = world.plan(
        "sets-adopted",
        &plan_of(
            "sets-adopted",
            vec![
                human("approve", &[]),
                agent("held", &[]),
                agent("build", &["approve", "held"]),
            ],
        ),
    );
    world
        .run(&[
            "start",
            &path,
            "--detach",
            "--dag-graph",
            &world.shipped_dag_graph(),
            "--set",
            "members.monitor.agent.model=observer",
        ])
        .exited(0);
    world.until("the held node to start", |world| {
        world
            .events_of("sets-adopted", "node-dispatched")
            .iter()
            .any(|event| event["labels"]["node"] == "held")
    });
    let edited = json!({"version":3,"commands":[
        {"op":"set-run-node-sets","sets":["members.worker.agent.model=adopted=value"]}
    ]});
    world
        .run_with_stdin(&["reply", "sets-adopted"], &edited.to_string())
        .exited(0);
    world.until("the live driver to commit the edit", |world| {
        committed(world, "sets-adopted").contains(&"set-run-node-sets".to_string())
    });
    world.release("held.go");
    world.until("the blocked driver to exit", |world| {
        world
            .run(&["status", "sets-adopted"])
            .stdout
            .contains("PAUSED")
    });
    world.run(&["status", "sets-adopted"]).exited(0);
    let checkpoint = world.run_json("sets-adopted", "checkpoint.json");
    assert_eq!(
        checkpoint["state"]["run_node_sets"],
        json!(["members.worker.agent.model=adopted=value"]),
        "the usable checkpoint did not fold the edit: {checkpoint}"
    );
    assert!(
        checkpoint["coverage"]["records"]
            .as_u64()
            .is_some_and(|count| count > 0),
        "the checkpoint covers no journal records: {checkpoint}"
    );
    world.run(&["attest", "sets-adopted", "approve"]).exited(0);
    world.run(&["adopt", "sets-adopted"]).exited(0);
    let launch = world.run_json("sets-adopted", "launch.json");
    assert!(
        launch["node_sets"].is_null(),
        "launch remains the baseline: {launch}"
    );
    assert_eq!(
        launch["dag_sets"],
        json!(["members.monitor.agent.model=observer"])
    );
    let dags: Vec<_> = world
        .invocations()
        .into_iter()
        .filter(|call| {
            call["tool"] == "oneagentgraph"
                && call["args"].as_array().is_some_and(|args| {
                    args.iter()
                        .any(|arg| arg.as_str().is_some_and(|s| s.ends_with("dag-scope.yaml")))
                })
        })
        .collect();
    assert!(
        dags.len() >= 2,
        "start and adopt launched the dag observer: {dags:?}"
    );
    for dag in dags {
        assert!(
            dag["args"]
                .as_array()
                .expect("argv")
                .windows(2)
                .any(|pair| {
                    pair[0] == "--set" && pair[1] == "members.monitor.agent.model=observer"
                }),
            "a dag observer lost its original overrides: {dag}"
        );
    }
    let call = world
        .invocations()
        .into_iter()
        .find(|call| {
            call["tool"] == "oneagentgraph"
                && call["args"]
                    .as_array()
                    .is_some_and(|args| args.iter().any(|arg| arg == "onepipeline.node=build"))
        })
        .expect("adoption dispatched build");
    assert!(
        call["args"]
            .as_array()
            .expect("argv")
            .windows(2)
            .any(|pair| {
                pair[0] == "--set" && pair[1] == "members.worker.agent.model=adopted=value"
            }),
        "the adopted dispatch lost the edit: {call}"
    );
}

```

After (af3fdcd9, `tests/e2e/live_edit.rs`):

```rust

fn a_run_wide_set_edit_is_replayed_when_a_driver_adopts() {
    let world = World::new("edit-sets-adopt");
    world.script("held.wait", "hold");
    let path = world.plan(
        "sets-adopted",
        &plan_of(
            "sets-adopted",
            vec![
                human("approve", &[]),
                agent("held", &[]),
                agent("build", &["approve", "held"]),
            ],
        ),
    );
    world
        .run(&[
            "start",
            &path,
            "--detach",
            "--dag-graph",
            &world.shipped_dag_graph(),
            "--set",
            "members.monitor.agent.model=observer",
        ])
        .exited(0);
    world.until("the held node to start", |world| {
        world
            .events_of("sets-adopted", "node-dispatched")
            .iter()
            .any(|event| event["labels"]["node"] == "held")
    });
    let edited = json!({"version":3,"commands":[
        {"op":"set-run-node-sets","sets":["members.worker.agent.model=adopted=value"]}
    ]});
    world
        .run_with_stdin(&["reply", "sets-adopted"], &edited.to_string())
        .exited(0);
    world.until("the live driver to commit the edit", |world| {
        committed(world, "sets-adopted").contains(&"set-run-node-sets".to_string())
    });
    world.release("held.go");
    world
        .until_read(
            "the blocked driver to exit",
            false,
            |world| world.run(&["status", "sets-adopted"]),
            |status| status.stdout.contains("PAUSED"),
        )
        .exited(0);
    let checkpoint = world.run_json("sets-adopted", "checkpoint.json");
    assert_eq!(
        checkpoint["state"]["run_node_sets"],
        json!(["members.worker.agent.model=adopted=value"]),
        "the usable checkpoint did not fold the edit: {checkpoint}"
    );
    assert!(
        checkpoint["coverage"]["records"]
            .as_u64()
            .is_some_and(|count| count > 0),
        "the checkpoint covers no journal records: {checkpoint}"
    );
    world.run(&["attest", "sets-adopted", "approve"]).exited(0);
    world.run(&["adopt", "sets-adopted"]).exited(0);
    let launch = world.run_json("sets-adopted", "launch.json");
    assert!(
        launch["node_sets"].is_null(),
        "launch remains the baseline: {launch}"
    );
    assert_eq!(
        launch["dag_sets"],
        json!(["members.monitor.agent.model=observer"])
    );
    let dags: Vec<_> = world
        .invocations()
        .into_iter()
        .filter(|call| {
            call["tool"] == "oneagentgraph"
                && call["args"].as_array().is_some_and(|args| {
                    args.iter()
                        .any(|arg| arg.as_str().is_some_and(|s| s.ends_with("dag-scope.yaml")))
                })
        })
        .collect();
    assert!(
        dags.len() >= 2,
        "start and adopt launched the dag observer: {dags:?}"
    );
    for dag in dags {
        assert!(
            dag["args"]
                .as_array()
                .expect("argv")
                .windows(2)
                .any(|pair| {
                    pair[0] == "--set" && pair[1] == "members.monitor.agent.model=observer"
                }),
            "a dag observer lost its original overrides: {dag}"
        );
    }
    let call = world
        .invocations()
        .into_iter()
        .find(|call| {
            call["tool"] == "oneagentgraph"
                && call["args"]
                    .as_array()
                    .is_some_and(|args| args.iter().any(|arg| arg == "onepipeline.node=build"))
        })
        .expect("adoption dispatched build");
    assert!(
        call["args"]
            .as_array()
            .expect("argv")
            .windows(2)
            .any(|pair| {
                pair[0] == "--set" && pair[1] == "members.worker.agent.model=adopted=value"
            }),
        "the adopted dispatch lost the edit: {call}"
    );
}

```

### `readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/readjust.rs`):

```rust

fn deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red() {
    let world = team_world("readjust-verdicts");
    world.script("a.work", "a's change\n");
    world.script("b.work-anew", "b's change");
    world.script("x.work", "x's change\n");
    world.script("y.work", "y's change\n");
    world.script("a-rework-1.work", "a's change, as the review asked\n");
    world.script("a-rework-1.work-file", "a");
    let run = "verdicts";
    launched(
        &world,
        run,
        vec![
            lifecycle("a", &[]),
            lifecycle("b", &["a"]),
            lifecycle("x", &[]),
            lifecycle("y", &["x"]),
        ],
    );
    assert!(
        host_calls(&world, 0).iter().any(is_check_read),
        "a first publication did not watch its checks"
    );
    let from = world.invocations().len();

    // A rework's republication, and the restack it owes the draft above it.
    reply(&world, run, json!([rework("a")])).exited(0);
    world.run(&["adopt", run]).exited(0);
    for node in ["a-rework-1", "b"] {
        assert_eq!(
            settled(&world, run, node)["outcome"],
            "change-review-draft-unchecked",
            "{node}"
        );
    }
    let b_branch = branch_of(&world, run, "b");
    let b_head = text(&settled(&world, run, "b")["head"], "b's head").to_owned();
    person(&world, &["verdict", &b_head, "failed:lint"]);

    // A readjustment's republication, made by the next review's own readjustment.
    merge(&world, &number_of(&world, run, "x"), "squash", "kept");
    let before_review = world.invocations().len();
    let watched: Vec<Value> = world.invocations()[from..before_review]
        .iter()
        .filter(|call| call["tool"] == "gh" && is_check_read(call))
        .cloned()
        .collect();
    assert!(
        watched.is_empty(),
        "a republication watched its checks: {watched:#?}"
    );
    let (status, results) = views(&world, run);
    for node in ["a-rework-1", "b"] {
        assert!(
            status.contains(&format!("{node}: check verdict outstanding")),
            "{node}:\n{status}"
        );
    }
    assert!(results.contains("check verdict outstanding"), "{results}");

    let receipt = review(&world, run);
    let read = |node: &str| record(&world, run, "node-checks-read", node);
    assert_eq!(read("a-rework-1").expect("read")["verdict"], "passed");
    assert_eq!(read("b").expect("read")["verdict"], "failed");
    assert_eq!(outcome_of(&world, run, "a-rework-1"), "change-review-draft");
    assert_eq!(
        settled(&world, run, "y")["outcome"],
        "change-review-draft-unchecked",
        "y's readjustment republished without a watch"
    );
    // The red draft was dispatched again on its own branch, its refusal the checks
    // that failed, and published onto the change request it already had.
    let redispatched = world
        .events_of(run, "node-dispatched")
        .into_iter()
        .rfind(|event| event["labels"]["node"] == "b")
        .expect("b was dispatched");
    assert_eq!(redispatched["payload"]["attempt"], 2, "{redispatched}");
    assert!(
        redispatched["payload"]["reason"]
            .as_str()
            .is_some_and(|reason| reason.starts_with("checks-failed") && reason.contains("lint")),
        "{redispatched}"
    );
    let repaired = settled(&world, run, "b");
    assert_eq!(repaired["branch"], b_branch.as_str(), "{repaired}");
    assert_eq!(
        repaired["outcome"], "change-review-draft-unchecked",
        "{repaired}"
    );
    assert_ne!(repaired["head"], b_head.as_str(), "{repaired}");
    assert_eq!(opened_from(&world, &b_branch), 1);
    let outstanding: Vec<&str> = receipt["outstanding"]
        .as_array()
        .map(|nodes| nodes.iter().filter_map(Value::as_str).collect())
        .unwrap_or_default();
    assert!(
        outstanding.contains(&"y") && outstanding.contains(&"b"),
        "{receipt}"
    );
    let readjust_line = world.run(&["readjust", run]);
    readjust_line.exited(0);
    assert!(
        readjust_line.stdout.contains("readjust performed")
            && !readjust_line.stdout.contains("outstanding"),
        "the readjustment read the outstanding verdicts, so none is left: {}",
        readjust_line.stdout
    );
    assert_eq!(read("y").expect("read")["verdict"], "passed");
    assert_eq!(outcome_of(&world, run, "y"), "change-review-draft");
    assert_eq!(outcome_of(&world, run, "b"), "change-review-draft");
}

```

After (af3fdcd9, `tests/e2e/readjust.rs`):

```rust

fn deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red() {
    let world = team_world("readjust-verdicts");
    world.script("a.work", "a's change\n");
    world.script("b.work-anew", "b's change");
    world.script("x.work", "x's change\n");
    world.script("y.work", "y's change\n");
    world.script("a-rework-1.work", "a's change, as the review asked\n");
    world.script("a-rework-1.work-file", "a");
    let run = "verdicts";
    launched(
        &world,
        run,
        vec![
            lifecycle("a", &[]),
            lifecycle("b", &["a"]),
            lifecycle("x", &[]),
            lifecycle("y", &["x"]),
        ],
    );
    assert!(
        host_calls(&world, 0).iter().any(is_check_read),
        "a first publication did not watch its checks"
    );
    let from = world.invocations().len();

    // A rework's republication, and the restack it owes the draft above it.
    reply(&world, run, json!([rework("a")])).exited(0);
    world.run(&["adopt", run]).exited(0);
    for node in ["a-rework-1", "b"] {
        assert_eq!(
            settled(&world, run, node)["outcome"],
            "change-review-draft-unchecked",
            "{node}"
        );
    }
    let b_branch = branch_of(&world, run, "b");
    let b_head = text(&settled(&world, run, "b")["head"], "b's head").to_owned();
    person(&world, &["verdict", &b_head, "failed:lint"]);

    // A readjustment's republication, made by the next review's own readjustment.
    merge(&world, &number_of(&world, run, "x"), "squash", "kept");
    let before_review = world.invocations().len();
    let watched: Vec<Value> = world.invocations()[from..before_review]
        .iter()
        .filter(|call| call["tool"] == "gh" && is_check_read(call))
        .cloned()
        .collect();
    assert!(
        watched.is_empty(),
        "a republication watched its checks: {watched:#?}"
    );
    let (status, results) = views(&world, run);
    for node in ["a-rework-1", "b"] {
        assert!(
            status.contains(&format!("{node}: check verdict outstanding")),
            "{node}:\n{status}"
        );
    }
    assert!(results.contains("check verdict outstanding"), "{results}");

    let receipt = review(&world, run);
    let read = |node: &str| record(&world, run, "node-checks-read", node);
    assert_eq!(read("a-rework-1").expect("read")["verdict"], "passed");
    assert_eq!(read("b").expect("read")["verdict"], "failed");
    assert_eq!(outcome_of(&world, run, "a-rework-1"), "change-review-draft");
    assert_eq!(
        settled(&world, run, "y")["outcome"],
        "change-review-draft-unchecked",
        "y's readjustment republished without a watch"
    );
    // The red draft was dispatched again on its own branch, its refusal the checks
    // that failed, and published onto the change request it already had.
    let redispatched = world
        .events_of(run, "node-dispatched")
        .into_iter()
        .rfind(|event| event["labels"]["node"] == "b")
        .expect("b was dispatched");
    assert_eq!(redispatched["payload"]["attempt"], 2, "{redispatched}");
    assert!(
        redispatched["payload"]["reason"]
            .as_str()
            .is_some_and(|reason| reason.starts_with("checks-failed") && reason.contains("lint")),
        "{redispatched}"
    );
    let repaired = settled(&world, run, "b");
    assert_eq!(repaired["branch"], b_branch.as_str(), "{repaired}");
    assert_eq!(
        repaired["outcome"], "change-review-draft-unchecked",
        "{repaired}"
    );
    assert_ne!(repaired["head"], b_head.as_str(), "{repaired}");
    assert_eq!(opened_from(&world, &b_branch), 1);
    let outstanding: Vec<&str> = receipt["outstanding"]
        .as_array()
        .map(|nodes| nodes.iter().filter_map(Value::as_str).collect())
        .unwrap_or_default();
    assert!(
        outstanding.contains(&"y") && outstanding.contains(&"b"),
        "{receipt}"
    );
    let readjust_line = world.run(&["readjust", run]);
    readjust_line.exited(0);
    assert!(
        readjust_line.stdout.contains("readjust performed")
            && !readjust_line.stdout.contains("outstanding"),
        "the readjustment read the outstanding verdicts, so none is left: {}",
        readjust_line.stdout
    );
    assert_eq!(read("y").expect("read")["verdict"], "passed");
    let outcomes = outcomes_of(&world, run, &["y", "b"]);
    assert_eq!(outcomes[0], "change-review-draft");
    assert_eq!(outcomes[1], "change-review-draft");
}

```

### `readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/readjust.rs`):

```rust

fn every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding() {
    let world = team_world("readjust-verdict-words");
    branch_off_main(&world, "release");
    for node in ["a", "b", "c", "p", "d"] {
        world.script(&format!("{node}.work"), &format!("{node}'s change\n"));
    }
    let on_release = |id: &str, deps: &[&str]| {
        let mut node = lifecycle(id, deps);
        node["base_branch"] = json!("release");
        node
    };
    let run = "words";
    launched(
        &world,
        run,
        vec![
            lifecycle("a", &[]),
            lifecycle("b", &["a"]),
            lifecycle("c", &["a"]),
            on_release("p", &[]),
            on_release("d", &["p"]),
        ],
    );
    merge(&world, &number_of(&world, run, "a"), "squash", "kept");
    merge(&world, &number_of(&world, run, "p"), "squash", "kept");
    readjusted(&world, run);
    let head = |node: &str| tip(&world, &branch_of(&world, run, node));
    person(&world, &["verdict", &head("b"), "pending:ci"]);
    person(&world, &["verdict", &head("c"), "skipped:lint"]);
    person(&world, &["verdict", &head("d"), "none"]);
    let (code, receipt) = readjust(&world, run);
    assert_eq!(code, 0, "{receipt}");
    for (node, verdict) in [
        ("b", "pending"),
        ("c", "passed-with-skipped"),
        ("d", "none-required"),
    ] {
        let read = record(&world, run, "node-checks-read", node).expect("read");
        assert_eq!(read["verdict"], verdict, "{node}: {read}");
    }
    assert_eq!(receipt["outstanding"], json!(["b"]), "{receipt}");
    for node in ["c", "d"] {
        assert_eq!(
            outcome_of(&world, run, node),
            "change-review-draft",
            "{node}"
        );
    }
    assert_eq!(
        outcome_of(&world, run, "b"),
        "change-review-draft-unchecked"
    );
    let (status, _) = views(&world, run);
    assert!(status.contains("b: check verdict outstanding"), "{status}");
    assert!(!status.contains("c: check verdict outstanding"), "{status}");

    person(&world, &["verdict", &head("b"), "passed"]);
    let (_, receipt) = readjust(&world, run);
    assert!(receipt.get("outstanding").is_none(), "{receipt}");
    assert_eq!(outcome_of(&world, run, "b"), "change-review-draft");
}

```

After (af3fdcd9, `tests/e2e/readjust.rs`):

```rust

fn every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding() {
    let world = team_world("readjust-verdict-words");
    branch_off_main(&world, "release");
    for node in ["a", "b", "c", "p", "d"] {
        world.script(&format!("{node}.work"), &format!("{node}'s change\n"));
    }
    let on_release = |id: &str, deps: &[&str]| {
        let mut node = lifecycle(id, deps);
        node["base_branch"] = json!("release");
        node
    };
    let run = "words";
    launched(
        &world,
        run,
        vec![
            lifecycle("a", &[]),
            lifecycle("b", &["a"]),
            lifecycle("c", &["a"]),
            on_release("p", &[]),
            on_release("d", &["p"]),
        ],
    );
    merge(&world, &number_of(&world, run, "a"), "squash", "kept");
    merge(&world, &number_of(&world, run, "p"), "squash", "kept");
    readjusted(&world, run);
    let head = |node: &str| tip(&world, &branch_of(&world, run, node));
    person(&world, &["verdict", &head("b"), "pending:ci"]);
    person(&world, &["verdict", &head("c"), "skipped:lint"]);
    person(&world, &["verdict", &head("d"), "none"]);
    let (code, receipt) = readjust(&world, run);
    assert_eq!(code, 0, "{receipt}");
    for (node, verdict) in [
        ("b", "pending"),
        ("c", "passed-with-skipped"),
        ("d", "none-required"),
    ] {
        let read = record(&world, run, "node-checks-read", node).expect("read");
        assert_eq!(read["verdict"], verdict, "{node}: {read}");
    }
    assert_eq!(receipt["outstanding"], json!(["b"]), "{receipt}");
    let outcomes = outcomes_of(&world, run, &["c", "d", "b"]);
    for (node, outcome) in ["c", "d"].iter().zip(&outcomes) {
        assert_eq!(outcome, "change-review-draft", "{node}");
    }
    assert_eq!(outcomes[2], "change-review-draft-unchecked");
    let (status, _) = views(&world, run);
    assert!(status.contains("b: check verdict outstanding"), "{status}");
    assert!(!status.contains("c: check verdict outstanding"), "{status}");

    person(&world, &["verdict", &head("b"), "passed"]);
    let (_, receipt) = readjust(&world, run);
    assert!(receipt.get("outstanding").is_none(), "{receipt}");
    assert_eq!(outcome_of(&world, run, "b"), "change-review-draft");
}

```

### `shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/shipped.rs`):

```rust

fn status_on_an_adopted_run_describes_the_driver_driving_it_now() {
    const RUN: &str = "single-node";
    const NODE: &str = "cover-report-failures";
    const RETRY: &str = "cover-report-failures-2";
    let world = World::new("shipped-adopted");
    let example_store = world.root.join("shipped-plan-store");
    copy_tree(&repo_file("examples/plan-store"), &example_store);
    for (index, identity) in example_repositories().into_iter().enumerate() {
        let checkout = world.root.join(format!("example-{index}"));
        std::fs::create_dir_all(&checkout).expect("an example checkout");
        assert!(onepipeline_testfakes::profile::process::Command::new("git")
            .args(["init", "--initial-branch=main"])
            .arg(&checkout)
            .output()
            .expect("git initializes the example checkout")
            .status
            .success());
        world.register(&checkout, Some(&format!("https://{identity}.git")));
    }
    let world = world
        .with_env(
            "ONETASKGRAPH_SOURCES__PLANS__CONFIG__ROOT",
            &example_store.to_string_lossy(),
        )
        .with_env("ONEPIPELINE_REPLY_TIMEOUT_SECONDS", "2");
    world.script(&format!("{NODE}.fail"), "1");
    world
        .run(&["start", &format!("plans:{RUN}"), "--attach"])
        .out_has("\"settlement\":\"unattended\"");
    world
        .run(&["status", RUN])
        .exited(0)
        .out_has("driver exited")
        .out_has("settled unattended");

    let plan = world.run_json(RUN, "plan.json");
    let task = plan["tasks"]
        .as_array()
        .and_then(|tasks| tasks.iter().find(|task| task["id"] == NODE))
        .unwrap_or_else(|| panic!("the plan names the node: {plan}"));
    let replacement = serde_json::json!({
        "id": RETRY, "persona": task["persona"], "task": task["task"],
        "repo": task["repo"], "title": task["title"],
    });
    world.script(&format!("{RETRY}.wait"), "hold");
    // Nothing drives the run yet, so the reply outlives its short wait for an
    // answer: what matters is that the retry is queued for the adopter.
    world.run_with_stdin(
        &["reply", RUN],
        &serde_json::json!({"version": 2, "commands": [
            {"op": "retry", "id": NODE, "node": replacement}
        ]})
        .to_string(),
    );
    world.run(&["adopt", RUN, "--detach"]).exited(0);
    world.until("the adopter to dispatch the retry", |world| {
        world
            .events_of(RUN, "node-dispatched")
            .iter()
            .any(|event| event["labels"]["node"] == RETRY)
    });

    let adopter = world.events_of(RUN, "driver-adopted")[0]["payload"]["pid"].clone();
    let live = world.run(&["status", RUN]);
    live.exited(0)
        .out_has("ACTIVE")
        .out_has("driver: live, adopted")
        .out_has(&format!("pid {adopter}, adoption 1"));
    assert!(
        !live.stdout.contains("driver exited"),
        "the earlier driver's exit was printed beside a live adopter:\n{}",
        live.stdout
    );
    let reading: serde_json::Value =
        serde_json::from_str(&world.run(&["status", RUN, "--json"]).exited(0).stdout)
            .expect("the reading is JSON");
    assert_eq!(reading["driven"], true, "{reading}");
    assert_eq!(reading["word"], "ACTIVE", "{reading}");
    assert!(reading["ending"].is_null(), "{reading}");

    world.release(&format!("{RETRY}.go"));
    world.until("the adopter to exit", |world| {
        world.events_of(RUN, "driver-exited").len() == 2
    });
    world.until("the adopter's claim to be released", |world| {
        !world.run(&["status", RUN]).stdout.contains("ACTIVE")
    });
    let exits = world.events_of(RUN, "driver-exited");
    let adopters_exit = exits[1]["ts"].as_str().expect("a stamped record");
    assert_ne!(exits[0]["ts"], exits[1]["ts"]);
    let exited = world.run(&["status", RUN]);
    exited
        .exited(0)
        .out_has("driver exited")
        .out_has(&format!("({adopters_exit})"));
    assert!(
        !exited.stdout.contains("driver: live"),
        "the adopter was still named as live after it exited:\n{}",
        exited.stdout
    );
    let reading: serde_json::Value =
        serde_json::from_str(&world.run(&["status", RUN, "--json"]).exited(0).stdout)
            .expect("the reading is JSON");
    assert_eq!(reading["driven"], false, "{reading}");
    assert!(reading["ending"].is_object(), "{reading}");
}

```

After (af3fdcd9, `tests/e2e/shipped.rs`):

```rust

fn status_on_an_adopted_run_describes_the_driver_driving_it_now() {
    const RUN: &str = "single-node";
    const NODE: &str = "cover-report-failures";
    const RETRY: &str = "cover-report-failures-2";
    let world = World::new("shipped-adopted");
    let example_store = world.root.join("shipped-plan-store");
    copy_tree(&repo_file("examples/plan-store"), &example_store);
    for (index, identity) in example_repositories().into_iter().enumerate() {
        let checkout = world.root.join(format!("example-{index}"));
        std::fs::create_dir_all(&checkout).expect("an example checkout");
        assert!(onepipeline_testfakes::profile::process::Command::new("git")
            .args(["init", "--initial-branch=main"])
            .arg(&checkout)
            .output()
            .expect("git initializes the example checkout")
            .status
            .success());
        world.register(&checkout, Some(&format!("https://{identity}.git")));
    }
    let world = world
        .with_env(
            "ONETASKGRAPH_SOURCES__PLANS__CONFIG__ROOT",
            &example_store.to_string_lossy(),
        )
        .with_env("ONEPIPELINE_REPLY_TIMEOUT_SECONDS", "2");
    world.script(&format!("{NODE}.fail"), "1");
    world
        .run(&["start", &format!("plans:{RUN}"), "--attach"])
        .out_has("\"settlement\":\"unattended\"");
    world
        .run(&["status", RUN])
        .exited(0)
        .out_has("driver exited")
        .out_has("settled unattended");

    let plan = world.run_json(RUN, "plan.json");
    let task = plan["tasks"]
        .as_array()
        .and_then(|tasks| tasks.iter().find(|task| task["id"] == NODE))
        .unwrap_or_else(|| panic!("the plan names the node: {plan}"));
    let replacement = serde_json::json!({
        "id": RETRY, "persona": task["persona"], "task": task["task"],
        "repo": task["repo"], "title": task["title"],
    });
    world.script(&format!("{RETRY}.wait"), "hold");
    // Nothing drives the run yet, so the reply outlives its short wait for an
    // answer: what matters is that the retry is queued for the adopter.
    world.run_with_stdin(
        &["reply", RUN],
        &serde_json::json!({"version": 2, "commands": [
            {"op": "retry", "id": NODE, "node": replacement}
        ]})
        .to_string(),
    );
    world.run(&["adopt", RUN, "--detach"]).exited(0);
    world.until("the adopter to dispatch the retry", |world| {
        world
            .events_of(RUN, "node-dispatched")
            .iter()
            .any(|event| event["labels"]["node"] == RETRY)
    });

    let adopter = world.events_of(RUN, "driver-adopted")[0]["payload"]["pid"].clone();
    let live = world.run(&["status", RUN]);
    live.exited(0)
        .out_has("ACTIVE")
        .out_has("driver: live, adopted")
        .out_has(&format!("pid {adopter}, adoption 1"));
    assert!(
        !live.stdout.contains("driver exited"),
        "the earlier driver's exit was printed beside a live adopter:\n{}",
        live.stdout
    );
    let reading: serde_json::Value =
        serde_json::from_str(&world.run(&["status", RUN, "--json"]).exited(0).stdout)
            .expect("the reading is JSON");
    assert_eq!(reading["driven"], true, "{reading}");
    assert_eq!(reading["word"], "ACTIVE", "{reading}");
    assert!(reading["ending"].is_null(), "{reading}");

    world.release(&format!("{RETRY}.go"));
    world.until("the adopter to exit", |world| {
        world.events_of(RUN, "driver-exited").len() == 2
    });
    let released = world.until_read(
        "the adopter's claim to be released",
        false,
        |world| world.run(&["status", RUN]),
        |status| !status.stdout.contains("ACTIVE"),
    );
    let exits = world.events_of(RUN, "driver-exited");
    let adopters_exit = exits[1]["ts"].as_str().expect("a stamped record");
    assert_ne!(exits[0]["ts"], exits[1]["ts"]);
    let exited = released;
    exited
        .exited(0)
        .out_has("driver exited")
        .out_has(&format!("({adopters_exit})"));
    assert!(
        !exited.stdout.contains("driver: live"),
        "the adopter was still named as live after it exited:\n{}",
        exited.stdout
    );
    let reading: serde_json::Value =
        serde_json::from_str(&world.run(&["status", RUN, "--json"]).exited(0).stdout)
            .expect("the reading is JSON");
    assert_eq!(reading["driven"], false, "{reading}");
    assert!(reading["ending"].is_object(), "{reading}");
}

```

### `shipped::status_says_an_adopter_that_died_recorded_no_exit`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/shipped.rs`):

```rust

fn status_says_an_adopter_that_died_recorded_no_exit() {
    const RETRY: &str = "build-2";
    let world = World::new("adopter-died").with_env("ONEPIPELINE_REPLY_TIMEOUT_SECONDS", "2");
    let path = world.plan(
        "died",
        &crate::harness::plan_of("died", vec![crate::harness::agent("build", &[])]),
    );
    world.script("build.fail", "1");
    world.run(&["start", &path, "--attach"]);
    // A held retry keeps the adopter driving: with nothing left to do it settles
    // and records its own exit, which can land before the kill below.
    world.script(&format!("{RETRY}.wait"), "hold");
    let plan = world.run_json("died", "plan.json");
    let task = &plan["tasks"][0];
    world.run_with_stdin(
        &["reply", "died"],
        &serde_json::json!({"version": 2, "commands": [{"op": "retry", "id": "build", "node": {
            "id": RETRY, "persona": task["persona"], "task": task["task"],
            "repo": task["repo"], "title": task["title"],
        }}]})
        .to_string(),
    );
    world.run(&["adopt", "died", "--detach"]).exited(0);
    world.until("the adopter to dispatch the retry", |world| {
        world
            .events_of("died", "node-dispatched")
            .iter()
            .any(|event| event["labels"]["node"] == RETRY)
    });
    let pid = world.events_of("died", "driver-adopted")[0]["payload"]["pid"]
        .as_u64()
        .expect("the adoption names its driver");
    crate::harness::end_process(u32::try_from(pid).expect("a pid"));
    world.until("the driver to read as gone", |world| {
        !world.run(&["status", "died"]).stdout.contains("ACTIVE")
    });
    let status = world.run(&["status", "died"]);
    status
        .exited(0)
        .out_has("driver: exited without recording it, adopted");
    assert!(
        !status.stdout.contains("driver exited"),
        "{}",
        status.stdout
    );
    world.release(&format!("{RETRY}.go"));
}

```

After (af3fdcd9, `tests/e2e/shipped.rs`):

```rust

fn status_says_an_adopter_that_died_recorded_no_exit() {
    const RETRY: &str = "build-2";
    let world = World::new("adopter-died").with_env("ONEPIPELINE_REPLY_TIMEOUT_SECONDS", "2");
    let path = world.plan(
        "died",
        &crate::harness::plan_of("died", vec![crate::harness::agent("build", &[])]),
    );
    world.script("build.fail", "1");
    world.run(&["start", &path, "--attach"]);
    // A held retry keeps the adopter driving: with nothing left to do it settles
    // and records its own exit, which can land before the kill below.
    world.script(&format!("{RETRY}.wait"), "hold");
    let plan = world.run_json("died", "plan.json");
    let task = &plan["tasks"][0];
    world.run_with_stdin(
        &["reply", "died"],
        &serde_json::json!({"version": 2, "commands": [{"op": "retry", "id": "build", "node": {
            "id": RETRY, "persona": task["persona"], "task": task["task"],
            "repo": task["repo"], "title": task["title"],
        }}]})
        .to_string(),
    );
    world.run(&["adopt", "died", "--detach"]).exited(0);
    world.until("the adopter to dispatch the retry", |world| {
        world
            .events_of("died", "node-dispatched")
            .iter()
            .any(|event| event["labels"]["node"] == RETRY)
    });
    let pid = world.events_of("died", "driver-adopted")[0]["payload"]["pid"]
        .as_u64()
        .expect("the adoption names its driver");
    crate::harness::end_process(u32::try_from(pid).expect("a pid"));
    let status = world.until_read(
        "the driver to read as gone",
        false,
        |world| world.run(&["status", "died"]),
        |status| !status.stdout.contains("ACTIVE"),
    );
    status
        .exited(0)
        .out_has("driver: exited without recording it, adopted");
    assert!(
        !status.stdout.contains("driver exited"),
        "{}",
        status.stdout
    );
    world.release(&format!("{RETRY}.go"));
}

```

### `unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/unwatched.rs`):

```rust

fn concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns() {
    let world = World::new("unwatched-several");
    world.script("build.wait", "hold");
    let run = held(&world, "unwatchedseveral");

    let first = arm(&world, &run);
    let second = arm(&world, &run);
    let third = arm(&world, &run);
    let names: Vec<String> = records_under(&world, &run)
        .iter()
        .map(|path| named(path))
        .collect();
    assert_eq!(
        names.len(),
        3,
        "three concurrent watches did not leave three records: {names:?}"
    );
    world.run(&["unwatched"]).exited(SUCCESS);

    // Two of the three gone, and the run is still watched: one live watch is
    // enough, which is what makes a record per watch rather than per run right.
    for mut watch in [first, second] {
        watch.kill().expect("the watch takes the signal");
        watch.wait().expect("the watch ends");
    }
    world.until("the two killed watches to read as gone", |world| {
        world.run(&["unwatched"]).code == SUCCESS
    });
    let asked = world.run(&["unwatched"]);
    asked.exited(SUCCESS);
    assert!(
        asked.stdout.is_empty(),
        "a run one live watch still holds was reported: {}",
        asked.stdout
    );

    // And unwatched once none is.
    let mut third = third;
    third.kill().expect("the watch takes the signal");
    third.wait().expect("the watch ends");
    world
        .run(&["unwatched"])
        .exited(RUNS_UNWATCHED)
        .out_has(&run);
    world.release("build.go");
}

```

After (af3fdcd9, `tests/e2e/unwatched.rs`):

```rust

fn concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns() {
    let world = World::new("unwatched-several");
    world.script("build.wait", "hold");
    let run = held(&world, "unwatchedseveral");

    let first = arm(&world, &run);
    let second = arm(&world, &run);
    let third = arm(&world, &run);
    let names: Vec<String> = records_under(&world, &run)
        .iter()
        .map(|path| named(path))
        .collect();
    assert_eq!(
        names.len(),
        3,
        "three concurrent watches did not leave three records: {names:?}"
    );
    world.run(&["unwatched"]).exited(SUCCESS);

    // Two of the three gone, and the run is still watched: one live watch is
    // enough, which is what makes a record per watch rather than per run right.
    for mut watch in [first, second] {
        watch.kill().expect("the watch takes the signal");
        watch.wait().expect("the watch ends");
    }
    let asked = world.until_read(
        "the two killed watches to read as gone",
        false,
        |world| world.run(&["unwatched"]),
        |asked| asked.code == SUCCESS,
    );
    asked.exited(SUCCESS);
    assert!(
        asked.stdout.is_empty(),
        "a run one live watch still holds was reported: {}",
        asked.stdout
    );

    // And unwatched once none is.
    let mut third = third;
    third.kill().expect("the watch takes the signal");
    third.wait().expect("the watch ends");
    world
        .run(&["unwatched"])
        .exited(RUNS_UNWATCHED)
        .out_has(&run);
    world.release("build.go");
}

```

### `views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/views.rs`):

```rust

fn a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice() {
    let world = World::new("views-parked-advice");
    world.script("slow.turn-open", "");
    world.script("slow.wait", "hold");
    world.script("slow.stops-when-interrupted", "");
    let path = world.plan("parkedrun", &plan_of("parkedrun", vec![agent("slow", &[])]));
    world.run(&["start", &path, "--detach"]).exited(0);
    world.until("the held node's turn to open", |world| {
        !world.events_of("parkedrun", "turn-started").is_empty()
    });

    world
        .run_with_stdin(
            &["reply", "parkedrun"],
            &serde_json::json!({"version": 2, "commands": [{"op": "cancel", "id": "slow"}]})
                .to_string(),
        )
        .exited(0);
    // The run is only what this journey is about once its driver has gone: what
    // is being read is a run nothing is driving. `result.json` is written before
    // the driver exits, so it is not the signal on its own.
    world.until("the driver to close the run out", |world| {
        world.run_file("parkedrun", "result.json").is_file()
    });
    // Each look starts a process, so it yields between looks rather than taking
    // the host from the exit it is waiting on (`tests/AGENTS.md`).
    world.until_store("the run to read as ended", |world| {
        world.run(&["runs"]).stdout.contains("ENDED unfinished")
    });

    let listing = world.run(&["runs"]);
    listing.exited(0).out_has("parkedrun");
    listing.out_has("ENDED unfinished");
    let status = world.run(&["status", "parkedrun"]);
    status.exited(0).out_has("parkedrun  ENDED unfinished");
    for rendered in [&listing, &status] {
        rendered.out_lacks("requeue");
        rendered.out_lacks("adopt");
        rendered.out_lacks("DRIVER DEAD");
    }

    world.release("slow.go");
}

```

After (af3fdcd9, `tests/e2e/views.rs`):

```rust

fn a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice() {
    let world = World::new("views-parked-advice");
    world.script("slow.turn-open", "");
    world.script("slow.wait", "hold");
    world.script("slow.stops-when-interrupted", "");
    let path = world.plan("parkedrun", &plan_of("parkedrun", vec![agent("slow", &[])]));
    world.run(&["start", &path, "--detach"]).exited(0);
    world.until("the held node's turn to open", |world| {
        !world.events_of("parkedrun", "turn-started").is_empty()
    });

    world
        .run_with_stdin(
            &["reply", "parkedrun"],
            &serde_json::json!({"version": 2, "commands": [{"op": "cancel", "id": "slow"}]})
                .to_string(),
        )
        .exited(0);
    // The run is only what this journey is about once its driver has gone: what
    // is being read is a run nothing is driving. `result.json` is written before
    // the driver exits, so it is not the signal on its own.
    world.until("the driver to close the run out", |world| {
        world.run_file("parkedrun", "result.json").is_file()
    });
    // Each look starts a process, so it yields between looks rather than taking
    // the host from the exit it is waiting on (`tests/AGENTS.md`).
    let listing = world.until_read(
        "the run to read as ended",
        true,
        |world| world.run(&["runs"]),
        |listing| listing.stdout.contains("ENDED unfinished"),
    );
    listing.exited(0).out_has("parkedrun");
    listing.out_has("ENDED unfinished");
    let status = world.run(&["status", "parkedrun"]);
    status.exited(0).out_has("parkedrun  ENDED unfinished");
    for rendered in [&listing, &status] {
        rendered.out_lacks("requeue");
        rendered.out_lacks("adopt");
        rendered.out_lacks("DRIVER DEAD");
    }

    world.release("slow.go");
}

```

### `views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt`

Classification: same asserted outcomes and the original argument/exit/stdio conditions for every retained command. Every retained CLI command remains a fresh process. Detached-driver, concurrency and timing/event assertions in the quoted body are unchanged. R proves less repeated independent read-process count: discarded duplicate reads are no longer separately observed. The reused readings are confined to the settled/held states and successful event predicates shown here; no arbitrary concurrent-read equivalence is claimed.

Before (13eb521a, `tests/e2e/views.rs`):

```rust

fn a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt() {
    let world = World::new("views-undriven-advice");
    world.script("build.wait", "hold");
    let path = world.plan(
        "livework",
        &plan_of(
            "livework",
            vec![agent("build", &[]), agent("later", &["build"])],
        ),
    );
    let started = world.run(&["start", &path, "--detach"]);
    started.exited(0);
    let driver = u32::try_from(
        started.json()["pid"]
            .as_u64()
            .expect("a detached launch names the driver it retained"),
    )
    .expect("a pid");
    world.until("the dispatch to be in flight", |world| {
        !world.events_of("livework", "node-dispatched").is_empty()
    });

    crate::harness::end_process(driver);
    world.until("the run to read as undriven", |world| {
        world
            .run(&["status", "livework"])
            .stdout
            .contains("DRIVER DEAD")
    });

    let listing = world.run(&["runs"]);
    listing.exited(0).out_has(
        "DRIVER DEAD — its ledger is intact; attach a fresh driver with: \
         onepipeline adopt livework",
    );
    listing.out_lacks("requeue");

    let status = world.run(&["status", "livework"]);
    status.exited(0);
    status.out_has("DRIVER DEAD: nothing is driving this run; adopt it or stop it");
    status.out_lacks("requeue");

    world.release("build.go");
}

```

After (af3fdcd9, `tests/e2e/views.rs`):

```rust

fn a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt() {
    let world = World::new("views-undriven-advice");
    world.script("build.wait", "hold");
    let path = world.plan(
        "livework",
        &plan_of(
            "livework",
            vec![agent("build", &[]), agent("later", &["build"])],
        ),
    );
    let started = world.run(&["start", &path, "--detach"]);
    started.exited(0);
    let driver = u32::try_from(
        started.json()["pid"]
            .as_u64()
            .expect("a detached launch names the driver it retained"),
    )
    .expect("a pid");
    world.until("the dispatch to be in flight", |world| {
        !world.events_of("livework", "node-dispatched").is_empty()
    });

    crate::harness::end_process(driver);
    let undriven = world.until_read(
        "the run to read as undriven",
        false,
        |world| world.run(&["status", "livework"]),
        |status| status.stdout.contains("DRIVER DEAD"),
    );

    let listing = world.run(&["runs"]);
    listing.exited(0).out_has(
        "DRIVER DEAD — its ledger is intact; attach a fresh driver with: \
         onepipeline adopt livework",
    );
    listing.out_lacks("requeue");

    let status = undriven;
    status.exited(0);
    status.out_has("DRIVER DEAD: nothing is driving this run; adopt it or stop it");
    status.out_lacks("requeue");

    world.release("build.go");
}

```

### Shared helper assertions and reader selection

Before/after helper bodies retain node-presence/JSON/exit checks. Reusing a stable result removes duplicate commands, so the same exit assertion runs once per retained command. The no-prototype arms preserve the per-node and post-wait fresh reads.

Before `tests/e2e/adoption.rs::reading_node` (13eb521a):

```rust

fn reading_node(world: &World, run: &str, node: &str) -> Value {
    let reading = world.run(&["status", run, "--json"]).json();
    reading["nodes"]
        .as_array()
        .unwrap_or_else(|| panic!("the reading lists no nodes: {reading}"))
        .iter()
        .find(|entry| entry["id"] == node)
        .cloned()
        .unwrap_or_else(|| panic!("the reading does not list {node}: {reading}"))
}

```

After `tests/e2e/adoption.rs::reading_node` (af3fdcd9):

```rust

fn reading_node(world: &World, run: &str, node: &str) -> Value {
    node_in(&world.run(&["status", run, "--json"]).json(), node)
}

```

After `tests/e2e/adoption.rs::node_in` (af3fdcd9):

```rust

fn node_in(reading: &Value, node: &str) -> Value {
    reading["nodes"]
        .as_array()
        .unwrap_or_else(|| panic!("the reading lists no nodes: {reading}"))
        .iter()
        .find(|entry| entry["id"] == node)
        .cloned()
        .unwrap_or_else(|| panic!("the reading does not list {node}: {reading}"))
}

```

Before `tests/e2e/command_step.rs::result` (13eb521a):

```rust

fn result(world: &World, run: &str, node: &str) -> Value {
    let read = world.run(&["results", run, "--json"]);
    let reading: Value = serde_json::from_str(&read.stdout)
        .unwrap_or_else(|error| panic!("`results --json` is not JSON ({error}):\n{}", read.stdout));
    reading["nodes"]
        .as_array()
        .and_then(|nodes| nodes.iter().find(|entry| entry["id"] == node).cloned())
        .unwrap_or_else(|| panic!("`results {run} --json` does not list {node}: {reading}"))
}

```

After `tests/e2e/command_step.rs::result` (af3fdcd9):

```rust

fn result(world: &World, run: &str, node: &str) -> Value {
    let read = world.run(&["results", run, "--json"]);
    let reading: Value = serde_json::from_str(&read.stdout)
        .unwrap_or_else(|error| panic!("`results --json` is not JSON ({error}):\n{}", read.stdout));
    reading["nodes"]
        .as_array()
        .and_then(|nodes| nodes.iter().find(|entry| entry["id"] == node).cloned())
        .unwrap_or_else(|| panic!("`results {run} --json` does not list {node}: {reading}"))
}

```

Before `tests/e2e/readjust.rs::outcome_of` (13eb521a):

```rust

fn outcome_of(world: &World, run: &str, node: &str) -> Value {
    let output = world.run(&["results", run, "--json"]);
    output.exited(0);
    let results: Value = serde_json::from_str(&output.stdout).expect("results as JSON");
    results["nodes"]
        .as_array()
        .and_then(|nodes| nodes.iter().find(|entry| entry["id"] == node))
        .map(|entry| entry["outcome"].clone())
        .unwrap_or_else(|| panic!("results names no {node}: {results}"))
}

```

After `tests/e2e/readjust.rs::outcome_of` (af3fdcd9):

```rust

fn outcome_of(world: &World, run: &str, node: &str) -> Value {
    outcome_in(&results_of(world, run), node)
}

```

After `tests/e2e/readjust.rs::results_of` (af3fdcd9):

```rust

fn results_of(world: &World, run: &str) -> Value {
    let output = world.run(&["results", run, "--json"]);
    output.exited(0);
    serde_json::from_str(&output.stdout).expect("results as JSON")
}

```

After `tests/e2e/readjust.rs::outcomes_of` (af3fdcd9):

```rust

fn outcomes_of(world: &World, run: &str, nodes: &[&str]) -> Vec<Value> {
    if crate::harness::spike_variant::relaunch() {
        let results = results_of(world, run);
        nodes
            .iter()
            .map(|node| outcome_in(&results, node))
            .collect()
    } else {
        nodes
            .iter()
            .map(|node| outcome_of(world, run, node))
            .collect()
    }
}

```

After `tests/e2e/readjust.rs::outcome_in` (af3fdcd9):

```rust

fn outcome_in(results: &Value, node: &str) -> Value {
    results["nodes"]
        .as_array()
        .and_then(|nodes| nodes.iter().find(|entry| entry["id"] == node))
        .map(|entry| entry["outcome"].clone())
        .unwrap_or_else(|| panic!("results names no {node}: {results}"))
}

```

After `tests/e2e/harness.rs::until_read` (af3fdcd9):

```rust

pub fn until_read(
        &self,
        what: &str,
        store: bool,
        read: impl Fn(&Self) -> Run,
        ready: impl Fn(&Run) -> bool,
    ) -> Run {
        let mut held = None;
        let mut look = |world: &Self| {
            let reading = read(world);
            let holds = ready(&reading);
            if holds {
                held = Some(reading);
            }
            holds
        };
        if store {
            self.until_store(what, &mut look);
        } else {
            self.until(what, &mut look);
        }
        match held {
            Some(reading) if spike_variant::relaunch() => reading,
            _ => read(self),
        }
    }

```

## Suppressions within this spike diff (rechecked at a5f2ae74)

These are the 13 line/block directives introduced by the spike or standing over its changed lines, extracted against stacked base 13eb521a. Each site and substantive reason follows. No shared enforcement rule, scope, threshold or test marker was changed.

| Site | Rules | Reason |
| --- | --- | --- |
| `scripts/child-waits.mjs:30` | contracts_have_one_source_or_a_drift_gate | This is the manually audited source-analysis selection for the frozen cabae915 experiment, not a producer schema or a continuing interface. The report quotes that commit's changed functions; deriving this selection from trace observations would hide sites that ran zero times. Nothing here lands, and any later prototype revision requires a new report audit. |
| `scripts/child-waits.mjs:56` | contracts_have_one_source_or_a_drift_gate | The report audits every changed test body against 13eb521a and cabae915; this is that fixed experiment's explicit selection, including journeys absent on one platform. It is not a new independently versioned test registry, and this measurement branch never lands. |
| `scripts/child-waits.mjs:390` | tool_output_is_signal | compare is a report command: the Markdown it prints on success is the whole of what it is for, and it never lands: this branch is preserved as the measurement record and nothing on it merges. |
| `tests/e2e/adoption.rs:5099` | expensive_tests_stay_behind_their_own_edge | the edge this journey needs is the crate under test itself — its own views, its own write-back into a real store, and a real `onevcs` publication — so a narrower project would declare the same dependency and skip nothing. |
| `tests/e2e/live_edit.rs:66` | expensive_tests_stay_behind_their_own_edge | These journeys live beside the other live-edit journeys because they exercise the crate’s own edit vocabulary, reconciler and node dispatch; any src/ change can move them, so no narrower project edge could honestly run them. |
| `vendor/onevcs/src/lib.rs:81` | changed_behavior_has_e2e | measurement-only trace calls, never landed: the hosted e2e runs and their strace/ETW check exercise them. |
| `vendor/onevcs/src/probe.rs:186` | changed_behavior_has_e2e | measurement-only trace calls, never landed: the hosted e2e runs and their strace/ETW check exercise them. |
| `vendor/onevcs/src/spike_waits.rs:34` | code_lands_in_the_domain_that_owns_it | Measurement-only shared switch, never landed (a1): every child inherits one selection so artifacts identify the entire experiment, but only onepipeline's harness reads Relaunch. This vendored helper is not a repository-engine API proposal; the report explicitly requires R to land in onepipeline tests alone with no onevcs release. |
| `vendor/onevcs/src/spike_waits.rs:154` | changed_behavior_has_e2e | Measurement-only fallback, never landed (a1): portable hosted journeys cannot safely force OpenProcess access failure without mocking the kernel or changing host privileges. It keeps the old bounded sleep on failure; successful and already-gone child paths are exercised. Production adoption must cover platform permission failures separately. |
| `vendor/onevcs/src/spike_waits.rs:200` | changed_behavior_has_e2e | Measurement-only fallback, never landed (a1): real spawned PIDs fit pid_t, so this defensive conversion arm is outside the hosted workload. It retains the caller's bounded sleep; no saving is attributed to it, and testing an invented PID is not a realistic child journey. |
| `vendor/onevcs/src/spike_waits.rs:209` | changed_behavior_has_e2e | Measurement-only fallback, never landed (a1): the kernel returns an int descriptor, so an out-of-int syscall result is defensive only. Resource exhaustion or syscall interception would change the measured host; this preserves the old bounded sleep and is not priced as an optimization. |
| `vendor/onevcs/src/spike_waits.rs:215` | changed_behavior_has_e2e | Measurement-only fallback, never landed (a1): safely forcing pidfd_open to be unavailable requires a different kernel/seccomp policy, outside these hosted runners. ESRCH is exercised by the already-gone child test; other errors keep the original bounded sleep. Production adoption must validate unsupported-kernel behavior. |
| `vendor/onevcs/src/spike_waits.rs:252` | changed_behavior_has_e2e | Measurement-only fallback, never landed (a1): kqueue allocation failure cannot be forced safely in the hosted workload without exhausting descriptors or mocking the kernel. This retains the caller's bounded sleep; no saving is claimed for it, and production adoption must validate that resource-failure branch. |

Full continuation of tests/e2e/live_edit.rs:66: these journeys live beside the other live-edit journeys in the file because they exercise the crate's own edit vocabulary, reconciler and node dispatch; any src/ change can move these, so a narrower graph edge would omit required behavior.

The standing tests/e2e/harness.rs:97 initializer directive is included conservatively as an additional in-scope site: changed_behavior_has_e2e is suppressed for measurement switch/trace setup because hosted e2e records and recorded fold fixtures prove it; a new assertion journey would alter the measured suite. scripts/child-waits.mjs:78 uses biome-ignore lint/suspicious/noControlCharactersInRegex because job logs carry ANSI escape codes. vendor/onevcs/src/probe.rs's ignore-end was reindented without changing its reason or trace-only region. Existing file-wide directives whose directive text the spike did not write are outside the operational inventory scope.

| Existing Rust attribute site | Rules and recorded reason |
| --- | --- |
| tests/e2e/readjust.rs:941 | #[allow( clippy::too_many_lines, reason = "one journey's three republications and the two reads that answer them" )] |

Deterministic ignore validation passes on the entire new vendor/onevcs/src/spike_waits.rs module (vendor-ignore-check.log); root llmlint validate excluding unchanged vendored files passes separately. Full judged lint explicitly judged the changed vendor lines and all these reasons (history 20261115T173905Z-79b5f, zero findings).

## Retry implementation/check delta, 2026-11-15 17:10 UTC

After 0e1af3e7, judged lint found missing numerical/refusal assertions, unvalidated metadata/selector input, the manually audited fixed source selections, and unforced kernel failure fallbacks. The working tree now validates optional metadata fields and rejects unknown fields/types, represents exit/adaptive/relaunch as a closed enum, and refuses misspelled/non-Unicode selectors with exit 2. This changes only invalid measurement configurations; all four in-flight demonstrations still select the known cabae915 values. Their evidence is explicitly on cabae915 plus each demonstration commit, not on the later parser revision.

Ten fold tests pass on this working tree (fold-green4.log). Additional command assertions verify exact means/ranges/spreads/difference/share scaling, name missing baseline tests and unrecovered failures, and refuse incomplete logs and bad metadata. Red evidence: fold-mutants-red.log deliberately doubled the mean, hid missing tests and removed the incomplete-log recovery action; each corresponding new test failed. metadata-red.log first observed the metadata test fail before validation (null metadata gave an unhelpful property access failure).

The six helper-module tests pass (selector-green.log), compiling the actual vendor/onevcs/src/spike_waits.rs and actual launch_trace.rs together through scratch waits-verification/Cargo.toml, with no mock notification or trace implementation. Cargo refuses `cargo test -p onevcs --lib` because this path dependency has dev-dependencies and is not a workspace member; that refusal is recorded in vendor-waits.log and is not called a passing run. The isolated manifest points directly at the branch source files rather than copying their implementations. selector-isolated-red.log records typo/non-Unicode cases failing (exit 0 vs required 2) with validation deliberately disabled, then the original source was restored. New enum docs repair the warnings-denied build refusal from a concurrently running workspace-wiring test. Six fixture JSON files were formatted without changing their values after that same wiring test exposed their format mismatch. Its three failed cases still need a targeted recheck; no full wiring pass is claimed yet.

New narrowly scoped suppressions, authorized for never-landed measurement code by a1: scripts/child-waits.mjs before CHANGED_SITES and CHANGED_JOURNEYS explains that these are the frozen experiment’s manually audited source selections, including zero-observation sites, not a continuing producer contract. vendor/onevcs/src/spike_waits.rs marks only OpenProcess failure, PID conversion failure, out-of-int descriptor failure, pidfd_open unavailable-kernel failure, and kqueue allocation failure arms. Each retains the original bounded sleep and is not priced as an optimization; safely forcing kernel permission/resource/syscall-policy failures would change the hosted workload or mock the kernel. Existing real-child exit/already-gone tests cover the success/ESRCH paths; production adoption must separately cover unavailable-kernel, permissions and resource failures. These are site markers, not shared-rule or enforcement changes. Judged retry 2 is in progress, not yet green.

All four completed round-1 lint logs show 54 selected Nx tasks, zero Actions-cache save lines and `Nx cache: stored 0 entries, 0 bytes; replayed 0 entries` (round1-lint-facts.json derives these with the unchanged shared jobFacts reader). This zero-write statement currently applies to those four lint jobs only; test-platform cache reports await job completion.


## Retry delta at 0c710566

The comparison now requires numeric run/attempt/job metadata together, uses completed profiles plus a wholly passing tier summary or an explicit nextest PASS to establish a pass, and never promotes a provisional unfinished profile without a PASS. It classifies a rerun after the exact timestamped summary boundary (the old +1s clock tolerance applied incorrectly to same-clock nextest outcomes). Missing profile counts read `not recorded` rather than implying a test did not run. Thirteen fold tests pass (fold-green5.log); outcomes-red.log first observed the partial-identity, unfinished-profile and half-second-rerun tests fail on the prior implementation. The existing usage errors now have command-level assertions too. The fixed prototype selector remains in the never-landed vendor snapshot to give every process one inherited experiment identity; a narrowly scoped a1 reason at Variant::Relaunch explains why that measurement registration is not a repository-engine API proposal or release requirement.

The previous wiring run finished 158/161 passing; its three failures were fixture formatting and the two warnings-denied build checks during the missing-variant-docs edit. The exact fixture-isolation test now passes after formatting (wiring-format-recheck.log); the two build checks are being rerun. The expanded all-option e2e slice is running 71 tests, and the third judged pass remains in progress. No passing result is claimed for either yet.

Current primary allowance at the last read: 3,954 core requests and 3,491 GraphQL points. Reads still stop below 2,500/2,000. No new hosted demonstrations were started. Four inherited round-1 platform runs remain the measurement work in flight; no savings are concluded from local timings.


## Approved baseline: exact job durations and nextest summaries

Source: run 43684231509 attempts 1/2, each job named below; timestamped job.log and test-profile-test-OS/launch-host.json under inventory scratch 1794352-0/runs/baseline-N. GITHUB_SHA and head are the full identities stated above. Job minutes below use the jobs API start/completion timestamps. The comparison command’s job-min column instead measures the first-to-last log timestamp span, excluding runner startup/finalization padding; it is not used to price savings. Pre-e2e minutes include compilation and earlier Nx work, not solely compilation.

| Platform | Attempt/job | Processor | Logical/physical cores | Job min | Pre-e2e min | E2e nextest min | Passed/run |

| --- | --- | --- | --- | --- | --- | --- | --- |

| linux | 1/132721606859 | Intel(R) Xeon(R) 6975P-C | 4/None | 136.30 | 96.31 | 37.92 | Summary [2275.142s] 2155 tests run: 2155 passed (23 slow), 1 skipped |

| macos | 1/132721606835 | Apple M1 (Virtual) | 3/3 | 201.85 | 92.98 | 90.11 | Summary [5406.747s] 2121 tests run: 2121 passed (40 slow), 1 skipped |

| windows | 1/132721606851 | AMD EPYC 9V45 96-Core Processor                 | 4/None | 144.70 | 57.17 | 87.11 | Summary [5226.740s] 1832 tests run: 1832 passed (54 slow), 1 skipped |

| linux | 2/132799383400 | INTEL(R) XEON(R) PLATINUM 8573C | 4/None | 171.47 | 125.93 | 41.06 | Summary [2463.341s] 2155 tests run: 2155 passed (24 slow), 1 skipped |

| macos | 2/132799383592 | Apple M1 (Virtual) | 3/3 | 198.55 | 85.46 | 94.38 | Summary [5662.622s] 2121 tests run: 2121 passed (41 slow), 1 skipped |

| windows | 2/132799383582 | AMD EPYC 7763 64-Core Processor                 | 4/None | 251.52 | 92.90 | 132.99 | Summary [7979.620s] 1832 tests run: 1832 passed (134 slow), 1 skipped |

linux: before mean 39.48736 nextest minutes; range 37.91903–41.05568, spread 3.13665. Calculated from the two rows above; no option difference is yet claimed.

macos: before mean 92.24474 nextest minutes; range 90.11245–94.37703, spread 4.26458. Calculated from the two rows above; no option difference is yet claimed.

windows: before mean 110.05300 nextest minutes; range 87.11233–132.99367, spread 45.88133. Calculated from the two rows above; no option difference is yet claimed.

Compile-before-e2e evidence, attempt 1, linux job 132721606859 (first compile line and last completed compilation profile before the tier):

```text

2026-11-15T07:06:02.5777575Z    Compiling proc-macro2 v1.0.107

2026-11-15T07:15:13.6597500Z    Compiling onepipeline v0.113.1 (/io)

```

Compile-before-e2e evidence, attempt 1, macos job 132721606835 (first compile line and last completed compilation profile before the tier):

```text

not recorded

not recorded

```

Compile-before-e2e evidence, attempt 1, windows job 132721606851 (first compile line and last completed compilation profile before the tier):

```text

not recorded

not recorded

```

Compile-before-e2e evidence, attempt 2, linux job 132799383400 (first compile line and last completed compilation profile before the tier):

```text

2026-11-15T12:51:16.6108168Z    Compiling proc-macro2 v1.0.107

2026-11-15T13:03:36.8757471Z    Compiling onepipeline v0.113.1 (/io)

```

Compile-before-e2e evidence, attempt 2, macos job 132799383592 (first compile line and last completed compilation profile before the tier):

```text

not recorded

not recorded

```

Compile-before-e2e evidence, attempt 2, windows job 132799383582 (first compile line and last completed compilation profile before the tier):

```text

not recorded

not recorded

```

## Baseline named-test reconciliation

Local source read on 0c710566; baseline-named-proof.json in this retry scratch records every name and its run/tier identity. Each set size equals the entirely passing nextest summary. macOS/Windows names come from completed main-tier test-profile records. Linux retains 2,154 completed main-tier records; the missing name is `loopcost::the_settlement_readability_latency_is_reported_from_its_journal_stamps`, whose later budgets invocation overwrote its aggregate profile. Its original in-tier launch-trace starts plus the all-passed nextest summary complete the named set. This proves the name ran/passed; it does not recover the overwritten wall/category/wait aggregates. The fold therefore still prints 2,154 profile-backed Linux passes, and this explicit reconciliation supplies the additional name for the report’s later after-side comparison. No Linux aggregate profile precision is claimed beyond the inventory’s bound.

linux: attempts 1/2 have identical named sets of 2155/2155 passing tests; jobs 132721606859/132799383400.

macos: attempts 1/2 have identical named sets of 2121/2121 passing tests; jobs 132721606835/132799383592.

windows: attempts 1/2 have identical named sets of 1832/1832 passing tests; jobs 132721606851/132799383582.

Linux attempt 1: 3 original in-scope start records for the overwritten name; retained later profile run id `cb6fded2-89ca-4e77-b236-e5505937b057`. Source: job 132721606859, test-profile-test-linux/launch/loopcost__the_settlement_readability_latency_is_reported_from_its_journal_stamps.jsonl, scoped to main nextest id 21fd59ea-9add-43aa-abae-0fd219c703a7.

Linux attempt 2: 5 original in-scope start records for the overwritten name; retained later profile run id `3e32a0c6-a2c0-4a30-ae1d-79e91633bc7f`. Source: job 132799383400, test-profile-test-linux/launch/loopcost__the_settlement_readability_latency_is_reported_from_its_journal_stamps.jsonl, scoped to main nextest id 2077affc-b3f8-4207-9d22-fc387055d3ae.

## Manager a39/a40: notification proof and producer freeze

Ruling a40 supersedes a39’s narrower assumption: round 1 at cabae915 counts, despite the later validated selector, provided the diff is shown and every later round uses one frozen producer revision. No in-flight demonstration branch was changed. Producer revision 4ee92293 has the same syscalls, intervals and unit-returning callers for every known selection; its differences from cabae915 are the typed/validated selector (af3fdcd9), documentation/site reasons, and test-only outcome recording/assertions. The selector changes invalid configurations (typos/non-Unicode now exit 2), not which waits the known exit/adaptive/relaunch selections choose. The observation macro’s non-test expansion is exactly the original discarded-result syscall statement; only cfg(test) retains and classifies the kernel result. No new runtime notification algorithm or interval is introduced. No numerical correction for selector representation is invented; the older producer identity is explicit.

Seven helper tests pass on 4ee92293 (notification-green.log), including real child exit, already-gone PID and a child held alive on its stdin pipe until the test releases/reaps it. They assert the kernel Exited/Bound outcome and live-child status, with no elapsed-time comparison. notification-red-cleanup.log first observed all three outcome assertions fail before recording was added. The warnings-denied real onevcs library check passes (frozen-producer-check.log); macOS/Windows target test-compilation checks are in progress. The 71 real-binary journey slice passed on af3fdcd9; 4ee92293’s observation-only changes are cfg(test) and do not enter the dependency library that those journeys execute. Its exact-source diff follows. The two build-reuse tests now pass serially (wiring-build-serial.log), after the concurrent build run’s missing-metadata/recompilation refusal. No shared enforcement changed.

Every later hosted round must use this one frozen producer, plus its selected constant and the same demonstration-only read-only/optimized-dependency/src edits. Any further producer change requires a new manager ruling. Reader/report refinements are identified separately and do not silently revise timed code.

```diff
diff --git a/tests/e2e/harness.rs b/tests/e2e/harness.rs
index 8d338941..0afa3ebb 100644
--- a/tests/e2e/harness.rs
+++ b/tests/e2e/harness.rs
@@ -68,15 +68,15 @@ pub mod spike_variant {
     /// names them.
     pub const SELECTED: &str = "";
 
-    /// Whether `name` is in effect: [`SELECTED`], unless the environment this test
+    /// Whether `variant` is in effect: [`SELECTED`], unless the environment this test
     /// process started in already chose, which is how a local slice tries one.
-    fn is_selected(name: &str) -> bool {
-        onevcs::spike_waits::is_selected(name)
+    fn is_selected(variant: onevcs::spike_waits::Variant) -> bool {
+        onevcs::spike_waits::is_selected(variant)
     }
 
     /// Whether the journeys that re-launch the CLI for one reading read it once.
     pub fn relaunch() -> bool {
-        is_selected("relaunch")
+        is_selected(onevcs::spike_waits::Variant::Relaunch)
     }
 
     /// The pause before the `looks`-th look again of a harness wait polling every
@@ -84,7 +84,9 @@ pub mod spike_variant {
     /// first and backing off to it. A wait every quarter second or longer is left as
     /// it is, because its predicate starts a process or re-reads a whole journal.
     pub fn pause(interval: std::time::Duration, looks: u32) -> std::time::Duration {
-        if !is_selected("adaptive") || interval >= std::time::Duration::from_millis(250) {
+        if !is_selected(onevcs::spike_waits::Variant::Adaptive)
+            || interval >= std::time::Duration::from_millis(250)
+        {
             return interval;
         }
         onevcs::spike_waits::backoff(looks, std::time::Duration::from_millis(1), interval)
diff --git a/vendor/onevcs/src/spike_waits.rs b/vendor/onevcs/src/spike_waits.rs
index 7a2069ea..c7d07a7a 100644
--- a/vendor/onevcs/src/spike_waits.rs
+++ b/vendor/onevcs/src/spike_waits.rs
@@ -24,32 +24,94 @@ use std::time::{Duration, Instant};
 /// The switch.
 pub const ENV: &str = "ONEPIPELINE_SPIKE_CHILD_WAITS";
 
-fn selected() -> &'static [String] {
-    static SELECTED: OnceLock<Vec<String>> = OnceLock::new();
+/// The closed vocabulary of this measurement's independently selectable options.
+#[derive(Clone, Copy, Debug, Eq, PartialEq)]
+pub enum Variant {
+    /// Wake on a child exit or finished output capture.
+    Exit,
+    /// Start file polls short and cap at their original interval.
+    Adaptive,
+    // llmlint: ignore[code_lands_in_the_domain_that_owns_it] Measurement-only shared switch, never landed (a1): every child inherits one selection so artifacts identify the entire experiment, but only onepipeline's harness reads Relaunch. This vendored helper is not a repository-engine API proposal; the report explicitly requires R to land in onepipeline tests alone with no onevcs release.
+    /// Reuse stable CLI readings inside the selected journeys.
+    Relaunch,
+}
+
+fn invalid_selection(reason: &str) -> ! {
+    eprintln!("{ENV}: {reason}; expected a comma-separated list of exit, adaptive, relaunch");
+    std::process::exit(2)
+}
+
+fn selected() -> &'static [Variant] {
+    static SELECTED: OnceLock<Vec<Variant>> = OnceLock::new();
     SELECTED.get_or_init(|| {
-        std::env::var(ENV)
-            .unwrap_or_default()
+        let value = match std::env::var(ENV) {
+            Ok(value) => value,
+            Err(std::env::VarError::NotPresent) => String::new(),
+            Err(std::env::VarError::NotUnicode(_)) => invalid_selection("not valid Unicode"),
+        };
+        value
             .split(',')
             .map(str::trim)
             .filter(|name| !name.is_empty())
-            .map(str::to_owned)
+            .map(|name| match name {
+                "exit" => Variant::Exit,
+                "adaptive" => Variant::Adaptive,
+                "relaunch" => Variant::Relaunch,
+                _ => invalid_selection(&format!("unknown prototype {name:?}")),
+            })
             .collect()
     })
 }
 
 /// Whether the named prototype is in effect in this process.
-pub fn is_selected(name: &str) -> bool {
-    selected().iter().any(|chosen| chosen == name)
+pub fn is_selected(variant: Variant) -> bool {
+    selected().contains(&variant)
 }
 
 /// Whether exit notification is in effect.
 pub fn exit_notify() -> bool {
-    is_selected("exit")
+    is_selected(Variant::Exit)
 }
 
 /// Whether adaptive polls are in effect.
 pub fn adaptive() -> bool {
-    is_selected("adaptive")
+    is_selected(Variant::Adaptive)
+}
+
+// Test-only observation of the actual kernel result. Production callers and
+// their syscalls/intervals stay unchanged; no elapsed-time inference is needed.
+#[cfg(test)]
+#[derive(Clone, Copy, Debug, Eq, PartialEq)]
+enum Notification {
+    Exited,
+    Bound,
+    Unavailable,
+}
+
+#[cfg(test)]
+thread_local! {
+    static NOTIFICATION: std::cell::Cell<Option<Notification>> = const { std::cell::Cell::new(None) };
+}
+
+#[cfg(test)]
+fn observed(notification: Notification) {
+    NOTIFICATION.with(|last| last.set(Some(notification)));
+}
+
+// One syscall expression for both builds; only unit-test builds retain its
+// outcome. The non-test expansion is the original discarded-result statement.
+macro_rules! observe_wait {
+    ($call:expr, $result:ident => $notification:expr) => {{
+        #[cfg(test)]
+        {
+            let $result = $call;
+            observed($notification);
+        }
+        #[cfg(not(test))]
+        {
+            $call;
+        }
+    }};
 }
 
 /// Wait at most `upto` for `child` to exit, returning as soon as it does.
@@ -89,7 +151,16 @@ pub fn await_pid_exit(site: crate::launch_trace::Site, pid: u32, upto: Duration)
         // answer (a process already gone, or one this user cannot open) is
         // waited out as a plain sleep would have been.
         let handle = unsafe { OpenProcess(PROCESS_SYNCHRONIZE, 0, pid) };
+        // llmlint: ignore[changed_behavior_has_e2e] Measurement-only fallback, never landed (a1): portable hosted journeys cannot safely force OpenProcess access failure without mocking the kernel or changing host privileges. It keeps the old bounded sleep on failure; successful and already-gone child paths are exercised. Production adoption must cover platform permission failures separately.
         if handle.is_null() {
+            #[cfg(test)]
+            observed(
+                if std::io::Error::last_os_error().raw_os_error() == Some(87) {
+                    Notification::Exited
+                } else {
+                    Notification::Unavailable
+                },
+            );
             // ERROR_INVALID_PARAMETER: no such process, so it is already gone.
             if std::io::Error::last_os_error().raw_os_error() != Some(87) {
                 std::thread::sleep(upto);
@@ -116,26 +187,41 @@ fn wait_handle(handle: std::os::windows::raw::HANDLE, upto: Duration) {
     let millis = u32::try_from(upto.as_millis()).unwrap_or(u32::MAX - 1);
     // SAFETY: the handle is live for the call; the wait only reads its state.
     unsafe {
-        WaitForSingleObject(handle as _, millis);
+        observe_wait!(WaitForSingleObject(handle as _, millis), ready => match ready {
+            windows_sys::Win32::Foundation::WAIT_OBJECT_0 => Notification::Exited,
+            windows_sys::Win32::Foundation::WAIT_TIMEOUT => Notification::Bound,
+            _ => Notification::Unavailable,
+        });
     }
 }
 
 #[cfg(target_os = "linux")]
 fn await_pid(pid: u32, upto: Duration) {
+    // llmlint: ignore[changed_behavior_has_e2e] Measurement-only fallback, never landed (a1): real spawned PIDs fit pid_t, so this defensive conversion arm is outside the hosted workload. It retains the caller's bounded sleep; no saving is attributed to it, and testing an invented PID is not a realistic child journey.
     let Ok(raw) = libc::pid_t::try_from(pid) else {
+        #[cfg(test)]
+        observed(Notification::Unavailable);
         return std::thread::sleep(upto);
     };
     // SAFETY: `pidfd_open` takes a pid and flags and returns a descriptor this
     // function owns, or -1.
     let descriptor = unsafe { libc::syscall(libc::SYS_pidfd_open, raw, 0) };
+    // llmlint: ignore[changed_behavior_has_e2e] Measurement-only fallback, never landed (a1): the kernel returns an int descriptor, so an out-of-int syscall result is defensive only. Resource exhaustion or syscall interception would change the measured host; this preserves the old bounded sleep and is not priced as an optimization.
     let Ok(descriptor) = libc::c_int::try_from(descriptor) else {
+        #[cfg(test)]
+        observed(Notification::Unavailable);
         return std::thread::sleep(upto);
     };
+    // llmlint: ignore[changed_behavior_has_e2e] Measurement-only fallback, never landed (a1): safely forcing pidfd_open to be unavailable requires a different kernel/seccomp policy, outside these hosted runners. ESRCH is exercised by the already-gone child test; other errors keep the original bounded sleep. Production adoption must validate unsupported-kernel behavior.
     if descriptor < 0 {
         // ESRCH: the process is already gone, and that is the answer.
         if std::io::Error::last_os_error().raw_os_error() == Some(libc::ESRCH) {
+            #[cfg(test)]
+            observed(Notification::Exited);
             return;
         }
+        #[cfg(test)]
+        observed(Notification::Unavailable);
         return std::thread::sleep(upto);
     }
     let mut watched = libc::pollfd {
@@ -146,7 +232,15 @@ fn await_pid(pid: u32, upto: Duration) {
     let millis = libc::c_int::try_from(upto.as_millis()).unwrap_or(libc::c_int::MAX);
     // SAFETY: one descriptor owned here, live for the call; closed once after.
     unsafe {
-        libc::poll(&raw mut watched, 1, millis);
+        observe_wait!(libc::poll(&raw mut watched, 1, millis), ready => {
+            if ready == 0 {
+                Notification::Bound
+            } else if ready > 0 && watched.revents & (libc::POLLIN | libc::POLLHUP) != 0 {
+                Notification::Exited
+            } else {
+                Notification::Unavailable
+            }
+        });
         libc::close(descriptor);
     }
 }
@@ -155,7 +249,10 @@ fn await_pid(pid: u32, upto: Duration) {
 fn await_pid(pid: u32, upto: Duration) {
     // SAFETY: a fresh kqueue this function owns and closes below.
     let queue = unsafe { libc::kqueue() };
+    // llmlint: ignore[changed_behavior_has_e2e] Measurement-only fallback, never landed (a1): kqueue allocation failure cannot be forced safely in the hosted workload without exhausting descriptors or mocking the kernel. This retains the caller's bounded sleep; no saving is claimed for it, and production adoption must validate that resource-failure branch.
     if queue < 0 {
+        #[cfg(test)]
+        observed(Notification::Unavailable);
         return std::thread::sleep(upto);
     }
     let change = libc::kevent {
@@ -175,14 +272,25 @@ fn await_pid(pid: u32, upto: Duration) {
     // is closed once after. A registration refused with ESRCH is a process
     // already exited, which returns at once, as it should.
     unsafe {
-        libc::kevent(
+        observe_wait!(libc::kevent(
             queue,
             &raw const change,
             1,
             &raw mut fired,
             1,
             &raw const timeout,
-        );
+        ), ready => {
+            if ready == 0 {
+                Notification::Bound
+            } else if (ready > 0 && (fired.flags & libc::EV_ERROR == 0
+                || fired.data == libc::ESRCH as libc::intptr_t))
+                || (ready < 0 && std::io::Error::last_os_error().raw_os_error() == Some(libc::ESRCH))
+            {
+                Notification::Exited
+            } else {
+                Notification::Unavailable
+            }
+        });
         libc::close(queue);
     }
 }
@@ -192,6 +300,8 @@ fn await_pid(pid: u32, upto: Duration) {
     not(any(target_os = "linux", target_os = "macos", target_os = "ios"))
 ))]
 fn await_pid(_pid: u32, upto: Duration) {
+    #[cfg(test)]
+    observed(Notification::Unavailable);
     std::thread::sleep(upto);
 }
 
@@ -219,39 +329,115 @@ mod tests {
         assert_eq!(backoff(u32::MAX, first, ceiling), ceiling);
     }
 
+    fn notification(wait: impl FnOnce()) -> Option<Notification> {
+        NOTIFICATION.with(|last| last.set(None));
+        wait();
+        NOTIFICATION.with(std::cell::Cell::take)
+    }
+
     #[test]
-    fn a_wait_on_a_child_returns_at_its_exit_rather_than_at_its_bound() {
+    fn a_wait_on_a_child_reports_its_exit_notification() {
         let mut child = quick_child();
-        let began = Instant::now();
-        let bound = Duration::from_secs(20);
-        let mut exited = None;
-        while began.elapsed() < bound {
-            if let Some(status) = child.try_wait().expect("the child can be asked about") {
-                exited = Some(status);
-                break;
-            }
-            await_child_exit(&child, bound);
-        }
-        if exited.is_none() {
-            let _ = child.kill();
-        }
-        let _ = child.wait();
-        assert!(exited.is_some(), "the child never exited");
-        assert!(
-            began.elapsed() < Duration::from_secs(10),
-            "the wait ran to its bound: {:?}",
-            began.elapsed()
-        );
+        let result = notification(|| await_child_exit(&child, Duration::from_secs(20)));
+        let status = child.wait().expect("the child is reaped");
+        assert_eq!(result, Some(Notification::Exited));
+        assert!(status.success());
     }
 
     #[test]
-    fn a_wait_on_a_pid_already_gone_returns_without_waiting_its_bound() {
+    fn a_wait_on_a_pid_already_gone_reports_it_exited() {
         let mut child = quick_child();
         let pid = child.id();
-        child.wait().expect("the child is reaped");
-        let began = Instant::now();
-        await_pid_exit(crate::launch_site!(), pid, Duration::from_secs(20));
-        assert!(began.elapsed() < Duration::from_secs(10));
+        assert!(child.wait().expect("the child is reaped").success());
+        let result = notification(|| {
+            await_pid_exit(crate::launch_site!(), pid, Duration::from_secs(20));
+        });
+        assert_eq!(result, Some(Notification::Exited));
+    }
+
+    #[test]
+    fn a_live_child_reaches_the_wait_bound_and_remains_alive_until_released() {
+        #[cfg(windows)]
+        let mut command = std::process::Command::new("cmd");
+        #[cfg(windows)]
+        command.args(["/C", "set /p answer= & exit /b 0"]);
+        #[cfg(not(windows))]
+        let mut command = std::process::Command::new("sh");
+        #[cfg(not(windows))]
+        command.args(["-c", "read answer; exit 0"]);
+        let mut child = command
+            .stdin(std::process::Stdio::piped())
+            .spawn()
+            .expect("the held child starts");
+        let result = notification(|| await_child_exit(&child, Duration::from_millis(10)));
+        let still_live = child
+            .try_wait()
+            .expect("the held child can be read")
+            .is_none();
+        drop(child.stdin.take());
+        let status = child
+            .wait()
+            .expect("closing stdin releases and reaps the child");
+        assert_eq!(result, Some(Notification::Bound));
+        assert!(still_live, "the child exited before being released");
+        assert!(status.success());
+    }
+
+    #[test]
+    fn selection_probe() {
+        println!("selected={:?}", selected());
+    }
+
+    #[test]
+    fn the_selector_reads_only_known_variants_and_refuses_a_typo_in_a_fresh_process() {
+        let probe = |value: &str| {
+            std::process::Command::new(std::env::current_exe().expect("the test binary"))
+                .args([
+                    "--exact",
+                    "spike_waits::tests::selection_probe",
+                    "--nocapture",
+                ])
+                .env(ENV, value)
+                .output()
+                .expect("the selector probe starts")
+        };
+        for (value, expected) in [
+            ("", "selected=[]"),
+            ("exit", "selected=[Exit]"),
+            ("adaptive", "selected=[Adaptive]"),
+            ("relaunch", "selected=[Relaunch]"),
+            (
+                "exit, adaptive,relaunch",
+                "selected=[Exit, Adaptive, Relaunch]",
+            ),
+        ] {
+            let output = probe(value);
+            assert!(output.status.success(), "{output:?}");
+            assert!(
+                String::from_utf8_lossy(&output.stdout).contains(expected),
+                "{output:?}"
+            );
+        }
+        let output = probe("adpative");
+        assert_eq!(output.status.code(), Some(2));
+        assert!(String::from_utf8_lossy(&output.stderr).contains("unknown prototype"));
+    }
+
+    #[cfg(unix)]
+    #[test]
+    fn a_non_unicode_selector_is_refused_in_a_fresh_process() {
+        use std::os::unix::ffi::OsStringExt as _;
+        let output = std::process::Command::new(std::env::current_exe().expect("the test binary"))
+            .args([
+                "--exact",
+                "spike_waits::tests::selection_probe",
+                "--nocapture",
+            ])
+            .env(ENV, std::ffi::OsString::from_vec(vec![0xff]))
+            .output()
+            .expect("the selector probe starts");
+        assert_eq!(output.status.code(), Some(2));
+        assert!(String::from_utf8_lossy(&output.stderr).contains("not valid Unicode"));
     }
 
     fn quick_child() -> Child {
```


## Local verification checkpoint at ebd52af2 (producer remains frozen at 4ee92293)

Full spike-diff judged lint, excluding unchanged vendor lines via the diff, is green: history 20261115T173905Z-79b5f, 18 passed / 0 failed (judged4.log). That run read the producer and the prior reader; a separately scoped judged pass is running on the two reader files after ebd52af2. The new reader command test was first observed failing on the earlier reader (quiet-tier-red.log), then all 14 fold tests passed (fold-green-final.log). It infers completed profiles passed in a quiet log only when every failure counted by the summary is named, excluding those failures; otherwise it requires explicit PASS lines. This avoids both treating unfinished records as passes and dropping quiet Linux successes on a failed tier. No producer file changed after 4ee92293.

The actual helper and trace modules cross-compile with their tests for aarch64-apple-darwin and x86_64-pc-windows-msvc (check-TARGET.log); these are compilation proofs, not macOS/Windows executions. Seven helper tests execute and pass on this Linux host. Main onevcs library compilation with warnings denied is green on the repository lock; the two build-reuse checks are being rerun after the test-only observer source change to close their source-input evidence too. Existing 71-journey runtime evidence remains on af3fdcd9 and is explicitly inert under a40’s test-only changes.


## Current handoff — 2026-11-15 18:18 UTC

Hosted test-platform measurements collected: none yet. The four inherited demonstrations remain in flight with the run/merge/head identities above. E/A/R macOS jobs remain queued; base #1616 macOS is now running, and all eight Linux/Windows jobs are running (jobs API read at 17:58 UTC). Four lint jobs have been read, each with zero cache writes; no test-platform final cache report is yet available. No new demonstration, cancellation, or push to an in-flight demonstration branch has occurred. The next free slots still belong to git-reads and engine-startup under c11.2/c12.0/a33. All later option rounds use frozen producer 4ee92293 under a40. Inventory attempts 1/2 remain the primary before side; own base is an additional diagnostic point pending comparability, not a silent replacement.

Local branch head 327d8551: 23 fold command tests pass (a46-final-tests.log); 7 real helper/selector tests pass on Linux (notification-green.log); actual module tests compile for macOS and Windows (check-TARGET.log); warnings-denied real onevcs library compilation passes. The 71 real-binary journeys passed on af3fdcd9, whose runtime behavior is unchanged by a40’s test-only observation changes. Full-diff judged lint on the producer/prior reader passed 18 rules (history 20261115T173905Z-79b5f). The later reader’s bounded final judgment is NOT green: history 20261115T181435Z-f2378, 5 passed / 3 failed, as documented below. No global or inherited rule was weakened. Source-diff verification confirms producer files still match 4ee92293.

The four a46 cases now use heterogeneous waits with an absent site, heterogeneous journey-launch counts with an absent journey, two distinct before passing-name sets, and malformed JSON. All four assertions were observed failing with deliberately corrupted aggregation/union/exit-status implementations (a46-mutants-red.log), the source was restored, then all 23 tests passed. These are intentional negative-state proofs, not failures of the finished implementation. Other newly covered paths include ANSI/TIMEOUT/signal/LEAK-FAIL/EXEC-FAIL outcomes, malformed timestamps, nonterminal SLOW exclusion, wait seconds/harness totals, processor identity, log spans and missing-host/no-observation output. Successful LEAK warnings remain passes while LEAK-FAIL remains failure (leak-red.log first observed the incorrect classification, reader-green19.log/23-test runs prove the fix).

## Bounded judged-reader limitations (manager a46)

The manager’s a46 instruction was: “One pass and one rerun; anything still raised after that goes in the report's limitations, not another repair round.” Following it, no further reader repair was made after history 20261115T181435Z-f2378. This qualifies the original unbounded green-reader-lint bar; it is not a claim that the three findings passed.

1. boundary_inputs_validated, scripts/child-waits.mjs:80–81: the terminal-result parser accepts arbitrary uppercase status words with a seconds-duration shape. An unknown/nonterminal word of that shape could be attributed as failure. It excludes the observed SLOW shape and malformed timestamps, but it does not validate an exhaustive producer vocabulary.
2. changed_behavior_has_e2e, scripts/child-waits.mjs:178–180: the conservative inference fallback when the summary counts an unnamed failure lacks a dedicated subprocess assertion. Named-failure and unfinished-profile paths are tested; this specific missing-attribution case is not claimed proven.
3. contracts_have_one_source_or_a_drift_gate, scripts/child-waits.mjs:83–85: PASS/LEAK success semantics are consumer-maintained; recorded-fixture mutations do not independently prove future/pinned nextest producer compatibility.

For real-run evidence, compare named outcomes and summary counts with the retained raw logs and profile records, and expose any unrecognized status rather than silently claiming equivalence. No option price is accepted from an incomplete or contradictory passed-test set. No numerical correction for these limitations is invented.

## Controlled build-reuse result (manager a43)

The no-recompile assertion at npm/test/workspace-nx.test.mjs:1415 recurred after a source edit even though _crate-build itself passed. It had passed serially on 0c710566, but the later frozen-source attempt recompiled the normal onevcs/onepipeline context. Cargo-tree reads show the dev graph enables onevcs/testing through onevcs-testing whereas the no-dev graph does not; this is evidence of differing feature graphs, not a proven complete causal diagnosis. Per a43, one complete default build with RUSTFLAGS=-D warnings was run on the frozen producer, followed by exactly one targeted no-recompile assertion. Both passed (a43-default-build.exit = 0, a43-recheck.log = 1/1 passed). No further retry and no enforcement edit were made. The general cold-feature-graph build-proof question is recorded as unverified nonblocking draft drafts:brief-process-launch-speed-2026-11-14-spikes/drafts/20261115T175127Z-verify-whether-the-no-recompile-build-proof-cove.

## Common demonstration inputs verified from git objects

All four round-1 heads have Cargo.toml blob d95eed3341f21cfccf8e0fc309d3904325998617, including [profile.dev.package."*"] opt-level = 2; and src/lib.rs blob 563b327b22f01e50c02c8743ef5dc6cfdd9894ec, the byte-identical no-behaviour source edit. Their selected constants are exit/adaptive/relaunch/empty respectively (round1-common-inputs.json, git object reads on 327d8551). Executed workflow blob db2bbe081a7b9319eb38bd014e72350b389e8b01 is also identical to the approved baseline’s read-only workflow. Test-platform zero-write evidence still awaits completed logs.


## First hosted R point — Linux, incomplete sample (2026-11-15 18:37 UTC)

R run 43736265323 / attempt 1 / [test-linux job 132879430099](https://github.com/nickderobertis/onepipeline/actions/runs/43736265323/job/132879430099) completed. GITHUB_SHA 7b56610e75bdec33e277d44b3e442521f35fe0bb, head c22459bfda17d6a6ad10e322ff607e70eb56a68e (producer cabae915 plus R selection and the common demonstration edits). Workflow blob db2bbe081a7b9319eb38bd014e72350b389e8b01. Processor Intel(R) Xeon(R) 6975P-C, 4 logical cores, from artifact test-profile-test-linux/launch-host.json.

Job duration is 115.33 minutes from the jobs API timestamps; its log span is 115.30 minutes. The e2e tier starts 75.93 minutes into that log, after compilation/earlier Nx work, and nextest reports 2,245.314 seconds = 37.42190 minutes, 2,155/2,155 passed. Overall job failure is retained as failure, not called a green CI job: the patch-pin refusal prevents the coverage merge, as below. Its selected 37 Nx tasks are byte-for-byte the same set as both Linux baseline points (first-linux-R-facts.json and baseline facts source). No test body is excused by that status.

Artifact id 14174882487, test-profile-test-linux, compressed 35388112 bytes; zip SHA-256 596036b4d9bde6ebe672b1692396255fbfb80f80e7e7897ffd82f94a49220570. Raw job.log SHA-256 0885eac00a67e19f6f5027428f7575ee94cc26df6e52451dc2b9984626dfc88d. The artifact’s 2,155 completed main-tier test-profile names equal the union of the approved baseline’s 2,155 names, with no missing or extra name. All main-tier records survive here; unlike the two baseline artifacts there is no overwritten profile requiring trace reconciliation. The wholly passing nextest summary establishes their success. No main-tier failed-and-recovered e2e name is present (relaunch-linux-round1-proof.json and the comparison output).

One command run on cf6b33a1:

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-linux before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-linux after:relaunch-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736265323/1/test-linux
```

Its output follows verbatim. The before rows abbreviate the logged merge SHA; the full baseline GITHUB_SHA is 37341b0a57e77d18f6db6c11c1b32d7b30fb8dac as identified above. This is 2 approved before points against only 1 after point: **not the required completed 3-run after comparison**. The command’s -2.07-minute difference is inside the before side’s 3.14-minute spread, so it is undecided. Its -1.86-minute typical-PR figure is provisional arithmetic (0.9 times that first-point mean difference), not an accepted expected saving. R is not included in a combination on this evidence.

```text
## 2 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| after | 43736265323/1/132879430099 (relaunch-1) | 7b56610e75bdec33e277d44b3e442521f35fe0bb | c22459bfda17d6a6ad10e322ff607e70eb56a68e | Intel(R) Xeon(R) 6975P-C (4) | 115.30 | 75.93 | 37.42 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 39.49 | 37.92–41.06 | 3.14 |
| after | 37.42 | 37.42–37.42 | 0.00 |

Difference, after − before: -2.07 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -1.86 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25264.5 | 0.0 | 2228.0 | 26004.0 | 0.0 | 2146.2 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1729.0 | 0.0 | 34.7 | 1740.0 | 0.0 | 34.9 |
| onepipeline::commandstep::run | wait | 18.0 | 213.5 | 9.9 | 18.0 | 212.0 | 9.8 |
| onepipeline::dispatchenv::run | wait | 97.0 | 311.0 | 10.9 | 97.0 | 312.0 | 10.9 |
| onepipeline::driver::attach | sleep | 37015.5 | 0.0 | 1854.5 | 34838.0 | 0.0 | 1744.8 |
| onepipeline::driver::confirm_driving | sleep | 1436.0 | 0.0 | 72.0 | 1434.0 | 0.0 | 71.9 |
| onepipeline::driver::submit_offered | sleep | 4243.0 | 0.0 | 212.5 | 4211.0 | 0.0 | 210.9 |
| onepipeline::hooks::run | wait | 111.5 | 831.5 | 36.1 | 111.0 | 829.0 | 36.0 |
| onepipeline::planedit::run | wait | 32.0 | 461.0 | 8.6 | 32.0 | 462.0 | 8.7 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.0 | 6.9 | 78.0 | 213.0 | 6.8 |
| onepipeline::sys::gone_within | sleep | 2692.0 | 0.0 | 54.0 | 2668.0 | 0.0 | 53.5 |
| onepipeline::vcs::follow | sleep | 45581.0 | 0.0 | 916.1 | 47382.0 | 0.0 | 951.6 |
| onevcs::git::bounded | wait | 364937.5 | 871189.5 | 1249.7 | 363429.0 | 863015.0 | 1221.0 |
| onevcs::pool::maintain::run | wait | 35.0 | 2458.5 | 24.2 | 35.0 | 2445.0 | 24.0 |
| onevcs::probe::read | wait | 353.0 | 738.5 | 0.6 | 350.0 | 731.0 | 0.5 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 9.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 2.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 2.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 2.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 5.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 5.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 6.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 9.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 8.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 8.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 4.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 7.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 4.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 3.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after relaunch-1: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
```

Across the 17 changed journeys, those output rows total 142.0 baseline-mean direct CLI launches versus 119.0 in this after point: 23 fewer launches, not 23 measured minutes. One changed adoption-check journey has 31.0 launches on both sides because removing a final read does not fix how many state-poll reads the run needs. The output lists each journey separately rather than claiming they all have a measured count reduction. Wait seconds are overlapping sums at individual sites; they are not added to estimate wall-time savings.

Cache restores, from this job’s timestamped cache steps through the shared jobFacts reader (seconds are each logged step span, not a separate fresh measurement):

| Step | Result | Seconds |
| --- | --- | ---: |
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.003 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 54.423 |
| actions/setup-node@v4 | no restore | 3.955 |
| actions/setup-python@v5 | miss | 5.409 |
| astral-sh/setup-uv@v6 | no restore | 1.842 |
| actions/cache/restore@v4 | hit | 0.538 |

The final cache report says `Nx cache: stored 0 entries, 0 bytes; replayed 0 entries`; Actions-cache save lines: 0. These are this completed Linux job’s evidence, not a claim about the still-running jobs. The executed read-only workflow guards are unchanged.

Merged Linux line coverage was not produced; the unchanged floor is 95.74 LCOV (95% line-coverage policy). This job’s exact log reason follows (same source/job above):

```text
2026-11-15T17:06:41.8552900Z     the patch of `oneagentgraph` is not a git source
2026-11-15T18:29:42.5213836Z Tasks not run because their dependencies failed or --nx-bail=true:
2026-11-15T18:29:42.5214185Z - onepipeline:test
2026-11-15T18:29:54.0744518Z     the patch of `oneagentgraph` is not a git source
2026-11-15T18:29:59.1894245Z     the patch of `oneagentgraph` is not a git source
2026-11-15T18:30:07.8973247Z     the patch of `oneagentgraph` is not a git source
```

Handoff: R Linux read and folded. All four workflows remain in flight overall; no demonstration is closed while its other platforms are running/queued. E/A/R need further after points on every platform, R still needs two more Linux points plus all macOS/Windows points, and any combination still depends on decided option savings. Producer remains frozen at 4ee92293, and next free slots go to the sibling spikes first.


## First hosted exit point — Linux, incomplete sample

Run 43736250019/attempt 1, [test-linux job 132879382741](https://github.com/nickderobertis/onepipeline/actions/runs/43736250019/job/132879382741); GITHUB_SHA 8a18672992559a9088d2527a71de265522e7f84f; head 9ba119ba96fa4544cea8889a2c809e9d01e65a84, producer cabae915 plus the selected constant/common edits. Executed workflow blob db2bbe081a7b9319eb38bd014e72350b389e8b01. Overall job conclusion: failure, retained as such; this is not a green-CI claim.

API job duration 128.63 minutes. The output below separately labels log-span and pre-e2e minutes (compile/earlier work), and uses the actual nextest summary for e2e minutes. Processor: AMD EPYC 9V74 80-Core Processor, 4 logical cores. Source: this job’s test-profile-test-linux artifact, id 14175181901, compressed 35730438 bytes; zip SHA-256 3081876f968cc03f1310a26bc06fe8290f3fcb3ef82ce55d5e75d8f9f79a48cc; job.log SHA-256 2d10d1a9ab60f48e953a11712cd14f1685785f4a44e1209d6eef950995305474.

The 2,155 completed main-tier profile names exactly equal the approved baseline union, with no missing/extra name and no overwritten profile here. The main tier passed 2,155/2,155, with no profile attempt over one. All 37 selected Nx tasks match both approved Linux baseline sets. These facts are retained in exit-linux-round1-proof.json and its facts sidecar.

One command, run on 5caad1a7:

```sh

node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-linux before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-linux after:exit-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736250019/1/test-linux

```

Output, verbatim. This is only one after point; its arithmetic cannot replace the required three-run comparison. The first-point difference is inside the baseline spread, so no saving or cost is decided and no combination is justified from it. Typical-PR minutes printed below are provisional scaled estimates, not an accepted price.

```text

## 2 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| after | 43736250019/1/132879382741 (exit-1) | 8a18672992559a9088d2527a71de265522e7f84f | 9ba119ba96fa4544cea8889a2c809e9d01e65a84 | AMD EPYC 9V74 80-Core Processor (4) | 128.57 | 85.91 | 39.93 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 39.49 | 37.92–41.06 | 3.14 |
| after | 39.93 | 39.93–39.93 | 0.00 |

Difference, after − before: 0.44 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 0.40 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25264.5 | 0.0 | 2228.0 | 25131.0 | 0.0 | 2235.7 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1729.0 | 0.0 | 34.7 | 1730.0 | 0.0 | 34.7 |
| onepipeline::commandstep::run | wait | 18.0 | 213.5 | 9.9 | 18.0 | 212.0 | 9.3 |
| onepipeline::dispatchenv::run | wait | 97.0 | 311.0 | 10.9 | 97.0 | 309.0 | 7.4 |
| onepipeline::driver::attach | sleep | 37015.5 | 0.0 | 1854.5 | 36192.0 | 0.0 | 1814.6 |
| onepipeline::driver::confirm_driving | sleep | 1436.0 | 0.0 | 72.0 | 1470.0 | 0.0 | 73.7 |
| onepipeline::driver::submit_offered | sleep | 4243.0 | 0.0 | 212.5 | 3837.0 | 0.0 | 192.2 |
| onepipeline::hooks::run | wait | 111.5 | 831.5 | 36.1 | 114.0 | 836.0 | 31.1 |
| onepipeline::planedit::run | wait | 32.0 | 461.0 | 8.6 | 32.0 | 463.0 | 8.2 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.0 | 6.9 | 78.0 | 215.0 | 3.4 |
| onepipeline::sys::gone_within | sleep | 2692.0 | 0.0 | 54.0 | 860329.0 | 0.0 | 42.0 |
| onepipeline::vcs::follow | sleep | 45581.0 | 0.0 | 916.1 | 47931.0 | 0.0 | 964.7 |
| onevcs::git::bounded | wait | 364937.5 | 871189.5 | 1249.7 | 364500.0 | 746546.0 | 801.7 |
| onevcs::pool::maintain::run | wait | 35.0 | 2458.5 | 24.2 | 35.0 | 2463.0 | 24.3 |
| onevcs::probe::read | wait | 353.0 | 738.5 | 0.6 | 354.0 | 703.0 | 0.3 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 8.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after exit-1: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.


```

Cache restore steps from this job’s log (elapsed logged step spans):

| Step | Result | Seconds |

| --- | --- | ---: |

| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.005 |

| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 76.464 |

| actions/setup-node@v4 | no restore | 3.522 |

| actions/setup-python@v5 | miss | 6.916 |

| astral-sh/setup-uv@v6 | no restore | 2.524 |

| actions/cache/restore@v4 | hit | 1.416 |

Final cache evidence: `Nx cache: stored 0 entries, 0 bytes; replayed 0 entries`; Actions-cache save lines: 0. No merged Linux coverage was produced; floor remains 95.74 LCOV. Exact log reasons:

```text

2026-11-15T17:10:20.3322875Z     the patch of `oneagentgraph` is not a git source

2026-11-15T18:42:33.2290140Z Tasks not run because their dependencies failed or --nx-bail=true:

2026-11-15T18:42:33.2290564Z - onepipeline:test

2026-11-15T18:42:56.0254336Z     the patch of `oneagentgraph` is not a git source

2026-11-15T18:43:00.9251273Z     the patch of `oneagentgraph` is not a git source

2026-11-15T18:43:10.1878678Z     the patch of `oneagentgraph` is not a git source

```

## First hosted adaptive point — Linux, incomplete sample

Run 43736257614/attempt 1, [test-linux job 132879405862](https://github.com/nickderobertis/onepipeline/actions/runs/43736257614/job/132879405862); GITHUB_SHA f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7; head 7c1a2c4daae604222efab39cf976a6b9258b3f8c, producer cabae915 plus the selected constant/common edits. Executed workflow blob db2bbe081a7b9319eb38bd014e72350b389e8b01. Overall job conclusion: failure, retained as such; this is not a green-CI claim.

API job duration 117.50 minutes. The output below separately labels log-span and pre-e2e minutes (compile/earlier work), and uses the actual nextest summary for e2e minutes. Processor: AMD EPYC 9V45 96-Core Processor, 4 logical cores. Source: this job’s test-profile-test-linux artifact, id 14174139876, compressed 35784704 bytes; zip SHA-256 5d81ceed3a0dbc4ee3c8589eafcffc21774e0606f805b8fd44d63545f2d12b94; job.log SHA-256 6d7d717e5257783c21f73b18cfabfc6894c1f7dd3bbf59b4f4f6e82908f4ff16.

The 2,155 completed main-tier profile names exactly equal the approved baseline union, with no missing/extra name and no overwritten profile here. The main tier passed 2,155/2,155, with no profile attempt over one. All 37 selected Nx tasks match both approved Linux baseline sets. These facts are retained in adaptive-linux-round1-proof.json and its facts sidecar.

One command, run on 5caad1a7:

```sh

node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-linux before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-linux after:adaptive-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736257614/1/test-linux

```

Output, verbatim. This is only one after point; its arithmetic cannot replace the required three-run comparison. The first-point difference is inside the baseline spread, so no saving or cost is decided and no combination is justified from it. Typical-PR minutes printed below are provisional scaled estimates, not an accepted price.

```text

## 2 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| after | 43736257614/1/132879405862 (adaptive-1) | f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7 | 7c1a2c4daae604222efab39cf976a6b9258b3f8c | AMD EPYC 9V45 96-Core Processor (4) | 117.44 | 76.13 | 39.23 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 39.49 | 37.92–41.06 | 3.14 |
| after | 39.23 | 39.23–39.23 | 0.00 |

Difference, after − before: -0.26 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -0.23 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25264.5 | 0.0 | 2228.0 | 24949.0 | 0.0 | 2272.9 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1729.0 | 0.0 | 34.7 | 1743.0 | 0.0 | 35.0 |
| onepipeline::commandstep::run | wait | 18.0 | 213.5 | 9.9 | 18.0 | 213.0 | 9.9 |
| onepipeline::dispatchenv::run | wait | 97.0 | 311.0 | 10.9 | 97.0 | 312.0 | 11.1 |
| onepipeline::driver::attach | sleep | 37015.5 | 0.0 | 1854.5 | 73908.0 | 0.0 | 1869.5 |
| onepipeline::driver::confirm_driving | sleep | 1436.0 | 0.0 | 72.0 | 4547.0 | 0.0 | 32.6 |
| onepipeline::driver::submit_offered | sleep | 4243.0 | 0.0 | 212.5 | 6173.0 | 0.0 | 195.2 |
| onepipeline::hooks::run | wait | 111.5 | 831.5 | 36.1 | 112.0 | 833.0 | 36.2 |
| onepipeline::planedit::run | wait | 32.0 | 461.0 | 8.6 | 32.0 | 463.0 | 8.7 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.0 | 6.9 | 78.0 | 215.0 | 7.0 |
| onepipeline::sys::gone_within | sleep | 2692.0 | 0.0 | 54.0 | 2661.0 | 0.0 | 53.4 |
| onepipeline::vcs::follow | sleep | 45581.0 | 0.0 | 916.1 | 49786.0 | 0.0 | 988.9 |
| onevcs::git::bounded | wait | 364937.5 | 871189.5 | 1249.7 | 365047.0 | 878027.0 | 1291.5 |
| onevcs::pool::maintain::run | wait | 35.0 | 2458.5 | 24.2 | 32.0 | 2458.0 | 24.2 |
| onevcs::probe::read | wait | 353.0 | 738.5 | 0.6 | 350.0 | 803.0 | 1.2 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after adaptive-1: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.


```

Cache restore steps from this job’s log (elapsed logged step spans):

| Step | Result | Seconds |

| --- | --- | ---: |

| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.004 |

| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 59.627 |

| actions/setup-node@v4 | no restore | 0.414 |

| actions/setup-python@v5 | miss | 5.837 |

| astral-sh/setup-uv@v6 | no restore | 2.373 |

| actions/cache/restore@v4 | hit | 1.045 |

Final cache evidence: `Nx cache: stored 0 entries, 0 bytes; replayed 0 entries`; Actions-cache save lines: 0. No merged Linux coverage was produced; floor remains 95.74 LCOV. Exact log reasons:

```text

2026-11-15T17:07:00.1915904Z     the patch of `oneagentgraph` is not a git source

2026-11-15T18:31:40.0428694Z Tasks not run because their dependencies failed or --nx-bail=true:

2026-11-15T18:31:40.0429115Z - onepipeline:test

2026-11-15T18:31:56.7888614Z     the patch of `oneagentgraph` is not a git source

2026-11-15T18:32:01.4747413Z     the patch of `oneagentgraph` is not a git source

2026-11-15T18:32:10.1559618Z     the patch of `oneagentgraph` is not a git source

```

## Shared full Linux selection (37 tasks)

This exact task set occurs on all three completed option/Linux jobs and both before/Linux jobs; it is selected by the common src/ edit, not a spawn-heavy subset.

```text

github-workflows:budgets
github-workflows:test
github-workflows:test-ci-shape
human-items-e2e:build
human-items-e2e:test
onepipeline-ci-jobs:test
onepipeline-codex-server:test
onepipeline-contract:test
onepipeline-coverage-keys:test
onepipeline-e2e:test
onepipeline-narrow-write:test
onepipeline-note-journeys:test
onepipeline-npm:test
onepipeline-pooled-slot:test
onepipeline-real-smoke:smoke
onepipeline-release-compat:release-compat
onepipeline-release:test
onepipeline-status-read:build
onepipeline-status-read:test
onepipeline-stop-verdict:test
onepipeline-stop-verdict:test-build
onepipeline-version-contract:test
onepipeline-version-e2e:test
onepipeline-version-package:test
onepipeline:budgets
onepipeline:build
onepipeline:coverage-clean
onepipeline:doc
onepipeline:install-documented
onepipeline:install-smoke
onepipeline:msrv
onepipeline:test
onepipeline:test-rest
onepipeline:wheel-smoke
pool-maintenance:test
report-job:budgets
report-job:test

```

Handoff 2026-11-15 18:56 UTC: all three option/Linux first points are collected and folded, each 2,155/2,155 passed and zero cache writes. E 39.93027, A 39.23223, R 37.42190 e2e minutes versus the two-point before mean 39.48736; all differences remain within the 3.13665-minute before spread. None is a decided saving. Nine test-platform jobs remain in flight/queued at the last collection; the whole workflows remain open. Further option/platform repetitions and any qualifying combination remain undone. Producer stays frozen at 4ee92293; no additional demonstrations have started.

## E/Windows first point — read on source 80aacfd4

[Run 43736250019, test-windows job 132879382569](https://github.com/nickderobertis/onepipeline/actions/runs/43736250019/job/132879382569), GITHUB_SHA 8a18672992559a9088d2527a71de265522e7f84f, head 9ba119ba96fa4544cea8889a2c809e9d01e65a84, executed workflow db2bbe081a7b9319eb38bd014e72350b389e8b01. Artifact 14176663027 (`test-profile-test-windows`), SHA-256 0928d1e2a5d9004cc39c4cb693e13d5f007dc053b4186258c0c9d9eabf1444fc. The job API reports 16:34:40–19:29:50 UTC = 175.16667 minutes; the log span and compilation/earlier-tier time are in the fold output below. AMD EPYC 9V74 80-Core Processor, 4 logical cores, from launch-host.json. The complete 39-task selection equals both inventory Windows selections; the job log reports zero Actions-cache saves and Nx stored 0 entries, 0 bytes, replayed 0. Full restore steps/times and selection arrays are in exit-windows-round1-facts.json.gz. Overall job conclusion is failure.

Main summary: `Summary [6568.346s] 1832 tests run: 1831 passed (75 slow), 1 timed out, 1 skipped`. `adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs` timed out at 540.104 seconds (17:40:09 UTC), then PASS at 140.273 seconds in the job’s own rerun (19:24:55 UTC). All 1,832 before names passed across main tier plus own rerun; the main tier alone lacks that one pass. No before-side Windows recovery was observed. Its original profile is `ended: unfinished`, with 535.9601875 wall seconds, so retained trace/profile counters are incomplete for that failed attempt; the later PASS log proves recovery but supplies no complete replacement profile. This is a missing-observation limitation, not zero waiting. The timeout output shows fixture publication warnings and no failed assertion; no root cause is established. The manager was notified (correlation c-01b086fb8f59cd79805a179dea3d4049); frozen producer unchanged.

The following command ran on 80aacfd4 (later evidence-only commits do not alter its inputs or fold source). Its -0.58-minute difference and -0.52-minute typical-PR arithmetic estimate are undecided inside the baseline spread, not demonstrated savings.

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-windows before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-windows after:exit-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736250019/1/test-windows
```

```text
## 2 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 9V45 96-Core Processor (4) | 144.66 | 57.17 | 87.11 | 1832/1832 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 7763 64-Core Processor (4) | 251.47 | 92.90 | 132.99 | 1832/1832 |
| after | 43736250019/1/132879382569 (exit-1) | 8a18672992559a9088d2527a71de265522e7f84f | 9ba119ba96fa4544cea8889a2c809e9d01e65a84 | AMD EPYC 9V74 80-Core Processor (4) | 175.11 | 56.47 | 109.47 | 1831/1832 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 110.05 | 87.11–132.99 | 45.88 |
| after | 109.47 | 109.47–109.47 | 0.00 |

Difference, after − before: -0.58 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -0.52 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 24414.5 | 0.0 | 6603.0 | 24253.0 | 0.0 | 5676.0 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 240.5 | 0.0 | 5.0 | 247.0 | 0.0 | 5.2 |
| onepipeline::commandstep::run | wait | 13.0 | 163.0 | 8.3 | 13.0 | 139.0 | 8.0 |
| onepipeline::dispatchenv::run | wait | 81.0 | 313.0 | 12.3 | 82.0 | 270.0 | 10.1 |
| onepipeline::driver::attach | sleep | 168609.0 | 0.0 | 9003.1 | 147985.0 | 0.0 | 7975.5 |
| onepipeline::driver::confirm_driving | sleep | 1346.5 | 0.0 | 70.0 | 1298.0 | 0.0 | 67.3 |
| onepipeline::driver::submit_offered | sleep | 5267.5 | 0.0 | 273.3 | 5010.0 | 0.0 | 262.2 |
| onepipeline::hooks::run | wait | 65.0 | 834.0 | 39.7 | 65.0 | 751.0 | 38.2 |
| onepipeline::planedit::run | wait | 30.0 | 620.0 | 12.4 | 30.0 | 501.0 | 14.9 |
| onepipeline::sys::gone_within | sleep | 54.5 | 0.0 | 1.1 | 49.0 | 0.0 | 0.1 |
| onepipeline::vcs::follow | sleep | 232763.0 | 0.0 | 5559.8 | 208483.0 | 0.0 | 5025.3 |
| onevcs::git::PipeCapture::start | sleep | 0.0 | 0.0 | 0.0 | 1381519.0 | 0.0 | 19949.4 |
| onevcs::git::PipeRead::await_readable | sleep | 2081824.5 | 0.0 | 24334.2 | 0.0 | 0.0 | 0.0 |
| onevcs::git::bounded | wait | 383607.5 | 1649484.5 | 18341.0 | 378744.0 | 1516335.0 | 15885.4 |
| onevcs::pool::maintain::run | wait | 19.0 | 1613.5 | 24.8 | 19.0 | 1601.0 | 24.8 |
| onevcs::probe::read | wait | 379.0 | 1000.0 | 13.1 | 377.0 | 870.0 | 9.7 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 15.5 | 18.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 34.5 | 36.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 4.0 | 4.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 9.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |

### Tests

1832 e2e tests passed in a before run.
- before inventory-1: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after exit-1: 1831 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed and not passed again: none.
```


## Completed diagnostic base, extra before-side point — source b0b724f3

[Run 43736273251](https://github.com/nickderobertis/onepipeline/actions/runs/43736273251), head 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1, GITHUB_SHA d1dcc5b7e02605051eebf05709688acf4e45f064, workflow db2bbe081a7b9319eb38bd014e72350b389e8b01. All platform jobs completed; PR #1616 was read and closed with its demonstration branch deleted. The frozen round-1 experiment is disabled on this base. Its dependency-opt manifest and no-behaviour src/lib.rs blob are identical to all round-1 variants, and each complete platform selection equals both inventory selections. This compares as an extra before point under c12.0; subsequent folds include all three before points, while the earlier two-point outputs remain historical sensitivity evidence.

| Platform/job | Processor/logical (physical) cores | API job minutes | Before e2e minutes (compile, earlier tiers) | E2e nextest minutes | Main passed/ran | Artifact |
|---|---|---:|---:|---:|---:|---|
| linux/[132879453312](https://github.com/nickderobertis/onepipeline/actions/runs/43736273251/job/132879453312) | AMD EPYC 7763 64-Core Processor / 4 (None) | 176.75000 | 131.14017 | 41.72650 | 2155/2155 | 14176134171 |
| macos/[132879453345](https://github.com/nickderobertis/onepipeline/actions/runs/43736273251/job/132879453345) | Apple M1 (Virtual) / 3 (3) | 156.55000 | 55.82005 | 82.26273 | 2121/2121 | 14176239814 |
| windows/[132879453337](https://github.com/nickderobertis/onepipeline/actions/runs/43736273251/job/132879453337) | AMD EPYC 9V74 80-Core Processor / 4 (None) | 171.96667 | 68.60455 | 102.62168 | 1830/1832 | 14176059098 |

Sources: job APIs/logs, corresponding test-profile artifacts and launch-host.json; archived base-{platform}-round1-facts/proof/receipt files carry all fields and hashes. Every platform job concluded failure, and budgets job 132933654023 passed. Linux main-tier named reconciliation is 2,154 retained main profiles plus the overwritten `loopcost::the_settlement_readability_latency_is_reported_from_its_journal_stamps`: two scoped original-tier process records and the all-passed summary prove that name ran/passed; its original aggregate counters cannot be recovered. macOS has all 2,121 named passes. Windows main tier failed `boundary::an_unusable_attempt_budget_falls_back_rather_than_disabling_the_recovery` and `store::a_project_larger_than_one_page_is_read_to_its_end`; both passed the job’s own reruns (19:26:30 UTC at 1.476 / 1.627 seconds, with later successful repeats). All 1,832 baseline names therefore passed across main plus own reruns.

Linux merged coverage was not produced. Its log states at 17:20:39.9048822Z `the patch of oneagentgraph is not a git source` (the original includes backticks), and at 19:29:45.9029539Z `Tasks not run because their dependencies failed or --nx-bail=true:`, followed at 19:29:45.9030789Z by `onepipeline:test`. No merged percentage is claimed; the floor remains 95.74 LCOV / 95% policy under a27.

### Cache steps for these newly read jobs

Times below are the cache/setup action’s log-span seconds, not a separately instrumented transfer-only time. Every Actions cache restore identified in the logs appears below; no-restore and tool-cache misses are retained to distinguish them. Full cache keys/log messages remain in facts files. Each platform log says Nx stored 0 entries, 0 bytes, replayed 0; each has no Actions-cache save entry. The already-read lint log has zero saves/stores too; the final budgets log has no cache restore/save or Nx store step. Thus this completed workflow wrote no cache entry.

| Job | Step | Restore observation | Action seconds |
|---|---|---|---:|
| exit-windows-round1/132879382569 | op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.017 |
| exit-windows-round1/132879382569 | Swatinem/rust-cache@v2.9.2 | partial (restore key) | 64.636 |
| exit-windows-round1/132879382569 | actions/setup-node@v4 | no restore | 12.658 |
| exit-windows-round1/132879382569 | actions/setup-python@v5 | no restore | 0.161 |
| exit-windows-round1/132879382569 | astral-sh/setup-uv@v6 | no restore | 2.800 |
| exit-windows-round1/132879382569 | actions/cache/restore@v4 | hit | 1.439 |
| base-linux-round1/132879453312 | op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.006 |
| base-linux-round1/132879453312 | Swatinem/rust-cache@v2.9.2 | partial (restore key) | 46.213 |
| base-linux-round1/132879453312 | actions/setup-node@v4 | no restore | 0.613 |
| base-linux-round1/132879453312 | actions/setup-python@v5 | miss | 7.460 |
| base-linux-round1/132879453312 | astral-sh/setup-uv@v6 | no restore | 3.061 |
| base-linux-round1/132879453312 | actions/cache/restore@v4 | hit | 1.209 |
| base-macos-round1/132879453345 | op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.022 |
| base-macos-round1/132879453345 | Swatinem/rust-cache@v2.9.2 | partial (restore key) | 26.938 |
| base-macos-round1/132879453345 | actions/setup-node@v4 | no restore | 0.883 |
| base-macos-round1/132879453345 | actions/setup-python@v5 | no restore | 0.163 |
| base-macos-round1/132879453345 | astral-sh/setup-uv@v6 | no restore | 1.995 |
| base-macos-round1/132879453345 | actions/cache/restore@v4 | hit | 0.536 |
| base-windows-round1/132879453337 | op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.018 |
| base-windows-round1/132879453337 | Swatinem/rust-cache@v2.9.2 | partial (restore key) | 85.889 |
| base-windows-round1/132879453337 | actions/setup-node@v4 | no restore | 5.306 |
| base-windows-round1/132879453337 | actions/setup-python@v5 | no restore | 0.165 |
| base-windows-round1/132879453337 | astral-sh/setup-uv@v6 | no restore | 2.856 |
| base-windows-round1/132879453337 | actions/cache/restore@v4 | hit | 1.526 |

The diagnostic command below ran on b0b724f3 for each named platform; it is a before-versus-disabled-base comparison, not an option saving.

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-linux before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-linux after:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-linux
```

```text
## 2 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| after | 43736273251/1/132879453312 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 7763 64-Core Processor (4) | 176.69 | 131.14 | 41.73 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 39.49 | 37.92–41.06 | 3.14 |
| after | 41.73 | 41.73–41.73 | 0.00 |

Difference, after − before: 2.24 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 2.02 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25264.5 | 0.0 | 2228.0 | 25200.0 | 0.0 | 2365.3 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1729.0 | 0.0 | 34.7 | 1724.0 | 0.0 | 34.6 |
| onepipeline::commandstep::run | wait | 18.0 | 213.5 | 9.9 | 18.0 | 215.0 | 10.0 |
| onepipeline::dispatchenv::run | wait | 97.0 | 311.0 | 10.9 | 97.0 | 317.0 | 11.4 |
| onepipeline::driver::attach | sleep | 37015.5 | 0.0 | 1854.5 | 41575.0 | 0.0 | 2084.0 |
| onepipeline::driver::confirm_driving | sleep | 1436.0 | 0.0 | 72.0 | 1447.0 | 0.0 | 72.6 |
| onepipeline::driver::submit_offered | sleep | 4243.0 | 0.0 | 212.5 | 4225.0 | 0.0 | 211.7 |
| onepipeline::hooks::run | wait | 111.5 | 831.5 | 36.1 | 112.0 | 834.0 | 36.3 |
| onepipeline::planedit::run | wait | 32.0 | 461.0 | 8.6 | 32.0 | 462.0 | 8.7 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.0 | 6.9 | 78.0 | 215.0 | 7.0 |
| onepipeline::sys::gone_within | sleep | 2692.0 | 0.0 | 54.0 | 2668.0 | 0.0 | 53.6 |
| onepipeline::vcs::follow | sleep | 45581.0 | 0.0 | 916.1 | 54325.0 | 0.0 | 1093.4 |
| onevcs::git::bounded | wait | 364937.5 | 871189.5 | 1249.7 | 365674.0 | 897126.0 | 1518.6 |
| onevcs::pool::maintain::run | wait | 35.0 | 2458.5 | 24.2 | 35.0 | 2474.0 | 24.4 |
| onevcs::probe::read | wait | 353.0 | 738.5 | 0.6 | 345.0 | 764.0 | 1.0 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after base-1: 2154 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
```

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-macos before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-macos after:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-macos
```

```text
## 2 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 201.81 | 92.98 | 90.11 | 2121/2121 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 198.48 | 85.46 | 94.38 | 2121/2121 |
| after | 43736273251/1/132879453345 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | Apple M1 (Virtual) (3) | 156.54 | 55.82 | 82.26 | 2121/2121 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 92.24 | 90.11–94.38 | 4.26 |
| after | 82.26 | 82.26–82.26 | 0.00 |

Difference, after − before: -9.98 min — decided: non-overlapping ranges and mean difference outside both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -8.98 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25382.5 | 0.0 | 5679.6 | 25494.0 | 0.0 | 5176.3 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 378.0 | 0.0 | 37.1 | 350.0 | 0.0 | 36.7 |
| onepipeline::commandstep::run | wait | 18.0 | 107.5 | 12.0 | 18.0 | 105.0 | 11.7 |
| onepipeline::dispatchenv::run | wait | 97.0 | 689.0 | 76.4 | 97.0 | 611.0 | 67.4 |
| onepipeline::driver::attach | sleep | 28624.5 | 0.0 | 3790.2 | 25902.0 | 0.0 | 3462.7 |
| onepipeline::driver::confirm_driving | sleep | 1410.0 | 0.0 | 185.1 | 1377.0 | 0.0 | 179.6 |
| onepipeline::driver::submit_offered | sleep | 2167.0 | 0.0 | 277.7 | 2068.0 | 0.0 | 269.9 |
| onepipeline::hooks::run | wait | 112.0 | 471.5 | 46.0 | 112.0 | 476.0 | 44.9 |
| onepipeline::planedit::run | wait | 32.0 | 149.0 | 11.4 | 32.0 | 141.0 | 11.0 |
| onepipeline::stopguard::consult | wait | 78.0 | 177.5 | 13.3 | 78.0 | 176.0 | 13.0 |
| onepipeline::sys::gone_within | sleep | 912.0 | 0.0 | 87.7 | 922.0 | 0.0 | 90.9 |
| onepipeline::vcs::follow | sleep | 24738.5 | 0.0 | 2585.1 | 20926.0 | 0.0 | 2205.0 |
| onevcs::git::bounded | wait | 375517.0 | 775344.5 | 4498.2 | 370540.0 | 757686.0 | 3525.6 |
| onevcs::pool::maintain::run | wait | 35.0 | 615.5 | 26.5 | 34.0 | 569.0 | 25.9 |
| onevcs::probe::read | wait | 360.0 | 727.5 | 6.0 | 358.0 | 716.0 | 2.8 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.5 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2121 e2e tests passed in a before run.
- before inventory-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after base-1: 2121 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
```

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-windows before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-windows after:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-windows
```

```text
## 2 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 9V45 96-Core Processor (4) | 144.66 | 57.17 | 87.11 | 1832/1832 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 7763 64-Core Processor (4) | 251.47 | 92.90 | 132.99 | 1832/1832 |
| after | 43736273251/1/132879453337 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 9V74 80-Core Processor (4) | 171.91 | 68.60 | 102.62 | 1830/1832 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 110.05 | 87.11–132.99 | 45.88 |
| after | 102.62 | 102.62–102.62 | 0.00 |

Difference, after − before: -7.43 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -6.69 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 24414.5 | 0.0 | 6603.0 | 24346.0 | 0.0 | 5905.4 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 240.5 | 0.0 | 5.0 | 243.0 | 0.0 | 5.0 |
| onepipeline::commandstep::run | wait | 13.0 | 163.0 | 8.3 | 13.0 | 154.0 | 8.1 |
| onepipeline::dispatchenv::run | wait | 81.0 | 313.0 | 12.3 | 82.0 | 302.0 | 11.6 |
| onepipeline::driver::attach | sleep | 168609.0 | 0.0 | 9003.1 | 158090.0 | 0.0 | 8337.8 |
| onepipeline::driver::confirm_driving | sleep | 1346.5 | 0.0 | 70.0 | 1306.0 | 0.0 | 67.6 |
| onepipeline::driver::submit_offered | sleep | 5267.5 | 0.0 | 273.3 | 5034.0 | 0.0 | 258.0 |
| onepipeline::hooks::run | wait | 65.0 | 834.0 | 39.7 | 65.0 | 844.0 | 40.2 |
| onepipeline::planedit::run | wait | 30.0 | 620.0 | 12.4 | 30.0 | 593.0 | 11.7 |
| onepipeline::sys::gone_within | sleep | 54.5 | 0.0 | 1.1 | 56.0 | 0.0 | 1.2 |
| onepipeline::vcs::follow | sleep | 232763.0 | 0.0 | 5559.8 | 229450.0 | 0.0 | 5288.5 |
| onevcs::git::PipeRead::await_readable | sleep | 2081824.5 | 0.0 | 24334.2 | 1911769.0 | 0.0 | 21882.4 |
| onevcs::git::bounded | wait | 383607.5 | 1649484.5 | 18341.0 | 380325.0 | 1513283.0 | 16042.0 |
| onevcs::pool::maintain::run | wait | 19.0 | 1613.5 | 24.8 | 19.0 | 1617.0 | 24.8 |
| onevcs::probe::read | wait | 379.0 | 1000.0 | 13.1 | 379.0 | 900.0 | 10.3 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 15.5 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 34.5 | 34.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 4.0 | 4.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |

### Tests

1832 e2e tests passed in a before run.
- before inventory-1: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after base-1: 1830 passed in the tier; of the before runs' passes, not run and passed here: boundary::an_unusable_attempt_budget_falls_back_rather_than_disabling_the_recovery, store::a_project_larger_than_one_page_is_read_to_its_end; failed in the tier, passed on the job's re-run: boundary::an_unusable_attempt_budget_falls_back_rather_than_disabling_the_recovery, store::a_project_larger_than_one_page_is_read_to_its_end; failed and not passed again: none.
```



## Current comparisons with all three approved before points — source b0b724f3

These command outputs supersede the two-point arithmetic above; they do not supply the missing after repetitions. Before point #1616 is disabled experiment, not an after saving. Reported missing main-tier names are reconciled by the supplementary trace proof or own rerun listed above; the raw fold preserves those distinctions.

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-linux before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-linux before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-linux after:exit-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736250019/1/test-linux
```

```text
## 3 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| before | 43736273251/1/132879453312 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 7763 64-Core Processor (4) | 176.69 | 131.14 | 41.73 | 2155/2155 |
| after | 43736250019/1/132879382741 (exit-1) | 8a18672992559a9088d2527a71de265522e7f84f | 9ba119ba96fa4544cea8889a2c809e9d01e65a84 | AMD EPYC 9V74 80-Core Processor (4) | 128.57 | 85.91 | 39.93 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 40.23 | 37.92–41.73 | 3.81 |
| after | 39.93 | 39.93–39.93 | 0.00 |

Difference, after − before: -0.30 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -0.27 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25243.0 | 0.0 | 2273.8 | 25131.0 | 0.0 | 2235.7 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1727.3 | 0.0 | 34.7 | 1730.0 | 0.0 | 34.7 |
| onepipeline::commandstep::run | wait | 18.0 | 214.0 | 9.9 | 18.0 | 212.0 | 9.3 |
| onepipeline::dispatchenv::run | wait | 97.0 | 313.0 | 11.1 | 97.0 | 309.0 | 7.4 |
| onepipeline::driver::attach | sleep | 38535.3 | 0.0 | 1931.0 | 36192.0 | 0.0 | 1814.6 |
| onepipeline::driver::confirm_driving | sleep | 1439.7 | 0.0 | 72.2 | 1470.0 | 0.0 | 73.7 |
| onepipeline::driver::submit_offered | sleep | 4237.0 | 0.0 | 212.2 | 3837.0 | 0.0 | 192.2 |
| onepipeline::hooks::run | wait | 111.7 | 832.3 | 36.2 | 114.0 | 836.0 | 31.1 |
| onepipeline::planedit::run | wait | 32.0 | 461.3 | 8.7 | 32.0 | 463.0 | 8.2 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.3 | 6.9 | 78.0 | 215.0 | 3.4 |
| onepipeline::sys::gone_within | sleep | 2684.0 | 0.0 | 53.9 | 860329.0 | 0.0 | 42.0 |
| onepipeline::vcs::follow | sleep | 48495.7 | 0.0 | 975.2 | 47931.0 | 0.0 | 964.7 |
| onevcs::git::bounded | wait | 365183.0 | 879835.0 | 1339.3 | 364500.0 | 746546.0 | 801.7 |
| onevcs::pool::maintain::run | wait | 35.0 | 2463.7 | 24.2 | 35.0 | 2463.0 | 24.3 |
| onevcs::probe::read | wait | 350.3 | 747.0 | 0.7 | 354.0 | 703.0 | 0.3 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 8.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after exit-1: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
```

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-linux before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-linux before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-linux after:adaptive-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736257614/1/test-linux
```

```text
## 3 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| before | 43736273251/1/132879453312 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 7763 64-Core Processor (4) | 176.69 | 131.14 | 41.73 | 2155/2155 |
| after | 43736257614/1/132879405862 (adaptive-1) | f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7 | 7c1a2c4daae604222efab39cf976a6b9258b3f8c | AMD EPYC 9V45 96-Core Processor (4) | 117.44 | 76.13 | 39.23 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 40.23 | 37.92–41.73 | 3.81 |
| after | 39.23 | 39.23–39.23 | 0.00 |

Difference, after − before: -1.00 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -0.90 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25243.0 | 0.0 | 2273.8 | 24949.0 | 0.0 | 2272.9 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1727.3 | 0.0 | 34.7 | 1743.0 | 0.0 | 35.0 |
| onepipeline::commandstep::run | wait | 18.0 | 214.0 | 9.9 | 18.0 | 213.0 | 9.9 |
| onepipeline::dispatchenv::run | wait | 97.0 | 313.0 | 11.1 | 97.0 | 312.0 | 11.1 |
| onepipeline::driver::attach | sleep | 38535.3 | 0.0 | 1931.0 | 73908.0 | 0.0 | 1869.5 |
| onepipeline::driver::confirm_driving | sleep | 1439.7 | 0.0 | 72.2 | 4547.0 | 0.0 | 32.6 |
| onepipeline::driver::submit_offered | sleep | 4237.0 | 0.0 | 212.2 | 6173.0 | 0.0 | 195.2 |
| onepipeline::hooks::run | wait | 111.7 | 832.3 | 36.2 | 112.0 | 833.0 | 36.2 |
| onepipeline::planedit::run | wait | 32.0 | 461.3 | 8.7 | 32.0 | 463.0 | 8.7 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.3 | 6.9 | 78.0 | 215.0 | 7.0 |
| onepipeline::sys::gone_within | sleep | 2684.0 | 0.0 | 53.9 | 2661.0 | 0.0 | 53.4 |
| onepipeline::vcs::follow | sleep | 48495.7 | 0.0 | 975.2 | 49786.0 | 0.0 | 988.9 |
| onevcs::git::bounded | wait | 365183.0 | 879835.0 | 1339.3 | 365047.0 | 878027.0 | 1291.5 |
| onevcs::pool::maintain::run | wait | 35.0 | 2463.7 | 24.2 | 32.0 | 2458.0 | 24.2 |
| onevcs::probe::read | wait | 350.3 | 747.0 | 0.7 | 350.0 | 803.0 | 1.2 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after adaptive-1: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
```

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-linux before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-linux before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-linux after:relaunch-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736265323/1/test-linux
```

```text
## 3 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| before | 43736273251/1/132879453312 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 7763 64-Core Processor (4) | 176.69 | 131.14 | 41.73 | 2155/2155 |
| after | 43736265323/1/132879430099 (relaunch-1) | 7b56610e75bdec33e277d44b3e442521f35fe0bb | c22459bfda17d6a6ad10e322ff607e70eb56a68e | Intel(R) Xeon(R) 6975P-C (4) | 115.30 | 75.93 | 37.42 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 40.23 | 37.92–41.73 | 3.81 |
| after | 37.42 | 37.42–37.42 | 0.00 |

Difference, after − before: -2.81 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -2.53 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25243.0 | 0.0 | 2273.8 | 26004.0 | 0.0 | 2146.2 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1727.3 | 0.0 | 34.7 | 1740.0 | 0.0 | 34.9 |
| onepipeline::commandstep::run | wait | 18.0 | 214.0 | 9.9 | 18.0 | 212.0 | 9.8 |
| onepipeline::dispatchenv::run | wait | 97.0 | 313.0 | 11.1 | 97.0 | 312.0 | 10.9 |
| onepipeline::driver::attach | sleep | 38535.3 | 0.0 | 1931.0 | 34838.0 | 0.0 | 1744.8 |
| onepipeline::driver::confirm_driving | sleep | 1439.7 | 0.0 | 72.2 | 1434.0 | 0.0 | 71.9 |
| onepipeline::driver::submit_offered | sleep | 4237.0 | 0.0 | 212.2 | 4211.0 | 0.0 | 210.9 |
| onepipeline::hooks::run | wait | 111.7 | 832.3 | 36.2 | 111.0 | 829.0 | 36.0 |
| onepipeline::planedit::run | wait | 32.0 | 461.3 | 8.7 | 32.0 | 462.0 | 8.7 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.3 | 6.9 | 78.0 | 213.0 | 6.8 |
| onepipeline::sys::gone_within | sleep | 2684.0 | 0.0 | 53.9 | 2668.0 | 0.0 | 53.5 |
| onepipeline::vcs::follow | sleep | 48495.7 | 0.0 | 975.2 | 47382.0 | 0.0 | 951.6 |
| onevcs::git::bounded | wait | 365183.0 | 879835.0 | 1339.3 | 363429.0 | 863015.0 | 1221.0 |
| onevcs::pool::maintain::run | wait | 35.0 | 2463.7 | 24.2 | 35.0 | 2445.0 | 24.0 |
| onevcs::probe::read | wait | 350.3 | 747.0 | 0.7 | 350.0 | 731.0 | 0.5 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 9.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 2.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 2.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 2.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 5.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 5.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 6.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 9.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 8.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 8.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 4.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 7.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 4.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 3.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after relaunch-1: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
```

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-windows before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-windows before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-windows after:exit-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736250019/1/test-windows
```

```text
## 3 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 9V45 96-Core Processor (4) | 144.66 | 57.17 | 87.11 | 1832/1832 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 7763 64-Core Processor (4) | 251.47 | 92.90 | 132.99 | 1832/1832 |
| before | 43736273251/1/132879453337 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 9V74 80-Core Processor (4) | 171.91 | 68.60 | 102.62 | 1830/1832 |
| after | 43736250019/1/132879382569 (exit-1) | 8a18672992559a9088d2527a71de265522e7f84f | 9ba119ba96fa4544cea8889a2c809e9d01e65a84 | AMD EPYC 9V74 80-Core Processor (4) | 175.11 | 56.47 | 109.47 | 1831/1832 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 107.58 | 87.11–132.99 | 45.88 |
| after | 109.47 | 109.47–109.47 | 0.00 |

Difference, after − before: 1.90 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 1.71 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 24391.7 | 0.0 | 6370.5 | 24253.0 | 0.0 | 5676.0 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 241.3 | 0.0 | 5.0 | 247.0 | 0.0 | 5.2 |
| onepipeline::commandstep::run | wait | 13.0 | 160.0 | 8.2 | 13.0 | 139.0 | 8.0 |
| onepipeline::dispatchenv::run | wait | 81.3 | 309.3 | 12.1 | 82.0 | 270.0 | 10.1 |
| onepipeline::driver::attach | sleep | 165102.7 | 0.0 | 8781.3 | 147985.0 | 0.0 | 7975.5 |
| onepipeline::driver::confirm_driving | sleep | 1333.0 | 0.0 | 69.2 | 1298.0 | 0.0 | 67.3 |
| onepipeline::driver::submit_offered | sleep | 5189.7 | 0.0 | 268.2 | 5010.0 | 0.0 | 262.2 |
| onepipeline::hooks::run | wait | 65.0 | 837.3 | 39.9 | 65.0 | 751.0 | 38.2 |
| onepipeline::planedit::run | wait | 30.0 | 611.0 | 12.2 | 30.0 | 501.0 | 14.9 |
| onepipeline::sys::gone_within | sleep | 55.0 | 0.0 | 1.2 | 49.0 | 0.0 | 0.1 |
| onepipeline::vcs::follow | sleep | 231658.7 | 0.0 | 5469.4 | 208483.0 | 0.0 | 5025.3 |
| onevcs::git::PipeCapture::start | sleep | 0.0 | 0.0 | 0.0 | 1381519.0 | 0.0 | 19949.4 |
| onevcs::git::PipeRead::await_readable | sleep | 2025139.3 | 0.0 | 23516.9 | 0.0 | 0.0 | 0.0 |
| onevcs::git::bounded | wait | 382513.3 | 1604084.0 | 17574.7 | 378744.0 | 1516335.0 | 15885.4 |
| onevcs::pool::maintain::run | wait | 19.0 | 1614.7 | 24.8 | 19.0 | 1601.0 | 24.8 |
| onevcs::probe::read | wait | 379.0 | 966.7 | 12.2 | 377.0 | 870.0 | 9.7 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 14.3 | 18.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 34.3 | 36.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 4.0 | 4.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 9.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |

### Tests

1832 e2e tests passed in a before run.
- before inventory-1: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 1830 passed in the tier; failed in the tier, passed on the job's re-run: boundary::an_unusable_attempt_budget_falls_back_rather_than_disabling_the_recovery, store::a_project_larger_than_one_page_is_read_to_its_end; failed and not passed again: none.
- after exit-1: 1831 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed and not passed again: none.
```



## A/Windows first point — source a5f2ae74

[Run 43736257614, test-windows job 132879405490](https://github.com/nickderobertis/onepipeline/actions/runs/43736257614/job/132879405490), GITHUB_SHA f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7, head 7c1a2c4daae604222efab39cf976a6b9258b3f8c, executed workflow db2bbe081a7b9319eb38bd014e72350b389e8b01. Test-profile artifact 14178385626, SHA-256 2647f7416545ebb42c111af2d1e8535a16bfe3225a85306ce104d088bf4c9810. Job API duration 215.63333 minutes; compilation and earlier-tier log span 67.90143 minutes. Processor from launch-host.json: INTEL(R) XEON(R) PLATINUM 8573C, 4 logical cores. Complete 39-task selection equals both inventory Windows selections. Overall job conclusion is failure, and no Actions-cache save or Nx remote-cache write occurred (Nx stored 0 entries/0 bytes, replayed 0).

Main summary `Summary [8262.800s] 1832 tests run: 1831 passed (114 slow), 1 timed out, 1 skipped`. The one timeout was `adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs`; its own rerun passed in 148.255 seconds at 20:05:12 UTC, with later successful repeats at 147.088 and 146.589 seconds. Thus all 1,832 baseline names passed across main plus own reruns, with that one main-tier absence preserved in the fold. Its retained original profile is unfinished: wall 536.06943 seconds, cargo build 128.5889193 seconds, unattributed 406.6448339 seconds, no profiled CLI spawn. Counters for the killed attempt are incomplete; the later PASS proves recovery but has no complete replacement profile. No root cause is established from that record. PR comments were read before investigating; no completed PR performance report was present.

The three-before mean is 107.5758944 minutes, sample SD 23.3384306; this single after point is 30.1374389 minutes (1.2913224 SD) slower. These local arithmetic values came from Python `statistics.mean` / `statistics.stdev` on `[87.11233333333332,132.99366666666666,102.62168333333334]`, then `(8262.8/60 - mean)/stdev`, on a5f2ae74. This is an adverse first point, not a decided regression: its difference remains inside the 45.8813333-minute before spread and after replication is incomplete. The 27.12-minute typical-PR number printed below is provisional arithmetic, not a claimed cost forecast.

Investigation suspects the current prototype first: `driver::attach` observations rise from 165,102.7 calls / 8,781.3 seconds to 239,799 / 10,534.7; `confirm_driving` 1,333 / 69.2 to 4,914 / 56.0; `follow` 231,658.7 / 5,469.4 to 206,679 / 6,599.1. These are overlapping recorded waits across children, not wall savings. Shorter observed per-call waits coexist with slower end-to-end execution; one different runner cannot establish attribution. The manager was asked to resolve repair versus frozen producer under a40 (correlations c-fbd6d58915c71594a1a2e3cec8e22f40 and c-b5e5eb820c925a3cffadef71e4cef5f2). No producer change was made.

Cache/setup action spans, from this job log (not separately timed transfer-only spans):

| Step | Restore observation | Action seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.020 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 63.338 |
| actions/setup-node@v4 | no restore | 3.844 |
| actions/setup-python@v5 | no restore | 0.206 |
| astral-sh/setup-uv@v6 | no restore | 3.008 |
| actions/cache/restore@v4 | hit | 0.886 |

Command run on a5f2ae74, producing the following output:

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-windows before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-windows before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-windows after:adaptive-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736257614/1/test-windows
```

```text
## 3 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 9V45 96-Core Processor (4) | 144.66 | 57.17 | 87.11 | 1832/1832 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 7763 64-Core Processor (4) | 251.47 | 92.90 | 132.99 | 1832/1832 |
| before | 43736273251/1/132879453337 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 9V74 80-Core Processor (4) | 171.91 | 68.60 | 102.62 | 1830/1832 |
| after | 43736257614/1/132879405490 (adaptive-1) | f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7 | 7c1a2c4daae604222efab39cf976a6b9258b3f8c | INTEL(R) XEON(R) PLATINUM 8573C (4) | 215.60 | 67.90 | 137.71 | 1831/1832 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 107.58 | 87.11–132.99 | 45.88 |
| after | 137.71 | 137.71–137.71 | 0.00 |

Difference, after − before: 30.14 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 27.12 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 24391.7 | 0.0 | 6370.5 | 24351.0 | 0.0 | 7512.2 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 241.3 | 0.0 | 5.0 | 240.0 | 0.0 | 5.1 |
| onepipeline::commandstep::run | wait | 13.0 | 160.0 | 8.2 | 13.0 | 164.0 | 8.6 |
| onepipeline::dispatchenv::run | wait | 81.3 | 309.3 | 12.1 | 81.0 | 343.0 | 13.9 |
| onepipeline::driver::attach | sleep | 165102.7 | 0.0 | 8781.3 | 239799.0 | 0.0 | 10534.7 |
| onepipeline::driver::confirm_driving | sleep | 1333.0 | 0.0 | 69.2 | 4914.0 | 0.0 | 56.0 |
| onepipeline::driver::submit_offered | sleep | 5189.7 | 0.0 | 268.2 | 7517.0 | 0.0 | 282.6 |
| onepipeline::hooks::run | wait | 65.0 | 837.3 | 39.9 | 65.0 | 862.0 | 41.8 |
| onepipeline::planedit::run | wait | 30.0 | 611.0 | 12.2 | 30.0 | 646.0 | 13.1 |
| onepipeline::sys::gone_within | sleep | 55.0 | 0.0 | 1.2 | 55.0 | 0.0 | 1.2 |
| onepipeline::vcs::follow | sleep | 231658.7 | 0.0 | 5469.4 | 206679.0 | 0.0 | 6599.1 |
| onevcs::git::PipeRead::await_readable | sleep | 2025139.3 | 0.0 | 23516.9 | 2599066.0 | 0.0 | 30450.8 |
| onevcs::git::bounded | wait | 382513.3 | 1604084.0 | 17574.7 | 387311.0 | 1946434.0 | 22901.4 |
| onevcs::pool::maintain::run | wait | 19.0 | 1614.7 | 24.8 | 18.0 | 1610.0 | 24.9 |
| onevcs::probe::read | wait | 379.0 | 966.7 | 12.2 | 364.0 | 998.0 | 14.6 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 14.3 | 22.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 34.3 | 36.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 4.0 | 4.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |

### Tests

1832 e2e tests passed in a before run.
- before inventory-1: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 1830 passed in the tier; failed in the tier, passed on the job's re-run: boundary::an_unusable_attempt_budget_falls_back_rather_than_disabling_the_recovery, store::a_project_larger_than_one_page_is_read_to_its_end; failed and not passed again: none.
- after adaptive-1: 1831 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed and not passed again: none.
```


## E/R local trace preparation before round two — source 4c869187

While waiting out a64’s hosted read pause, the same single real-binary views journey was run separately with `ONEPIPELINE_SPIKE_CHILD_WAITS=exit` and `relaunch`, each with its own `ONEPIPELINE_TEST_PROFILE_DIR=$ONEPIPELINE_NODE_SCRATCH_DIR/round2-local-{variant}` and `ONEPIPELINE_LAUNCH_TRACE=$ONEPIPELINE_TEST_PROFILE_DIR/launch`. Command: `RUSTFLAGS="-D warnings" just test-e2e "test(=views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice)"`, inheriting those explicit recording/variant variables. Both passed: exit nextest d5eef41f-031b-48f4-8bf1-8e02d37cf5e9, relaunch 9e2df5ef-7845-42a3-8158-9aa4d6b2b65a. The source remains frozen producer 4ee92293; only local environment selects an option.

The branch’s exported `readJob` / `foldJob` folded each recorded directory into the archived count-only JSON (round2-local-exit-counts.json.gz and round2-local-relaunch-counts.json.gz). The journey records five direct CLI launches for exit and four for relaunch, preserving its real-binary assertions. These are local counts, not hosted timing or savings evidence. The logs are retained but their elapsed times are not used. E2/R2 have not been opened; a63 requires released slots first.


## R/Windows first point — source b5261d37

[Run 43736265323, test-windows job 132879429855](https://github.com/nickderobertis/onepipeline/actions/runs/43736265323/job/132879429855), GITHUB_SHA 7b56610e75bdec33e277d44b3e442521f35fe0bb, head c22459bfda17d6a6ad10e322ff607e70eb56a68e, workflow db2bbe081a7b9319eb38bd014e72350b389e8b01. Artifact 14179090728, SHA-256 775ac7723385179cfcb05dd49a41b5e88873873f201f77c078ca568525af20c6; launch-host.json records AMD EPYC 7763 64-Core Processor, four logical cores. API job duration 241.85000 minutes, pre-e2e compile/earlier-tier span 74.75793 minutes. Complete 39-task selection equals both inventory Windows selections. Overall job failure; no Actions-cache save, Nx stored zero entries/bytes and replayed zero.

Main summary `Summary [8795.553s] 1832 tests run: 1830 passed (129 slow), 1 failed, 1 timed out, 1 skipped`. Held-release adoption timed out at 540.122 seconds and passed its own rerun at 147.010 seconds (20:24:31 UTC). `check_visibility::the_check_visibility_workload_reads_at_its_cadence_and_records_what_it_spent` failed at 127.549 seconds: `timed out waiting for all six publications’ followed checks to finish` (18:41:24 UTC); its own rerun passed at 207.727 seconds (20:24:31 UTC), with later passes 206.128 and 214.329 seconds. Both are named in the fold’s recovered list, so all 1,832 baseline test names passed across main plus own reruns, while the two main-tier failures remain explicit. R changes neither journey’s test body. The known load-sensitive held-release timeout is reported as a recovery per a63, not diagnosed as a prototype defect. PR comments were read before analysis; no finished performance report was present.

The 146.59255-minute first point is 39.01666 minutes slower than the three-before mean, still inside the 45.88133-minute before spread; it is undecided and supplies no decided saving for R. Under a61 keep producer frozen and collect the second repeat, rather than repair from one point inside the spread. The printed 35.11-minute scaled typical-PR number is provisional arithmetic, not a cost forecast. Changed-journey launch counts below are measured: most fixed read journeys decrease, but dynamic polling varies (the fast adoption journey has more total calls in this run despite its final duplicate read being removed). Do not transfer Linux’s exact 23-call difference to Windows.

Cache/setup action spans (not transfer-only timing), read from the same log:

| Step | Restore observation | Action seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.022 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 54.340 |
| actions/setup-node@v4 | no restore | 7.634 |
| actions/setup-python@v5 | no restore | 0.203 |
| astral-sh/setup-uv@v6 | no restore | 3.002 |
| actions/cache/restore@v4 | hit | 1.919 |

The following command ran on b5261d37 and printed this comparison:

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-windows before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-windows before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-windows after:relaunch-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736265323/1/test-windows
```

```text
## 3 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 9V45 96-Core Processor (4) | 144.66 | 57.17 | 87.11 | 1832/1832 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 7763 64-Core Processor (4) | 251.47 | 92.90 | 132.99 | 1832/1832 |
| before | 43736273251/1/132879453337 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 9V74 80-Core Processor (4) | 171.91 | 68.60 | 102.62 | 1830/1832 |
| after | 43736265323/1/132879429855 (relaunch-1) | 7b56610e75bdec33e277d44b3e442521f35fe0bb | c22459bfda17d6a6ad10e322ff607e70eb56a68e | AMD EPYC 7763 64-Core Processor (4) | 241.80 | 74.76 | 146.59 | 1830/1832 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 107.58 | 87.11–132.99 | 45.88 |
| after | 146.59 | 146.59–146.59 | 0.00 |

Difference, after − before: 39.02 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 35.11 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 24391.7 | 0.0 | 6370.5 | 24373.0 | 0.0 | 8092.1 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 241.3 | 0.0 | 5.0 | 238.0 | 0.0 | 5.0 |
| onepipeline::commandstep::run | wait | 13.0 | 160.0 | 8.2 | 13.0 | 166.0 | 8.6 |
| onepipeline::dispatchenv::run | wait | 81.3 | 309.3 | 12.1 | 81.0 | 349.0 | 14.4 |
| onepipeline::driver::attach | sleep | 165102.7 | 0.0 | 8781.3 | 208848.0 | 0.0 | 11352.4 |
| onepipeline::driver::confirm_driving | sleep | 1333.0 | 0.0 | 69.2 | 1453.0 | 0.0 | 77.1 |
| onepipeline::driver::submit_offered | sleep | 5189.7 | 0.0 | 268.2 | 5551.0 | 0.0 | 290.3 |
| onepipeline::hooks::run | wait | 65.0 | 837.3 | 39.9 | 65.0 | 885.0 | 42.7 |
| onepipeline::planedit::run | wait | 30.0 | 611.0 | 12.2 | 30.0 | 665.0 | 13.7 |
| onepipeline::sys::gone_within | sleep | 55.0 | 0.0 | 1.2 | 34.0 | 0.0 | 0.7 |
| onepipeline::vcs::follow | sleep | 231658.7 | 0.0 | 5469.4 | 277484.0 | 0.0 | 6857.0 |
| onevcs::git::PipeRead::await_readable | sleep | 2025139.3 | 0.0 | 23516.9 | 2592136.0 | 0.0 | 31053.1 |
| onevcs::git::bounded | wait | 382513.3 | 1604084.0 | 17574.7 | 385316.0 | 2022698.0 | 24386.3 |
| onevcs::pool::maintain::run | wait | 19.0 | 1614.7 | 24.8 | 19.0 | 1613.0 | 24.9 |
| onevcs::probe::read | wait | 379.0 | 966.7 | 12.2 | 337.0 | 1020.0 | 16.9 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 14.3 | 17.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 34.3 | 34.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 2.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 2.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 4.0 | 2.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 6.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 5.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 6.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 9.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 8.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 8.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 7.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 4.0 |

### Tests

1832 e2e tests passed in a before run.
- before inventory-1: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 1830 passed in the tier; failed in the tier, passed on the job's re-run: boundary::an_unusable_attempt_budget_falls_back_rather_than_disabling_the_recovery, store::a_project_larger_than_one_page_is_read_to_its_end; failed and not passed again: none.
- after relaunch-1: 1830 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs, check_visibility::the_check_visibility_workload_reads_at_its_cadence_and_records_what_it_spent; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs, check_visibility::the_check_visibility_workload_reads_at_its_cadence_and_records_what_it_spent; failed and not passed again: none.
```


## E2/R2 staged locally, not hosted

On parent 3c974735, exit round-two commit 76e124ef58e4d67fef8db8657478eae38fffedbb and relaunch round-two commit e156f19aa0d669eee79490ce7c49096b45ffcef2 are prepared as local branches only. Neither has been pushed or opened as a PR; they consume no hosted slot and have no run id. Their workflow/Cargo/src blobs match round one exactly (db2bbe081a7b9319eb38bd014e72350b389e8b01 / d95eed3341f21cfccf8e0fc309d3904325998617 / 563b327b22f01e50c02c8743ef5dc6cfdd9894ec), and `git diff --check` plus `cargo fmt --all -- --check` passed on each before its commit. Separate passed local E/R slices and count folds preceded this preparation on the identical frozen producer. They await a63’s slots as round-one demonstrations are read and closed; no third run is prepared. Receipt and exact patches are archived for the measurement record.


## E/macOS first point, completed E1 — source 233371f0

[Run 43736250019, test-macos job 132879382738](https://github.com/nickderobertis/onepipeline/actions/runs/43736250019/job/132879382738), GITHUB_SHA 8a18672992559a9088d2527a71de265522e7f84f, head 9ba119ba96fa4544cea8889a2c809e9d01e65a84; workflow db2bbe081a7b9319eb38bd014e72350b389e8b01. Artifact 14181386830, SHA-256 5f8d4e8f0a16eaaadab0a4719eb0be636ddc1503c591ea36bccb187ddd89e9e9. API job duration 90.80000 minutes; pre-e2e compile/earlier tiers 24.03595 minutes. Complete platform Nx selection equals both inventory selections. Launch-host.json records **Apple M2 Pro (Virtual), five logical and five physical cores**, unlike **Apple M1 (Virtual), three/three cores** for all three before points.

Main summary `Summary [3576.324s] 2121 tests run: 2120 passed (34 slow), 1 failed, 1 skipped`. `unwatched::a_host_sized_runs_root_is_answered_in_well_under_a_second_whatever_its_journals_hold` failed at 15.122 seconds, 20:40:09 UTC: `the answer changed when the journals grew, so the run count or the fixture moved`, with the same three rows PARKED versus ACTIVE. Its own reruns passed at 17.859 seconds (21:34:39 UTC), then 17.611 and 15.707 seconds. All 2,121 baseline names passed across main plus own reruns; no assertion was changed. This records the observed state transition/race, not an established root cause or a latency-budget failure.

The fold’s numerical verdict is decided against the three before points: 59.6054 versus 88.9174056 e2e minutes, a -29.3120056-minute difference. The -26.38-minute typical-PR arithmetic is the observed difference scaled by0.9, **not an attributable E saving**. Manager a66 requires the M2Pro/5-core point to be treated as not comparable to M1/3-core baselines for attribution. Report all points; if E2 is M1, prefer its matched comparison and disclose that choice. Do not infer a combination saving from the hardware-confounded numerical verdict. No extra baseline or third after run is authorized.

Every completed E1 job’s cache log is now read: lint, Linux, Windows and macOS have zero Actions-cache saves and Nx stored0; budgets job132966491793 has no cache restore/save or Nx store step. Budgets succeeded; all other jobs concluded failure, with own-tier recoveries recorded separately. Final PR comments/checks were read and #1613 was closed with its demonstration branch deleted. E1 therefore wrote no Actions-cache/Nx cache entry. Mac cache/setup action spans (not transfer-only timing):

| Step | Restore observation | Action seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.026 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 24.461 |
| actions/setup-node@v4 | no restore | 0.417 |
| actions/setup-python@v5 | no restore | 0.120 |
| astral-sh/setup-uv@v6 | no restore | 1.766 |
| actions/cache/restore@v4 | hit | 0.893 |

Command run on 233371f0, whose output supplies the figures and retains the raw arithmetic verdict:

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-macos before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-macos before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-macos after:exit-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736250019/1/test-macos
```

```text
## 3 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 201.81 | 92.98 | 90.11 | 2121/2121 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 198.48 | 85.46 | 94.38 | 2121/2121 |
| before | 43736273251/1/132879453345 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | Apple M1 (Virtual) (3) | 156.54 | 55.82 | 82.26 | 2121/2121 |
| after | 43736250019/1/132879382738 (exit-1) | 8a18672992559a9088d2527a71de265522e7f84f | 9ba119ba96fa4544cea8889a2c809e9d01e65a84 | Apple M2 Pro (Virtual) (5) | 90.76 | 24.04 | 59.61 | 2120/2121 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 88.92 | 82.26–94.38 | 12.11 |
| after | 59.61 | 59.61–59.61 | 0.00 |

Difference, after − before: -29.31 min — decided: non-overlapping ranges and mean difference outside both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -26.38 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25419.7 | 0.0 | 5511.8 | 25749.0 | 0.0 | 4835.3 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 368.7 | 0.0 | 37.0 | 791.0 | 0.0 | 36.2 |
| onepipeline::commandstep::run | wait | 18.0 | 106.7 | 11.9 | 18.0 | 210.0 | 10.1 |
| onepipeline::dispatchenv::run | wait | 97.0 | 663.0 | 73.4 | 97.0 | 1026.0 | 46.3 |
| onepipeline::driver::attach | sleep | 27717.0 | 0.0 | 3681.1 | 24809.0 | 0.0 | 2834.2 |
| onepipeline::driver::confirm_driving | sleep | 1399.0 | 0.0 | 183.2 | 1372.0 | 0.0 | 155.6 |
| onepipeline::driver::submit_offered | sleep | 2134.0 | 0.0 | 275.1 | 2227.0 | 0.0 | 258.3 |
| onepipeline::hooks::run | wait | 112.0 | 473.0 | 45.7 | 114.0 | 819.0 | 32.2 |
| onepipeline::planedit::run | wait | 32.0 | 146.3 | 11.3 | 32.0 | 422.0 | 8.4 |
| onepipeline::stopguard::consult | wait | 78.0 | 177.0 | 13.2 | 78.0 | 214.0 | 4.0 |
| onepipeline::sys::gone_within | sleep | 915.3 | 0.0 | 88.8 | 3839813.0 | 0.0 | 42.4 |
| onepipeline::vcs::follow | sleep | 23467.7 | 0.0 | 2458.4 | 20652.0 | 0.0 | 1727.5 |
| onevcs::git::bounded | wait | 373858.0 | 769458.3 | 4174.0 | 369694.0 | 817297.0 | 2181.4 |
| onevcs::pool::maintain::run | wait | 34.7 | 600.0 | 26.3 | 35.0 | 1842.0 | 25.6 |
| onevcs::probe::read | wait | 359.3 | 723.7 | 4.9 | 361.0 | 722.0 | 1.8 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.3 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2121 e2e tests passed in a before run.
- before inventory-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after exit-1: 2120 passed in the tier; of the before runs' passes, not run and passed here: unwatched::a_host_sized_runs_root_is_answered_in_well_under_a_second_whatever_its_journals_hold; failed in the tier, passed on the job's re-run: unwatched::a_host_sized_runs_root_is_answered_in_well_under_a_second_whatever_its_journals_hold; failed and not passed again: none.
```


## A/macOS first point and A1 close — source ff55e535

[Run 43736257614, test-macos job 132879405816](https://github.com/nickderobertis/onepipeline/actions/runs/43736257614/job/132879405816), GITHUB_SHA f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7, head7c1a2c4daae604222efab39cf976a6b9258b3f8c; workflowdb2bbe081a7b9319eb38bd014e72350b389e8b01. Artifact 14182381699, SHA-256 7c1d92855a84b2e8b0c4fb101229ee542c7c66fd389afb37f584656bef74e90f. Launch-host.json: AppleM1(Virtual),3logical/3physical cores, matching before-side hardware class. API job 177.11667 minutes; compile/earlier-tier pre-e2e span 68.83425 minutes. Full platform Nx selection equals both inventory selections.

Main `Summary [5652.889s] 2121 tests run: 2120 passed (39 slow), 1 timed out, 1 skipped`. The held-release adoption journey timed out at360.025seconds and passed own reruns133.880seconds (21:53:48UTC),130.490 and131.521seconds. All2,121baseline names passed across main plus own reruns, preserving the main-tier failure in the fold. A1’s complete cache audit is zero writes across lint/Linux/Windows/macOS; budgets job132973099280 has no cache restore/save or Nx store. Budgets succeeded, other jobs failed. PR comments and checks were captured, then #1614 was closed and its branch deleted.

A’s94.21482-minute matched-class point is5.30minutes slower than the three-before88.92mean, inside its12.11-minute spread: undecided. The4.77-minute typical-PR arithmetic is not a demonstrated cost forecast. Wait/site counts and changed-journey launch observations come from this complete artifact fold below. Cache/setup action spans (not transfer-only):

| Step | Restore observation | Action seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.069 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 56.559 |
| actions/setup-node@v4 | no restore | 0.880 |
| actions/setup-python@v5 | no restore | 0.215 |
| astral-sh/setup-uv@v6 | no restore | 2.175 |
| actions/cache/restore@v4 | hit | 2.159 |

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-macos before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-macos before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-macos after:adaptive-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736257614/1/test-macos
```

```text
## 3 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 201.81 | 92.98 | 90.11 | 2121/2121 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 198.48 | 85.46 | 94.38 | 2121/2121 |
| before | 43736273251/1/132879453345 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | Apple M1 (Virtual) (3) | 156.54 | 55.82 | 82.26 | 2121/2121 |
| after | 43736257614/1/132879405816 (adaptive-1) | f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7 | 7c1a2c4daae604222efab39cf976a6b9258b3f8c | Apple M1 (Virtual) (3) | 177.06 | 68.83 | 94.21 | 2120/2121 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 88.92 | 82.26–94.38 | 12.11 |
| after | 94.21 | 94.21–94.21 | 0.00 |

Difference, after − before: 5.30 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 4.77 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25419.7 | 0.0 | 5511.8 | 24959.0 | 0.0 | 5434.0 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 368.7 | 0.0 | 37.0 | 371.0 | 0.0 | 37.1 |
| onepipeline::commandstep::run | wait | 18.0 | 106.7 | 11.9 | 18.0 | 105.0 | 12.1 |
| onepipeline::dispatchenv::run | wait | 97.0 | 663.0 | 73.4 | 97.0 | 591.0 | 64.4 |
| onepipeline::driver::attach | sleep | 27717.0 | 0.0 | 3681.1 | 49280.0 | 0.0 | 3505.7 |
| onepipeline::driver::confirm_driving | sleep | 1399.0 | 0.0 | 183.2 | 3093.0 | 0.0 | 73.3 |
| onepipeline::driver::submit_offered | sleep | 2134.0 | 0.0 | 275.1 | 3869.0 | 0.0 | 276.1 |
| onepipeline::hooks::run | wait | 112.0 | 473.0 | 45.7 | 113.0 | 476.0 | 45.3 |
| onepipeline::planedit::run | wait | 32.0 | 146.3 | 11.3 | 32.0 | 150.0 | 11.4 |
| onepipeline::stopguard::consult | wait | 78.0 | 177.0 | 13.2 | 78.0 | 176.0 | 13.0 |
| onepipeline::sys::gone_within | sleep | 915.3 | 0.0 | 88.8 | 928.0 | 0.0 | 91.7 |
| onepipeline::vcs::follow | sleep | 23467.7 | 0.0 | 2458.4 | 22521.0 | 0.0 | 2275.0 |
| onevcs::git::bounded | wait | 373858.0 | 769458.3 | 4174.0 | 373998.0 | 765410.0 | 3927.4 |
| onevcs::pool::maintain::run | wait | 34.7 | 600.0 | 26.3 | 33.0 | 554.0 | 26.0 |
| onevcs::probe::read | wait | 359.3 | 723.7 | 4.9 | 353.0 | 714.0 | 5.0 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.3 | 32.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2121 e2e tests passed in a before run.
- before inventory-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after adaptive-1: 2120 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed and not passed again: none.
```


## E2 completed lint identity/cache audit — source ff55e535

[Run43765240430, lint job132968741726](https://github.com/nickderobertis/onepipeline/actions/runs/43765240430/job/132968741726) confirms executed GITHUB_SHA82b1540c1a151fbdb249216b6e5c38be9b5b0fa4, head76e124ef58e4d67fef8db8657478eae38fffedbb, base233371f09adec1b6bbe0cdc2fd6fb872d1760992, workflowdb2bbe081a7b9319eb38bd014e72350b389e8b01. The log reports at22:08:56.7340535Z `40 rules: 26 passed, 0 failed, 8 skipped, 6 not relevant`, against main41416e1475b68354723305b7a9ca7471596f7718. The deliberately required DO NOT MERGE title failed the conventional-title step; this is not a judged-code failure. Zero Actions-cache saves and Nx stored0entries/0bytes/replayed0. Full54-task selection and action spans are in exit-2-lint-facts.json.gz; raw log in exit-2-lint.log.gz. This additional hosted green judgment does not erase the retained local reader limitations under a46. Platform audits remain pending.


## A/Linux required two after points complete — source fd179821

[Run43758902628, test-linux job132949007160](https://github.com/nickderobertis/onepipeline/actions/runs/43758902628/job/132949007160), GITHUB_SHA1c9812957a60e44e4357116128eeb69723c3acce, head45363fbb55df1fda289eeca78bb9de14624652c5, workflowdb2bbe081a7b9319eb38bd014e72350b389e8b01. Artifact14183819322, SHA-256803898c7701966cd6d21160142fe5eca42b7f5b32dd1769165a377372e954b79. Processor: IntelXeon6975P-C,4logical cores. JobAPI duration116.58333minutes; compilation/earlier tiers before e2e76.77047minutes. Main summary `Summary [2263.167s] 2155 tests run: 2155 passed (23 slow), 1 skipped`. All2,155baseline names passed in the main tier, no recovery needed, full37-task selection matches both inventory Linux selections. Overall job failed the known patch audit; this is not an e2e failure.

Merged coverage was not produced: at21:20:56.9338554Z `the patch of oneagentgraph is not a git source` (original includes backticks); at22:44:02.5641092Z `Tasks not run because their dependencies failed or --nx-bail=true:`, followed at22:44:02.5641678Z by `onepipeline:test`. No merged percentage is claimed; floor remains95.74LCOV/95%policy (a27). No Actions-cache save; Nx stored0entries/0bytes/replayed0. Cache/setup action spans, not transfer-only times:

| Step | Restore observation | Action seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.004 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 68.896 |
| actions/setup-node@v4 | no restore | 4.646 |
| actions/setup-python@v5 | miss | 5.630 |
| astral-sh/setup-uv@v6 | no restore | 2.240 |
| actions/cache/restore@v4 | hit | 2.362 |

A/Linux now has exactly the two authorized after points. Mean38.4758417minutes versus three-before40.2337389, a measured1.7578972-minute difference; before spread3.8074667minutes exceeds it, so **undecided**, not an established saving. The1.58-minute typical-PR arithmetic printed below is an estimate of the observed difference scaled by0.9 and is not a reliable saving claim. No third point is authorized or needed for this spike’s revised bar. Counts/wait seconds below are mean per recorded e2e tier, with overlapping waits not added into wall savings. Source: these hosted summaries/artifacts and the following branch fold run on fd179821.

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-linux before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-linux before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-linux after:adaptive-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736257614/1/test-linux after:adaptive-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43758902628/1/test-linux
```

```text
## 3 before run(s) against 2 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| before | 43736273251/1/132879453312 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 7763 64-Core Processor (4) | 176.69 | 131.14 | 41.73 | 2155/2155 |
| after | 43736257614/1/132879405862 (adaptive-1) | f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7 | 7c1a2c4daae604222efab39cf976a6b9258b3f8c | AMD EPYC 9V45 96-Core Processor (4) | 117.44 | 76.13 | 39.23 | 2155/2155 |
| after | 43758902628/1/132949007160 (adaptive-2) | 1c9812957a60e44e4357116128eeb69723c3acce | 45363fbb55df1fda289eeca78bb9de14624652c5 | Intel(R) Xeon(R) 6975P-C (4) | 116.47 | 76.77 | 37.72 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 40.23 | 37.92–41.73 | 3.81 |
| after | 38.48 | 37.72–39.23 | 1.51 |

Difference, after − before: -1.76 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -1.58 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25243.0 | 0.0 | 2273.8 | 25070.5 | 0.0 | 2231.2 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1727.3 | 0.0 | 34.7 | 1742.5 | 0.0 | 35.0 |
| onepipeline::commandstep::run | wait | 18.0 | 214.0 | 9.9 | 18.0 | 212.0 | 9.8 |
| onepipeline::dispatchenv::run | wait | 97.0 | 313.0 | 11.1 | 97.0 | 311.0 | 11.0 |
| onepipeline::driver::attach | sleep | 38535.3 | 0.0 | 1931.0 | 71337.0 | 0.0 | 1805.8 |
| onepipeline::driver::confirm_driving | sleep | 1439.7 | 0.0 | 72.2 | 4490.0 | 0.0 | 31.6 |
| onepipeline::driver::submit_offered | sleep | 4237.0 | 0.0 | 212.2 | 6353.0 | 0.0 | 204.1 |
| onepipeline::hooks::run | wait | 111.7 | 832.3 | 36.2 | 111.5 | 831.0 | 36.1 |
| onepipeline::planedit::run | wait | 32.0 | 461.3 | 8.7 | 32.0 | 462.0 | 8.7 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.3 | 6.9 | 78.0 | 213.5 | 6.9 |
| onepipeline::sys::gone_within | sleep | 2684.0 | 0.0 | 53.9 | 2660.0 | 0.0 | 53.4 |
| onepipeline::vcs::follow | sleep | 48495.7 | 0.0 | 975.2 | 47952.5 | 0.0 | 951.9 |
| onevcs::git::bounded | wait | 365183.0 | 879835.0 | 1339.3 | 364588.0 | 860789.0 | 1135.7 |
| onevcs::pool::maintain::run | wait | 35.0 | 2463.7 | 24.2 | 32.0 | 2447.5 | 24.1 |
| onevcs::probe::read | wait | 350.3 | 747.0 | 0.7 | 351.0 | 769.0 | 0.9 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after adaptive-1: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after adaptive-2: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
```


## A/Windows required two after points complete — source 471db450

[Run43758902628, test-windows job132949006949](https://github.com/nickderobertis/onepipeline/actions/runs/43758902628/job/132949006949), executed GITHUB_SHA1c9812957a60e44e4357116128eeb69723c3acce, head45363fbb55df1fda289eeca78bb9de14624652c5, workflowdb2bbe081a7b9319eb38bd014e72350b389e8b01. Artifact14185160744, SHA-2567013ab839ed45423c017de6470de5b40beb520b87184258349a6cc0aa3b627c3; AMD EPYC9V45 96-Core Processor,4logical cores from launch-host.json. JobAPI duration148.78333minutes; compile/earlier-tier pre-e2e44.45813minutes. Full39-task selection matches both inventory selections. No Actions-cache save; Nx stored0entries/0bytes/replayed0. Overall job failure is preserved.

Main `Summary [5711.557s] 1832 tests run: 1831 passed (58 slow), 1 timed out, 1 skipped`. Held-release adoption timed out540.142seconds, then passed its own rerun139.019seconds at23:01:28UTC, with later passes142.273 and141.168seconds. All1,832baseline names passed across main plus own rerun; the main failure remains listed. Its original profile remains unfinished at535.808945wall seconds, so that attempt’s counters are incomplete; the later PASS log proves recovery without supplying a complete replacement profile. Cache/setup action spans (not transfer-only times):

| Step | Restore observation | Action seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.017 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 70.160 |
| actions/setup-node@v4 | no restore | 4.603 |
| actions/setup-python@v5 | no restore | 0.131 |
| astral-sh/setup-uv@v6 | no restore | 2.417 |
| actions/cache/restore@v4 | hit | 1.128 |

A/Windows’s two after points are137.7133333 and95.1926167minutes, mean116.452975 versus three-before107.5758944: +8.8770806minutes. Before spread45.8813333 and after spread42.5207167 both exceed that difference: **undecided**. The second point is below the overall before mean, so a61’s conditional “second point also adverse” is not met; do not label this pair likely slower. Its pooled mean is higher, but directions versus the overall before mean are mixed. It supplies no decided saving for a Windows combination. The printed+7.99-minute typical-PR arithmetic is an estimate of the observed difference, not a demonstrated cost forecast.

Source: the named hosted summaries/artifacts and this fold command, run on471db450. Exactly two A/Windows after points are complete; no third run is authorized.

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-windows before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-windows before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-windows after:adaptive-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736257614/1/test-windows after:adaptive-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43758902628/1/test-windows
```

```text
## 3 before run(s) against 2 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 9V45 96-Core Processor (4) | 144.66 | 57.17 | 87.11 | 1832/1832 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 7763 64-Core Processor (4) | 251.47 | 92.90 | 132.99 | 1832/1832 |
| before | 43736273251/1/132879453337 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 9V74 80-Core Processor (4) | 171.91 | 68.60 | 102.62 | 1830/1832 |
| after | 43736257614/1/132879405490 (adaptive-1) | f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7 | 7c1a2c4daae604222efab39cf976a6b9258b3f8c | INTEL(R) XEON(R) PLATINUM 8573C (4) | 215.60 | 67.90 | 137.71 | 1831/1832 |
| after | 43758902628/1/132949006949 (adaptive-2) | 1c9812957a60e44e4357116128eeb69723c3acce | 45363fbb55df1fda289eeca78bb9de14624652c5 | AMD EPYC 9V45 96-Core Processor (4) | 148.74 | 44.46 | 95.19 | 1831/1832 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 107.58 | 87.11–132.99 | 45.88 |
| after | 116.45 | 95.19–137.71 | 42.52 |

Difference, after − before: 8.88 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 7.99 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 24391.7 | 0.0 | 6370.5 | 24301.0 | 0.0 | 6266.1 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 241.3 | 0.0 | 5.0 | 243.5 | 0.0 | 5.1 |
| onepipeline::commandstep::run | wait | 13.0 | 160.0 | 8.2 | 13.0 | 161.0 | 8.2 |
| onepipeline::dispatchenv::run | wait | 81.3 | 309.3 | 12.1 | 81.0 | 309.5 | 12.1 |
| onepipeline::driver::attach | sleep | 165102.7 | 0.0 | 8781.3 | 209002.5 | 0.0 | 8828.7 |
| onepipeline::driver::confirm_driving | sleep | 1333.0 | 0.0 | 69.2 | 4662.5 | 0.0 | 48.6 |
| onepipeline::driver::submit_offered | sleep | 5189.7 | 0.0 | 268.2 | 7249.0 | 0.0 | 266.9 |
| onepipeline::hooks::run | wait | 65.0 | 837.3 | 39.9 | 65.5 | 841.0 | 40.2 |
| onepipeline::planedit::run | wait | 30.0 | 611.0 | 12.2 | 30.0 | 609.0 | 12.1 |
| onepipeline::sys::gone_within | sleep | 55.0 | 0.0 | 1.2 | 62.5 | 0.0 | 1.3 |
| onepipeline::vcs::follow | sleep | 231658.7 | 0.0 | 5469.4 | 175088.0 | 0.0 | 5537.1 |
| onevcs::git::PipeRead::await_readable | sleep | 2025139.3 | 0.0 | 23516.9 | 2092769.0 | 0.0 | 24145.2 |
| onevcs::git::bounded | wait | 382513.3 | 1604084.0 | 17574.7 | 381162.0 | 1622837.0 | 17836.8 |
| onevcs::pool::maintain::run | wait | 19.0 | 1614.7 | 24.8 | 18.5 | 1607.5 | 24.8 |
| onevcs::probe::read | wait | 379.0 | 966.7 | 12.2 | 371.5 | 929.5 | 11.2 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 14.3 | 17.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 34.3 | 36.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 4.0 | 4.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |

### Tests

1832 e2e tests passed in a before run.
- before inventory-1: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 1830 passed in the tier; failed in the tier, passed on the job's re-run: boundary::an_unusable_attempt_budget_falls_back_rather_than_disabling_the_recovery, store::a_project_larger_than_one_page_is_read_to_its_end; failed and not passed again: none.
- after adaptive-1: 1831 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed and not passed again: none.
- after adaptive-2: 1831 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed and not passed again: none.
```


## E/macOS required two after points complete — source0c1a4bc7

[Run43765240430, test-macos job132968741529](https://github.com/nickderobertis/onepipeline/actions/runs/43765240430/job/132968741529), executed GITHUB_SHA82b1540c1a151fbdb249216b6e5c38be9b5b0fa4, head76e124ef58e4d67fef8db8657478eae38fffedbb; workflowdb2bbe081a7b9319eb38bd014e72350b389e8b01. Artifact14186466809, SHA-256372447593c6384eea3323c52c57ee3105683765d3c79cdc870e97f2f415764a9. Host: AppleM2Pro(Virtual),5logical/5physical cores, the same hardware class as E1 and unlike every M1/3-core before point. JobAPI duration92.78333minutes; pre-e2e compilation/earlier tiers24.86403minutes. Main summary `Summary [3691.635s] 2121 tests run: 2121 passed (34 slow), 1 skipped`; all2,121baseline names passed in main, no rerun recovery needed. Full Nx selection matches both inventory Mac selections. Overall job failure remains explicit. No Actions-cache save, Nx stored0entries/0bytes/replayed0. Cache/setup action spans, not transfer-only timing:

| Step | Restore observation | Action seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.042 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 22.116 |
| actions/setup-node@v4 | no restore | 0.446 |
| actions/setup-python@v5 | no restore | 0.121 |
| astral-sh/setup-uv@v6 | no restore | 1.608 |
| actions/cache/restore@v4 | hit | 0.460 |

E’s two Mac points average60.566325minutes against before88.9174056: observed difference-28.3510806minutes. Before spread12.1143 and after spread1.92185 are smaller, so the fold’s **arithmetic** verdict is decided; its typical-PR arithmetic is-25.52minutes. Under a66, **neither after point is comparable for attribution**, because both are M2Pro/5cores and all before points are M1/3cores. There is no matched M1 E2 point to prefer. Thus attributable E/macOS minutes remain undetermined; do not call25.52minutes an expected prototype saving or use it to justify a combination. The authorized two points are complete; no third or additional baseline is started.

Source: these hosted summaries/artifacts and the branch fold below, run on0c1a4bc7. Counts are recorded observations; timing attribution is separately limited by hardware.

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-macos before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-macos before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-macos after:exit-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736250019/1/test-macos after:exit-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43765240430/1/test-macos
```

```text
## 3 before run(s) against 2 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 201.81 | 92.98 | 90.11 | 2121/2121 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 198.48 | 85.46 | 94.38 | 2121/2121 |
| before | 43736273251/1/132879453345 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | Apple M1 (Virtual) (3) | 156.54 | 55.82 | 82.26 | 2121/2121 |
| after | 43736250019/1/132879382738 (exit-1) | 8a18672992559a9088d2527a71de265522e7f84f | 9ba119ba96fa4544cea8889a2c809e9d01e65a84 | Apple M2 Pro (Virtual) (5) | 90.76 | 24.04 | 59.61 | 2120/2121 |
| after | 43765240430/1/132968741529 (exit-2) | 82b1540c1a151fbdb249216b6e5c38be9b5b0fa4 | 76e124ef58e4d67fef8db8657478eae38fffedbb | Apple M2 Pro (Virtual) (5) | 92.76 | 24.86 | 61.53 | 2121/2121 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 88.92 | 82.26–94.38 | 12.11 |
| after | 60.57 | 59.61–61.53 | 1.92 |

Difference, after − before: -28.35 min — decided: non-overlapping ranges and mean difference outside both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -25.52 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25419.7 | 0.0 | 5511.8 | 26018.0 | 0.0 | 4854.6 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 368.7 | 0.0 | 37.0 | 623.5 | 0.0 | 36.1 |
| onepipeline::commandstep::run | wait | 18.0 | 106.7 | 11.9 | 18.0 | 210.5 | 10.1 |
| onepipeline::dispatchenv::run | wait | 97.0 | 663.0 | 73.4 | 97.0 | 1030.0 | 46.5 |
| onepipeline::driver::attach | sleep | 27717.0 | 0.0 | 3681.1 | 25276.0 | 0.0 | 2882.4 |
| onepipeline::driver::confirm_driving | sleep | 1399.0 | 0.0 | 183.2 | 1371.5 | 0.0 | 156.5 |
| onepipeline::driver::submit_offered | sleep | 2134.0 | 0.0 | 275.1 | 2210.0 | 0.0 | 259.7 |
| onepipeline::hooks::run | wait | 112.0 | 473.0 | 45.7 | 114.0 | 819.5 | 32.2 |
| onepipeline::planedit::run | wait | 32.0 | 146.3 | 11.3 | 32.0 | 423.0 | 8.5 |
| onepipeline::stopguard::consult | wait | 78.0 | 177.0 | 13.2 | 78.0 | 214.0 | 4.1 |
| onepipeline::sys::gone_within | sleep | 915.3 | 0.0 | 88.8 | 3858243.5 | 0.0 | 42.6 |
| onepipeline::vcs::follow | sleep | 23467.7 | 0.0 | 2458.4 | 21175.5 | 0.0 | 1777.3 |
| onevcs::git::bounded | wait | 373858.0 | 769458.3 | 4174.0 | 369741.5 | 825609.5 | 2292.0 |
| onevcs::pool::maintain::run | wait | 34.7 | 600.0 | 26.3 | 34.5 | 1877.0 | 25.6 |
| onevcs::probe::read | wait | 359.3 | 723.7 | 4.9 | 357.0 | 716.5 | 1.9 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.3 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2121 e2e tests passed in a before run.
- before inventory-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after exit-1: 2120 passed in the tier; of the before runs' passes, not run and passed here: unwatched::a_host_sized_runs_root_is_answered_in_well_under_a_second_whatever_its_journals_hold; failed in the tier, passed on the job's re-run: unwatched::a_host_sized_runs_root_is_answered_in_well_under_a_second_whatever_its_journals_hold; failed and not passed again: none.
- after exit-2: 2121 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
```


## E/Linux required two points complete — source8c5c28d4

[Run43765240430, test-linux job132968741744](https://github.com/nickderobertis/onepipeline/actions/runs/43765240430/job/132968741744), GITHUB_SHA82b1540c1a151fbdb249216b6e5c38be9b5b0fa4, head76e124ef58e4d67fef8db8657478eae38fffedbb; workflowdb2bbe081a7b9319eb38bd014e72350b389e8b01. Artifact14187406959, SHA-2564246aaac86f489c7f1872bea1812dd07a15e9e657a12e92335aba05a27baaf78. Processor: IntelXeon6973P-C,4logical cores from launch-host.json. JobAPI duration144.16667minutes; pre-e2e compilation/earlier tiers84.54875minutes. Full37-task selection equals both inventory selections. Main `Summary [2238.518s] 2155 tests run: 2155 passed (23 slow), 1 skipped`.

There are2,154retained main-tier profiles. The later budget run overwrote `loopcost::the_settlement_readability_latency_is_reported_from_its_journal_stamps`; two scoped original-tier process records plus the all-passed summary reconcile that one name, yielding all2,155baseline names run/passed. Original aggregate counters for the overwritten profile cannot be recovered. The raw fold preserves its missing-profile warning below; the supplementary named proof is in exit-linux-round2-proof.json.gz. Do not interpret the overwritten counters as zero observations.

Merged coverage was not produced:22:18:40.7492395Z `the patch of oneagentgraph is not a git source` (original includes backticks);00:06:54.6896039Z `Tasks not run because their dependencies failed or --nx-bail=true:`, followed at00:06:54.6896446Z by `onepipeline:test`. Floor95.74LCOV/95%policy unchanged. Overall job failure remains explicit. No Actions-cache save; Nx stored0entries/0bytes/replayed0. Cache/setup action spans (not transfer-only timing):

| Step | Restore observation | Action seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.005 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 59.181 |
| actions/setup-node@v4 | no restore | 0.499 |
| actions/setup-python@v5 | miss | 9.521 |
| astral-sh/setup-uv@v6 | no restore | 2.744 |
| actions/cache/restore@v4 | hit | 1.243 |

Two E/Linux points average38.61945minutes versus three-before40.2337389, difference-1.6142889minutes. Before spread3.8074667 and after spread2.6216333 exceed that difference: **undecided**. The printed-1.45-minute typical-PR arithmetic is an estimate of the observed difference, not an established saving. Exactly two points are complete; no third run. Source: these hosted summaries/artifacts and this fold command, run on8c5c28d4.

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-linux before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-linux before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-linux after:exit-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736250019/1/test-linux after:exit-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43765240430/1/test-linux
```

```text
## 3 before run(s) against 2 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| before | 43736273251/1/132879453312 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 7763 64-Core Processor (4) | 176.69 | 131.14 | 41.73 | 2155/2155 |
| after | 43736250019/1/132879382741 (exit-1) | 8a18672992559a9088d2527a71de265522e7f84f | 9ba119ba96fa4544cea8889a2c809e9d01e65a84 | AMD EPYC 9V74 80-Core Processor (4) | 128.57 | 85.91 | 39.93 | 2155/2155 |
| after | 43765240430/1/132968741744 (exit-2) | 82b1540c1a151fbdb249216b6e5c38be9b5b0fa4 | 76e124ef58e4d67fef8db8657478eae38fffedbb | Intel(R) Xeon(R) 6973P-C (4) | 144.09 | 84.55 | 37.31 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 40.23 | 37.92–41.73 | 3.81 |
| after | 38.62 | 37.31–39.93 | 2.62 |

Difference, after − before: -1.61 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -1.45 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25243.0 | 0.0 | 2273.8 | 25031.0 | 0.0 | 2177.8 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1727.3 | 0.0 | 34.7 | 1729.5 | 0.0 | 34.7 |
| onepipeline::commandstep::run | wait | 18.0 | 214.0 | 9.9 | 18.0 | 213.0 | 9.3 |
| onepipeline::dispatchenv::run | wait | 97.0 | 313.0 | 11.1 | 97.0 | 309.0 | 7.2 |
| onepipeline::driver::attach | sleep | 38535.3 | 0.0 | 1931.0 | 34676.0 | 0.0 | 1738.3 |
| onepipeline::driver::confirm_driving | sleep | 1439.7 | 0.0 | 72.2 | 1451.5 | 0.0 | 72.8 |
| onepipeline::driver::submit_offered | sleep | 4237.0 | 0.0 | 212.2 | 4030.0 | 0.0 | 201.9 |
| onepipeline::hooks::run | wait | 111.7 | 832.3 | 36.2 | 114.0 | 835.0 | 31.0 |
| onepipeline::planedit::run | wait | 32.0 | 461.3 | 8.7 | 32.0 | 462.0 | 8.2 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.3 | 6.9 | 78.0 | 215.0 | 3.4 |
| onepipeline::sys::gone_within | sleep | 2684.0 | 0.0 | 53.9 | 2095718.0 | 0.0 | 41.6 |
| onepipeline::vcs::follow | sleep | 48495.7 | 0.0 | 975.2 | 44597.0 | 0.0 | 897.3 |
| onevcs::git::bounded | wait | 365183.0 | 879835.0 | 1339.3 | 364569.5 | 742453.5 | 679.6 |
| onevcs::pool::maintain::run | wait | 35.0 | 2463.7 | 24.2 | 35.0 | 2449.0 | 24.1 |
| onevcs::probe::read | wait | 350.3 | 747.0 | 0.7 | 356.0 | 708.5 | 0.3 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 8.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after exit-1: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after exit-2: 2154 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
```


## R2 lint identity, inherited findings and cancellation — one-log exception a80

[Run43775937612, lint job133002128717](https://github.com/nickderobertis/onepipeline/actions/runs/43775937612/job/133002128717) confirms executed GITHUB_SHAbd062baf4539baa3ac21165b20fb0580cd25df72, heade156f19aa0d669eee79490ce7c49096b45ffcef2, base39498db2e1db78c3ad6a8cc2ddbc024cb369fc98, workflowdb2bbe081a7b9319eb38bd014e72350b389e8b01. It selected54affected tasks; the affected formatting/lint/audit step succeeded. Its cache-report step succeeded with Nx stored0entries/0bytes/replayed0, no Actions-cache save, and Rust-cache post save skipped. The background cache-server step was cancelled during cleanup, not a cache write.

The judged step against main41416e1475b68354723305b7a9ca7471596f7718 reported `40 rules: 25 passed, 2 failed, 8 skipped, 5 not relevant`, history20261116T000657Z-1360a. Findings: `comments_earn_their_place` at inherited vendor/onejudge/src/provider.rs:772-774 (decorative banner); `new_code_lands_in_a_project` across20inherited vendor/oneagentgraph source files excluded by `.nxignore`. `git diff --name-only 13eb521a -- vendor/onejudge/src/provider.rs vendor/oneagentgraph` on8c5c28d4 printed nothing: neither area belongs to this spike’s diff. No inherited vendor file, rule or project configuration was changed to clear them. These whole-stack main-based findings are distinct from the retained three local reader limitations under a46. Manager a81 confirmed recording this interpretation without edits.

Job started23:38:54UTC, completed00:09:12UTC with conclusion cancelled. At00:09:07.3328126Z the gallery/screencomp deployment log says `The operation was canceled.` The stock lint job has timeout-minutes30 at ci.yml:52; elapsed30minutes18seconds is consistent with that limit, but the log does not identify a cancelling actor, so no stronger cause is asserted. This worker initiated no cancellation. The judged step had already failed as above; the conventional-title check was skipped. Platform jobs continue independently; no extra run is started.

Full lint log/facts and complete selected task/cache-step arrays are archived. This log was fetched once under a80’s explicit exception after the primary core allowance reached2,496, below this worker’s2,500floor. The2,000host floor is reserved for manager exceptions, not a general worker allowance. All further hosted reads/publication are held until00:52:49UTC reset; local evidence is committed meanwhile.


## E/Windows required two points complete; E2 closed — source7da20a80

[Run43765240430, test-windows job132968741764](https://github.com/nickderobertis/onepipeline/actions/runs/43765240430/job/132968741764), GITHUB_SHA82b1540c1a151fbdb249216b6e5c38be9b5b0fa4, head76e124ef58e4d67fef8db8657478eae38fffedbb; workflowdb2bbe081a7b9319eb38bd014e72350b389e8b01. Artifact14190585156, SHA-25602c2a46fa84d5fc987fc9e53b3edf58f28d2ff227e755551267a967599755bf6. Host: AMD EPYC7763 64-Core Processor,4logical cores. JobAPI duration222.75000minutes; pre-e2e compilation/earlier tiers74.70638minutes. Full39-task selection equals both inventory selections. Main `Summary [8291.854s] 1832 tests run: 1831 passed (118 slow), 1 timed out, 1 skipped`.

Held-release adoption timed out540.167seconds, then passed its own rerun143.311seconds at01:21:02UTC, with later passes143.537 and144.218seconds. All1,832baseline names passed across main plus own reruns. Original profile remains unfinished at536.0107985wall seconds, so its counters are incomplete; later PASS proves recovery without a replacement complete profile. No assertion or timeout was changed.

The two E/Windows points have unrounded mean123.835minutes (the fold’s floating-point formatting prints123.83), versus three-before107.5758944: +16.2591056minutes. Before spread45.8813333 and after spread28.7251333 exceed that difference: **undecided**, no saving. The printed+14.63-minute typical-PR arithmetic estimates the observed difference scaled by0.9; it is not a demonstrated cost forecast. Both after points are above the pooled before mean, but the mean difference remains inside the prescribed spreads.

E2’s complete workflow cache audit is now read: lint/Linux/Windows/macOS report no Actions-cache save and Nx stored0; budgets job133034427608 has no cache restore/save or Nx store step. Budgets succeeded; other jobs failed as separately recorded. The budgets checkout matches full82b1540c1a151fbdb249216b6e5c38be9b5b0fa4. Final PR comments/checks were captured; #1637 closed and its remote/local demonstration branch deleted after all jobs were read. No Actions-cache/Nx remote entry was written by E2. Windows cache/setup action spans, not transfer-only timing:

| Step | Restore observation | Action seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.023 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 49.039 |
| actions/setup-node@v4 | no restore | 8.518 |
| actions/setup-python@v5 | no restore | 0.199 |
| astral-sh/setup-uv@v6 | no restore | 3.185 |
| actions/cache/restore@v4 | hit | 1.739 |

Source: these hosted summaries/artifacts and this fold command run on7da20a80:

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-windows before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-windows before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-windows after:exit-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736250019/1/test-windows after:exit-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43765240430/1/test-windows
```

```text
## 3 before run(s) against 2 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 9V45 96-Core Processor (4) | 144.66 | 57.17 | 87.11 | 1832/1832 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 7763 64-Core Processor (4) | 251.47 | 92.90 | 132.99 | 1832/1832 |
| before | 43736273251/1/132879453337 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 9V74 80-Core Processor (4) | 171.91 | 68.60 | 102.62 | 1830/1832 |
| after | 43736250019/1/132879382569 (exit-1) | 8a18672992559a9088d2527a71de265522e7f84f | 9ba119ba96fa4544cea8889a2c809e9d01e65a84 | AMD EPYC 9V74 80-Core Processor (4) | 175.11 | 56.47 | 109.47 | 1831/1832 |
| after | 43765240430/1/132968741764 (exit-2) | 82b1540c1a151fbdb249216b6e5c38be9b5b0fa4 | 76e124ef58e4d67fef8db8657478eae38fffedbb | AMD EPYC 7763 64-Core Processor (4) | 222.69 | 74.71 | 138.20 | 1831/1832 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 107.58 | 87.11–132.99 | 45.88 |
| after | 123.83 | 109.47–138.20 | 28.73 |

Difference, after − before: 16.26 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 14.63 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 24391.7 | 0.0 | 6370.5 | 24302.0 | 0.0 | 6659.0 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 241.3 | 0.0 | 5.0 | 243.0 | 0.0 | 5.1 |
| onepipeline::commandstep::run | wait | 13.0 | 160.0 | 8.2 | 13.0 | 156.5 | 10.0 |
| onepipeline::dispatchenv::run | wait | 81.3 | 309.3 | 12.1 | 82.0 | 296.5 | 11.2 |
| onepipeline::driver::attach | sleep | 165102.7 | 0.0 | 8781.3 | 170440.0 | 0.0 | 9227.4 |
| onepipeline::driver::confirm_driving | sleep | 1333.0 | 0.0 | 69.2 | 1347.5 | 0.0 | 70.9 |
| onepipeline::driver::submit_offered | sleep | 5189.7 | 0.0 | 268.2 | 5212.5 | 0.0 | 272.8 |
| onepipeline::hooks::run | wait | 65.0 | 837.3 | 39.9 | 65.5 | 774.0 | 40.3 |
| onepipeline::planedit::run | wait | 30.0 | 611.0 | 12.2 | 30.0 | 489.0 | 14.3 |
| onepipeline::sys::gone_within | sleep | 55.0 | 0.0 | 1.2 | 45.5 | 0.0 | 0.1 |
| onepipeline::vcs::follow | sleep | 231658.7 | 0.0 | 5469.4 | 234349.0 | 0.0 | 5790.0 |
| onevcs::git::PipeCapture::start | sleep | 0.0 | 0.0 | 0.0 | 1603958.5 | 0.0 | 24475.7 |
| onevcs::git::PipeRead::await_readable | sleep | 2025139.3 | 0.0 | 23516.9 | 0.0 | 0.0 | 0.0 |
| onevcs::git::bounded | wait | 382513.3 | 1604084.0 | 17574.7 | 383461.5 | 1734149.5 | 19616.7 |
| onevcs::pool::maintain::run | wait | 19.0 | 1614.7 | 24.8 | 19.0 | 1607.0 | 24.8 |
| onevcs::probe::read | wait | 379.0 | 966.7 | 12.2 | 374.0 | 946.0 | 13.1 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 14.3 | 17.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 34.3 | 35.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 4.0 | 4.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 8.5 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |

### Tests

1832 e2e tests passed in a before run.
- before inventory-1: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 1830 passed in the tier; failed in the tier, passed on the job's re-run: boundary::an_unusable_attempt_budget_falls_back_rather_than_disabling_the_recovery, store::a_project_larger_than_one_page_is_read_to_its_end; failed and not passed again: none.
- after exit-1: 1831 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed and not passed again: none.
- after exit-2: 1831 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed and not passed again: none.
```


## A/macOS required two points complete; A2 closed — sourcef08afdd8

[Run43758902628, test-macos job132949007217](https://github.com/nickderobertis/onepipeline/actions/runs/43758902628/job/132949007217), GITHUB_SHA1c9812957a60e44e4357116128eeb69723c3acce, head45363fbb55df1fda289eeca78bb9de14624652c5; workflowdb2bbe081a7b9319eb38bd014e72350b389e8b01. Artifact14191871214, SHA-2560cb2d57a86fb92fd52f9dfcdc21ed33f7b25954feb3bc6ef93bf7eaf08ae0d75. Host: AppleM2Pro(Virtual),5logical/5physical cores. JobAPI duration91.43333minutes; pre-e2e compilation/earlier tiers22.95047minutes. Full platform selection equals both inventory Mac selections. Main `Summary [3707.242s] 2121 tests run: 2120 passed (34 slow), 1 failed, 1 skipped`.

`watch::an_explicit_condition_replaces_the_default_set` failed at120.500seconds: at01:44:15UTC the harness said `timed out waiting for build to settle`, before the explicit-watch condition comparison. It passed own reruns4.928seconds at01:53:49UTC,4.864 and4.666seconds. All2,121baseline names passed across main plus own reruns. The cause is not established; do not misdescribe this as an assertion that the explicit condition itself was wrong. No timeout/assertion was altered.

The two after points average78.0010917minutes versus three-before88.9174056, observed difference-10.9163139minutes. Before spread12.1143 and after spread32.42745 make this **undecided**. The printed-9.82-minute typical-PR arithmetic is not an established saving. After hardware is mixed: A1M1/3cores, A2M2/5cores, while all before points are M1/3. Under a66, A2 is not comparable to those before points for attribution; the single matched-class A1 point94.21 is itself inside the before spread. No attributable Mac saving is claimed.

A2’s complete cache audit is read: all lint/platform logs report no Actions-cache save and Nx stored0; budgets job133042758447 has no restore/save/Nx store step and checked out full1c9812957a60e44e4357116128eeb69723c3acce. Budgets succeeded, the other jobs failed as recorded. Final comments/checks were captured; #1636 closed and its remote/local demonstration branch was deleted after all jobs were read. A2 wrote no Actions-cache/Nx remote entry. Mac cache/setup action spans, not transfer-only timing:

| Step | Restore observation | Action seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.030 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 21.461 |
| actions/setup-node@v4 | no restore | 0.468 |
| actions/setup-python@v5 | no restore | 0.129 |
| astral-sh/setup-uv@v6 | no restore | 1.741 |
| actions/cache/restore@v4 | hit | 0.418 |

Source: these hosted summaries/artifacts and this fold command, run onf08afdd8:

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-macos before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-macos before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-macos after:adaptive-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736257614/1/test-macos after:adaptive-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43758902628/1/test-macos
```

```text
## 3 before run(s) against 2 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 201.81 | 92.98 | 90.11 | 2121/2121 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 198.48 | 85.46 | 94.38 | 2121/2121 |
| before | 43736273251/1/132879453345 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | Apple M1 (Virtual) (3) | 156.54 | 55.82 | 82.26 | 2121/2121 |
| after | 43736257614/1/132879405816 (adaptive-1) | f96a10004d4ab11ca882d5a735bdb3f8f7e1e8e7 | 7c1a2c4daae604222efab39cf976a6b9258b3f8c | Apple M1 (Virtual) (3) | 177.06 | 68.83 | 94.21 | 2120/2121 |
| after | 43758902628/1/132949007217 (adaptive-2) | 1c9812957a60e44e4357116128eeb69723c3acce | 45363fbb55df1fda289eeca78bb9de14624652c5 | Apple M2 Pro (Virtual) (5) | 91.43 | 22.95 | 61.79 | 2120/2121 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 88.92 | 82.26–94.38 | 12.11 |
| after | 78.00 | 61.79–94.21 | 32.43 |

Difference, after − before: -10.92 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -9.82 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25419.7 | 0.0 | 5511.8 | 24980.0 | 0.0 | 5235.5 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 368.7 | 0.0 | 37.0 | 394.0 | 0.0 | 36.7 |
| onepipeline::commandstep::run | wait | 18.0 | 106.7 | 11.9 | 18.0 | 105.0 | 11.6 |
| onepipeline::dispatchenv::run | wait | 97.0 | 663.0 | 73.4 | 97.0 | 585.0 | 59.7 |
| onepipeline::driver::attach | sleep | 27717.0 | 0.0 | 3681.1 | 48576.5 | 0.0 | 3194.8 |
| onepipeline::driver::confirm_driving | sleep | 1399.0 | 0.0 | 183.2 | 3086.5 | 0.0 | 67.9 |
| onepipeline::driver::submit_offered | sleep | 2134.0 | 0.0 | 275.1 | 3917.5 | 0.0 | 271.1 |
| onepipeline::hooks::run | wait | 112.0 | 473.0 | 45.7 | 112.5 | 501.0 | 44.0 |
| onepipeline::planedit::run | wait | 32.0 | 146.3 | 11.3 | 32.0 | 156.0 | 11.1 |
| onepipeline::stopguard::consult | wait | 78.0 | 177.0 | 13.2 | 78.0 | 178.0 | 12.8 |
| onepipeline::sys::gone_within | sleep | 915.3 | 0.0 | 88.8 | 959.5 | 0.0 | 87.6 |
| onepipeline::vcs::follow | sleep | 23467.7 | 0.0 | 2458.4 | 22537.5 | 0.0 | 2049.7 |
| onevcs::git::bounded | wait | 373858.0 | 769458.3 | 4174.0 | 371596.0 | 758607.5 | 3211.8 |
| onevcs::pool::maintain::run | wait | 34.7 | 600.0 | 26.3 | 32.5 | 589.5 | 25.7 |
| onevcs::probe::read | wait | 359.3 | 723.7 | 4.9 | 353.5 | 716.0 | 3.7 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.3 | 31.5 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2121 e2e tests passed in a before run.
- before inventory-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after adaptive-1: 2120 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed and not passed again: none.
- after adaptive-2: 2120 passed in the tier; of the before runs' passes, not run and passed here: watch::an_explicit_condition_replaces_the_default_set; failed in the tier, passed on the job's re-run: watch::an_explicit_condition_replaces_the_default_set; failed and not passed again: none.
```


## R/Linux required two points complete — source6ff64d15

[Run43775937612, test-linux job133002128807](https://github.com/nickderobertis/onepipeline/actions/runs/43775937612/job/133002128807), GITHUB_SHAbd062baf4539baa3ac21165b20fb0580cd25df72, heade156f19aa0d669eee79490ce7c49096b45ffcef2; workflowdb2bbe081a7b9319eb38bd014e72350b389e8b01. Artifact14191219514, SHA-256d3e80e8a573ec14e49248ed4ec93576f8fe722884759a87a47e2600e3f2df5ec; AMD EPYC7763 64-Core Processor,4logical cores. JobAPI duration152.70000minutes; pre-e2e compilation/earlier tiers105.98660minutes. Main `Summary [2623.374s] 2155 tests run: 2155 passed (23 slow), 1 skipped`. All2,155baseline names passed in main, no recovery or overwritten-profile reconciliation needed. Full37-task selection matches both inventory Linux selections. No Actions-cache save; Nx stored0entries/0bytes/replayed0. Overall job failure remains explicit.

Merged coverage was not produced:00:23:33.1858411Z `the patch of oneagentgraph is not a git source` (original includes backticks);02:10:30.7388161Z `Tasks not run because their dependencies failed or --nx-bail=true:`, followed at02:10:30.7389105Z by `onepipeline:test`. Floor95.74LCOV/95%policy unchanged. Cache/setup action spans, not transfer-only timing:

| Step | Restore observation | Action seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.006 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 42.040 |
| actions/setup-node@v4 | no restore | 0.573 |
| actions/setup-python@v5 | miss | 6.994 |
| astral-sh/setup-uv@v6 | no restore | 3.115 |
| actions/cache/restore@v4 | hit | 0.693 |

R’s two Linux points average40.5724minutes versus three-before40.2337389: +0.3386611minutes. Before spread3.8074667 and after spread6.301 both exceed the difference: **undecided**, no saving. The printed+0.30-minute typical-PR arithmetic is an estimate of the observed difference, not an established cost forecast. Changed-journey CLI launches are reported below as actual recorded means; dynamic polling can vary even when a final duplicate read is removed. No third point is authorized.

Source: the hosted summaries/artifacts and this fold command, run on6ff64d15:

```sh
node --max-old-space-size=12000 scripts/child-waits.mjs compare before:inventory-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-1/test-linux before:inventory-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/1794352-0/runs/baseline-2/test-linux before:base-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736273251/1/test-linux after:relaunch-1=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43736265323/1/test-linux after:relaunch-2=/home/whoop/ai-orchestrator/runs/brief-process-launch-speed-2026-11-14-spikes/scratch/3469976-5/data/43775937612/1/test-linux
```

```text
## 3 before run(s) against 2 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| before | 43736273251/1/132879453312 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 7763 64-Core Processor (4) | 176.69 | 131.14 | 41.73 | 2155/2155 |
| after | 43736265323/1/132879430099 (relaunch-1) | 7b56610e75bdec33e277d44b3e442521f35fe0bb | c22459bfda17d6a6ad10e322ff607e70eb56a68e | Intel(R) Xeon(R) 6975P-C (4) | 115.30 | 75.93 | 37.42 | 2155/2155 |
| after | 43775937612/1/133002128807 (relaunch-2) | bd062baf4539baa3ac21165b20fb0580cd25df72 | e156f19aa0d669eee79490ce7c49096b45ffcef2 | AMD EPYC 7763 64-Core Processor (4) | 152.65 | 105.99 | 43.72 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 40.23 | 37.92–41.73 | 3.81 |
| after | 40.57 | 37.42–43.72 | 6.30 |

Difference, after − before: 0.34 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 0.30 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25243.0 | 0.0 | 2273.8 | 25608.5 | 0.0 | 2254.1 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1727.3 | 0.0 | 34.7 | 1732.0 | 0.0 | 34.8 |
| onepipeline::commandstep::run | wait | 18.0 | 214.0 | 9.9 | 18.0 | 213.5 | 9.9 |
| onepipeline::dispatchenv::run | wait | 97.0 | 313.0 | 11.1 | 97.0 | 314.0 | 11.1 |
| onepipeline::driver::attach | sleep | 38535.3 | 0.0 | 1931.0 | 38123.5 | 0.0 | 1910.2 |
| onepipeline::driver::confirm_driving | sleep | 1439.7 | 0.0 | 72.2 | 1440.5 | 0.0 | 72.2 |
| onepipeline::driver::submit_offered | sleep | 4237.0 | 0.0 | 212.2 | 4225.0 | 0.0 | 211.6 |
| onepipeline::hooks::run | wait | 111.7 | 832.3 | 36.2 | 111.5 | 831.0 | 36.1 |
| onepipeline::planedit::run | wait | 32.0 | 461.3 | 8.7 | 32.0 | 462.0 | 8.7 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.3 | 6.9 | 78.0 | 214.0 | 6.9 |
| onepipeline::sys::gone_within | sleep | 2684.0 | 0.0 | 53.9 | 2661.5 | 0.0 | 53.4 |
| onepipeline::vcs::follow | sleep | 48495.7 | 0.0 | 975.2 | 52359.0 | 0.0 | 1052.8 |
| onevcs::git::bounded | wait | 365183.0 | 879835.0 | 1339.3 | 364926.5 | 882745.5 | 1377.7 |
| onevcs::pool::maintain::run | wait | 35.0 | 2463.7 | 24.2 | 34.5 | 2466.5 | 24.3 |
| onevcs::probe::read | wait | 350.3 | 747.0 | 0.7 | 350.0 | 755.0 | 0.8 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 9.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 30.5 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 2.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 2.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 2.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 5.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 5.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 6.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 9.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 8.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 8.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 4.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 7.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 4.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 3.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after relaunch-1: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after relaunch-2: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
```


## R1/macOS and R2/Windows completed — source b0204329

### relaunch-macos-round1

[Run 43736265323, job 132879430106](https://github.com/nickderobertis/onepipeline/actions/runs/43736265323/job/132879430106), GITHUB_SHA `7b56610e75bdec33e277d44b3e442521f35fe0bb`, head `c22459bfda17d6a6ad10e322ff607e70eb56a68e`, executed workflow `db2bbe081a7b9319eb38bd014e72350b389e8b01`. Profile artifact 14193233490, SHA-256 `4e93d94e1e71c308a68d6cc36c70e7d24629cab201158d42dcf7576f295439f4`. Host Apple M1 (Virtual), 3 logical cores. Job API duration 192.00000 minutes; compile and earlier tiers before e2e 79.85765 minutes; main `Summary [5761.301s] 2121 tests run: 2120 passed (39 slow), 1 timed out, 1 skipped`. Full 39-task Nx selection equals both inventory platform selections. Baseline names missing after own reruns: []; recovered names: ['adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs']. Overall job conclusion `failure` is retained. Cache saves []; Nx stored {'entries': 0, 'bytes': 0, 'replayed': 0}. Cache times below are complete setup/action spans, not transfer-only timings.

| Step | Restore | Seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.061 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 37.410 |
| actions/setup-node@v4 | no restore | 1.298 |
| actions/setup-python@v5 | no restore | 0.220 |
| astral-sh/setup-uv@v6 | no restore | 2.599 |
| actions/cache/restore@v4 | hit | 0.837 |
### relaunch-windows-round2

[Run 43775937612, job 133002128469](https://github.com/nickderobertis/onepipeline/actions/runs/43775937612/job/133002128469), GITHUB_SHA `bd062baf4539baa3ac21165b20fb0580cd25df72`, head `e156f19aa0d669eee79490ce7c49096b45ffcef2`, executed workflow `db2bbe081a7b9319eb38bd014e72350b389e8b01`. Profile artifact 14192569577, SHA-256 `c17900f01c5ee8ea9fd731d3a6249f39ab7a9d25c617da267afacad3f2a6edc1`. Host AMD EPYC 9V74 80-Core Processor, 4 logical cores. Job API duration 180.10000 minutes; compile and earlier tiers before e2e 52.19985 minutes; main `Summary [6861.746s] 1832 tests run: 1830 passed (77 slow), 1 failed, 1 timed out, 1 skipped`. Full 39-task Nx selection equals both inventory platform selections. Baseline names missing after own reruns: []; recovered names: ['adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs', 'store::a_run_launches_from_a_local_markdown_project_and_executes_the_graph_it_holds']. Overall job conclusion `failure` is retained. Cache saves []; Nx stored {'entries': 0, 'bytes': 0, 'replayed': 0}. Cache times below are complete setup/action spans, not transfer-only timings.

| Step | Restore | Seconds |
|---|---|---:|
| op-nx/github-cache/start-cache-server@91839c24885842cac86567 | no restore | 0.017 |
| Swatinem/rust-cache@v2.9.2 | partial (restore key) | 72.276 |
| actions/setup-node@v4 | no restore | 4.057 |
| actions/setup-python@v5 | no restore | 0.160 |
| astral-sh/setup-uv@v6 | no restore | 2.853 |
| actions/cache/restore@v4 | hit | 1.523 |

R1/macOS held-release main TIMEOUT360.043s recovered on its own reruns129.197/129.658/129.530s. The unfinished original profile cannot supply complete aggregate counters; observed counts are not zeros. R1 all2,121 baseline names passed across main and own reruns. The host was M1/3cores, comparable class to the before points.

R2/Windows main held-release timeout recovered144.243/143.775/144.360s. Its store::a_run_launches_from_a_local_markdown_project_and_executes_the_graph_it_holds failed0.372s with dispatch sequence [design,design,build] versus [design,build]; own reruns0.294/0.298/0.330s recovered. This is a recorded failure, not an established prototype regression. Follow-up draft investigates the duplicate dispatch separately. All1,832 baseline names passed including own reruns. Incomplete held-release original counters remain a limitation.

R1 budgets job has no cache restore/save or Nx store step, checkout7b56610e75bdec33e277d44b3e442521f35fe0bb. R1 fully read, final comments/checks captured, #1615 closed after its jobs completed. No Actions-cache or Nx remote entries were written by R1.

Source for the following two-after Windows output: `node --max-old-space-size=12000 scripts/child-waits.mjs compare` with the three Windows before directories and R1/R2 after directories named in the output, run on b0204329. R mean130.48 versus107.58minutes, observed +22.90, undecided inside before45.88-minute spread. Typical-PR arithmetic +20.61 is an estimate of observed difference, not an established forecast.

```text
## 3 before run(s) against 2 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 9V45 96-Core Processor (4) | 144.66 | 57.17 | 87.11 | 1832/1832 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 7763 64-Core Processor (4) | 251.47 | 92.90 | 132.99 | 1832/1832 |
| before | 43736273251/1/132879453337 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 9V74 80-Core Processor (4) | 171.91 | 68.60 | 102.62 | 1830/1832 |
| after | 43736265323/1/132879429855 (relaunch-1) | 7b56610e75bdec33e277d44b3e442521f35fe0bb | c22459bfda17d6a6ad10e322ff607e70eb56a68e | AMD EPYC 7763 64-Core Processor (4) | 241.80 | 74.76 | 146.59 | 1830/1832 |
| after | 43775937612/1/133002128469 (relaunch-2) | bd062baf4539baa3ac21165b20fb0580cd25df72 | e156f19aa0d669eee79490ce7c49096b45ffcef2 | AMD EPYC 9V74 80-Core Processor (4) | 180.06 | 56.01 | 114.36 | 1830/1832 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 107.58 | 87.11–132.99 | 45.88 |
| after | 130.48 | 114.36–146.59 | 32.23 |

Difference, after − before: 22.90 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 20.61 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 24391.7 | 0.0 | 6370.5 | 24309.0 | 0.0 | 7035.1 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 241.3 | 0.0 | 5.0 | 242.5 | 0.0 | 5.1 |
| onepipeline::commandstep::run | wait | 13.0 | 160.0 | 8.2 | 13.0 | 162.5 | 8.5 |
| onepipeline::dispatchenv::run | wait | 81.3 | 309.3 | 12.1 | 81.0 | 320.0 | 12.8 |
| onepipeline::driver::attach | sleep | 165102.7 | 0.0 | 8781.3 | 185058.5 | 0.0 | 9931.0 |
| onepipeline::driver::confirm_driving | sleep | 1333.0 | 0.0 | 69.2 | 1378.0 | 0.0 | 72.1 |
| onepipeline::driver::submit_offered | sleep | 5189.7 | 0.0 | 268.2 | 5348.5 | 0.0 | 277.9 |
| onepipeline::hooks::run | wait | 65.0 | 837.3 | 39.9 | 65.0 | 863.5 | 41.3 |
| onepipeline::planedit::run | wait | 30.0 | 611.0 | 12.2 | 30.0 | 646.5 | 13.4 |
| onepipeline::sys::gone_within | sleep | 55.0 | 0.0 | 1.2 | 41.5 | 0.0 | 0.9 |
| onepipeline::vcs::follow | sleep | 231658.7 | 0.0 | 5469.4 | 255080.5 | 0.0 | 6103.1 |
| onevcs::git::PipeRead::await_readable | sleep | 2025139.3 | 0.0 | 23516.9 | 2267215.5 | 0.0 | 26669.5 |
| onevcs::git::bounded | wait | 382513.3 | 1604084.0 | 17574.7 | 382410.0 | 1781873.0 | 20432.9 |
| onevcs::pool::maintain::run | wait | 19.0 | 1614.7 | 24.8 | 19.0 | 1618.5 | 24.9 |
| onevcs::probe::read | wait | 379.0 | 966.7 | 12.2 | 353.5 | 950.0 | 13.6 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 14.3 | 17.5 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 34.3 | 33.5 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 2.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 2.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 4.0 | 2.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 5.5 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 5.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 6.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 9.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 8.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 8.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 7.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 4.0 |

### Tests

1832 e2e tests passed in a before run.
- before inventory-1: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 1830 passed in the tier; failed in the tier, passed on the job's re-run: boundary::an_unusable_attempt_budget_falls_back_rather_than_disabling_the_recovery, store::a_project_larger_than_one_page_is_read_to_its_end; failed and not passed again: none.
- after relaunch-1: 1830 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs, check_visibility::the_check_visibility_workload_reads_at_its_cadence_and_records_what_it_spent; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs, check_visibility::the_check_visibility_workload_reads_at_its_cadence_and_records_what_it_spent; failed and not passed again: none.
- after relaunch-2: 1830 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs, store::a_run_launches_from_a_local_markdown_project_and_executes_the_graph_it_holds; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs, store::a_run_launches_from_a_local_markdown_project_and_executes_the_graph_it_holds; failed and not passed again: none.

```
