## 1 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | off | 0000000 | 1111111 | AMD Ryzen Threadripper 1920X 12-Core Processor (20) | 0.08 | 0.02 | 0.07 | 2/2 |
| after | on | 0000000 | 1111111 | AMD Ryzen Threadripper 1920X 12-Core Processor (20) | 0.07 | 0.01 | 0.06 | 2/2 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 0.07 | 0.07–0.07 | 0.00 |
| after | 0.06 | 0.06–0.06 | 0.00 |

Difference, after − before: -0.01 min — decided: non-overlapping ranges and mean difference outside both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -0.01 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 6.0 | 0.0 | 0.5 | 6.0 | 0.0 | 0.5 |
| onepipeline::commandstep::run | wait | 3.0 | 6.0 | 0.2 | 3.0 | 6.0 | 0.0 |
| onepipeline::dispatchenv::run | wait | 2.0 | 4.0 | 0.1 | 2.0 | 4.0 | 0.0 |
| onepipeline::driver::attach | sleep | 12.0 | 0.0 | 0.6 | 35.0 | 0.0 | 0.6 |
| onepipeline::driver::confirm_driving | sleep | 2.0 | 0.0 | 0.1 | 5.0 | 0.0 | 0.1 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 2.0 |

### Tests

2 e2e tests passed in a before run.
- before off: 2 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after on: 2 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
