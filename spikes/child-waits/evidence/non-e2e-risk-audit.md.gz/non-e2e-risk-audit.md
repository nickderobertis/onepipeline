## Non-e2e execution limitations — rulings a88/a89

Ruling from the manager a88: “No: the by-name proof covers the e2e tier only, as ruled for the siblings. For other tiers, matching per-tier counts and an unchanged selection are enough; keep the report's explicit statement of that scope.”

Ruling a89: “Yes, report them as explicit non-e2e execution limitations; do not assert matching counts where they don't match.” Its bounded additional check asked about the four note timeouts, the root failure, overlap with R's changed paths, and whether baselines showed the same timeouts. The retained logs and unchanged source answer it below; no new hosted run or producer repair was made.

Every completed platform's full Nx selection matches both inventory baseline selections. Non-e2e executed counts do **not** universally match; no equivalence or whole-job-green claim is made for them. Full chronological nextest summary/count records for each side are in spikes/child-waits/evidence/non-e2e-tier-audit.json.gz, with original timestamps, nextest ids, source log paths and preceding Nx context. The preceding context is a log locator, not a guarantee that parallel output assigns each line to that context. Main e2e records are included for cross-checking, and distinguished by the main ids quoted elsewhere.

Concrete R2/Linux differences, run43775937612/job133002128807:
- Summary [360.021s] 4/75 tests run: 0 passed, 4 timed out, 41 skipped; the log explicitly says71/75 were not run due to test failure.
- Root Summary [181.145s] 1373/1443 tests run: 1372 passed, 1 failed, 1 skipped;70/1443 not run.
- Own selected reruns recovered six named failures/timeouts; the patch-pin failure remained. Reruns did not fill the unrun tests, so those counts cannot be called matching. This does not change main e2e2155/2155 passing evidence.

The four note timeouts were:
1. a_cancel_refuses_the_note_offered_to_its_node_and_the_one_queued_behind_it,360.008s.
2. a_cancel_preempts_the_unanswered_note_to_its_node_and_what_waits_behind_it,360.010s.
3. a_cancel_beside_a_live_note_is_applied_as_its_envelope_is_handed,360.011s.
4. a_binding_note_enters_the_bar_its_judge_decides_against_as_the_workers_own,360.018s.

All four also timed out in inventory run43684231509 attempt2/Linux job132799383400 at2026-11-15T12:21:16Z: respectively360.015/360.011/360.010/360.015s. They recovered on that baseline job's own three reruns. The baseline is therefore not clean of these timeouts. Inventory attempt1 and the extra base do not show these four timeouts. Exact original outcome lines are retained in the audit JSON.

Source inspection on0df9705e: git diff13eb521a over tests/note/main.rs and tests/patch_pin.rs is empty. The four bodies live at tests/note/main.rs1599/1838/2078/4073 and share ../e2e/harness.rs. There is no call in that module to until_read, spike_variant::relaunch, or the R results/outcomes reuse helpers. The shared initializer selects the experiment, but R alone leaves spike_variant::pause at its old interval; product waits select Exit or Adaptive, neither enabled by R. A search for Variant::Relaunch, spike_variant::relaunch and until_read in src, tests/note and vendor/onevcs/src finds only the selector's enum parsing, not an active R runtime path. These four journeys still launch children, but do not exercise R's changed re-launch/read-reuse path. No R-specific timeout regression is established by this record.

The root failure is patch_pin::every_patched_member_of_one_repository_comes_from_one_revision: the vendored oneagentgraph patch is not a git source. That checks the measurement manifest, not a child wait or journey read-reuse path; it is also present in the approved baselines. This is the known coverage/merge prerequisite refusal, not a new R failure.

This is one bounded log/source check under a89. It does not establish the general cause of the timeouts, and it does not erase the reduced non-e2e execution evidence.
