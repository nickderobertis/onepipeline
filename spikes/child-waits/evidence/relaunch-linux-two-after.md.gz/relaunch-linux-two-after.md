## 3 before run(s) against 2 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Intel(R) Xeon(R) 6975P-C (4) | 136.22 | 96.31 | 37.92 | 2155/2155 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | INTEL(R) XEON(R) PLATINUM 8573C (4) | 171.41 | 125.93 | 41.06 | 2155/2155 |
| before | 43736273251/1/132879453312 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 7763 64-Core Processor (4) | 176.69 | 131.14 | 41.73 | 2155/2155 |
| after | 43736265323/1/132879430099 (relaunch-1) | 7b56610e75bdec33e277d44b3e442521f35fe0bb | c22459bfda17d6a6ad10e322ff607e70eb56a68e | Intel(R) Xeon(R) 6975P-C (4) | 115.30 | 75.93 | 37.42 | 2155/2155 |
| after | 43775937612/1/133002128807 (relaunch-2) | bd062baf4539baa3ac21165b20fb0580cd25df72 | e156f19aa0d669eee79490ce7c49096b45ffcef2 | AMD EPYC 7763 64-Core Processor (4) | 152.65 | 105.99 | 43.72 | 2155/2155 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 40.23 | 37.92–41.73 | 3.81 |
| after | 40.57 | 37.42–43.72 | 6.30 |

Difference, after − before: 0.34 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 0.30 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25243.0 | 0.0 | 2273.8 | 25608.5 | 0.0 | 2254.1 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 1727.3 | 0.0 | 34.7 | 1732.0 | 0.0 | 34.8 |
| onepipeline::commandstep::run | wait | 18.0 | 214.0 | 9.9 | 18.0 | 213.5 | 9.9 |
| onepipeline::dispatchenv::run | wait | 97.0 | 313.0 | 11.1 | 97.0 | 314.0 | 11.1 |
| onepipeline::driver::attach | sleep | 38535.3 | 0.0 | 1931.0 | 38123.5 | 0.0 | 1910.2 |
| onepipeline::driver::confirm_driving | sleep | 1439.7 | 0.0 | 72.2 | 1440.5 | 0.0 | 72.2 |
| onepipeline::driver::submit_offered | sleep | 4237.0 | 0.0 | 212.2 | 4225.0 | 0.0 | 211.6 |
| onepipeline::hooks::run | wait | 111.7 | 832.3 | 36.2 | 111.5 | 831.0 | 36.1 |
| onepipeline::planedit::run | wait | 32.0 | 461.3 | 8.7 | 32.0 | 462.0 | 8.7 |
| onepipeline::stopguard::consult | wait | 78.0 | 214.3 | 6.9 | 78.0 | 214.0 | 6.9 |
| onepipeline::sys::gone_within | sleep | 2684.0 | 0.0 | 53.9 | 2661.5 | 0.0 | 53.4 |
| onepipeline::vcs::follow | sleep | 48495.7 | 0.0 | 975.2 | 52359.0 | 0.0 | 1052.8 |
| onevcs::git::bounded | wait | 365183.0 | 879835.0 | 1339.3 | 364926.5 | 882745.5 | 1377.7 |
| onevcs::pool::maintain::run | wait | 35.0 | 2463.7 | 24.2 | 34.5 | 2466.5 | 24.3 |
| onevcs::probe::read | wait | 350.3 | 747.0 | 0.7 | 350.0 | 755.0 | 0.8 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 9.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.0 | 30.5 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 2.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 2.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 2.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 5.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 5.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 6.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 9.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 8.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 8.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 4.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 7.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 4.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 3.0 |

### Tests

2154 e2e tests passed in a before run.
- before inventory-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2154 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after relaunch-1: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after relaunch-2: 2155 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
