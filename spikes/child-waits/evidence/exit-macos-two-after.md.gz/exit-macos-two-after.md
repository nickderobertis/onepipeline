## 3 before run(s) against 2 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 201.81 | 92.98 | 90.11 | 2121/2121 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 198.48 | 85.46 | 94.38 | 2121/2121 |
| before | 43736273251/1/132879453345 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | Apple M1 (Virtual) (3) | 156.54 | 55.82 | 82.26 | 2121/2121 |
| after | 43736250019/1/132879382738 (exit-1) | 8a18672992559a9088d2527a71de265522e7f84f | 9ba119ba96fa4544cea8889a2c809e9d01e65a84 | Apple M2 Pro (Virtual) (5) | 90.76 | 24.04 | 59.61 | 2120/2121 |
| after | 43765240430/1/132968741529 (exit-2) | 82b1540c1a151fbdb249216b6e5c38be9b5b0fa4 | 76e124ef58e4d67fef8db8657478eae38fffedbb | Apple M2 Pro (Virtual) (5) | 92.76 | 24.86 | 61.53 | 2121/2121 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 88.92 | 82.26–94.38 | 12.11 |
| after | 60.57 | 59.61–61.53 | 1.92 |

Difference, after − before: -28.35 min — decided: non-overlapping ranges and mean difference outside both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -25.52 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25419.7 | 0.0 | 5511.8 | 26018.0 | 0.0 | 4854.6 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 368.7 | 0.0 | 37.0 | 623.5 | 0.0 | 36.1 |
| onepipeline::commandstep::run | wait | 18.0 | 106.7 | 11.9 | 18.0 | 210.5 | 10.1 |
| onepipeline::dispatchenv::run | wait | 97.0 | 663.0 | 73.4 | 97.0 | 1030.0 | 46.5 |
| onepipeline::driver::attach | sleep | 27717.0 | 0.0 | 3681.1 | 25276.0 | 0.0 | 2882.4 |
| onepipeline::driver::confirm_driving | sleep | 1399.0 | 0.0 | 183.2 | 1371.5 | 0.0 | 156.5 |
| onepipeline::driver::submit_offered | sleep | 2134.0 | 0.0 | 275.1 | 2210.0 | 0.0 | 259.7 |
| onepipeline::hooks::run | wait | 112.0 | 473.0 | 45.7 | 114.0 | 819.5 | 32.2 |
| onepipeline::planedit::run | wait | 32.0 | 146.3 | 11.3 | 32.0 | 423.0 | 8.5 |
| onepipeline::stopguard::consult | wait | 78.0 | 177.0 | 13.2 | 78.0 | 214.0 | 4.1 |
| onepipeline::sys::gone_within | sleep | 915.3 | 0.0 | 88.8 | 3858243.5 | 0.0 | 42.6 |
| onepipeline::vcs::follow | sleep | 23467.7 | 0.0 | 2458.4 | 21175.5 | 0.0 | 1777.3 |
| onevcs::git::bounded | wait | 373858.0 | 769458.3 | 4174.0 | 369741.5 | 825609.5 | 2292.0 |
| onevcs::pool::maintain::run | wait | 34.7 | 600.0 | 26.3 | 34.5 | 1877.0 | 25.6 |
| onevcs::probe::read | wait | 359.3 | 723.7 | 4.9 | 357.0 | 716.5 | 1.9 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.3 | 31.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 5.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 5.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 4.0 |

### Tests

2121 e2e tests passed in a before run.
- before inventory-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after exit-1: 2120 passed in the tier; of the before runs' passes, not run and passed here: unwatched::a_host_sized_runs_root_is_answered_in_well_under_a_second_whatever_its_journals_hold; failed in the tier, passed on the job's re-run: unwatched::a_host_sized_runs_root_is_answered_in_well_under_a_second_whatever_its_journals_hold; failed and not passed again: none.
- after exit-2: 2121 passed in the tier; of the before runs' passes, not run and passed here: none; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
