## 3 before run(s) against 2 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 201.81 | 92.98 | 90.11 | 2121/2121 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | Apple M1 (Virtual) (3) | 198.48 | 85.46 | 94.38 | 2121/2121 |
| before | 43736273251/1/132879453345 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | Apple M1 (Virtual) (3) | 156.54 | 55.82 | 82.26 | 2121/2121 |
| after | 43736265323/1/132879430106 (relaunch-1) | 7b56610e75bdec33e277d44b3e442521f35fe0bb | c22459bfda17d6a6ad10e322ff607e70eb56a68e | Apple M1 (Virtual) (3) | 191.99 | 82.72 | 96.02 | 2120/2121 |
| after | 43775937612/1/133002128779 (relaunch-2) | bd062baf4539baa3ac21165b20fb0580cd25df72 | e156f19aa0d669eee79490ce7c49096b45ffcef2 | Apple M1 (Virtual) (3) | 186.07 | 70.43 | 100.95 | 2119/2121 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 88.92 | 82.26–94.38 | 12.11 |
| after | 98.49 | 96.02–100.95 | 4.93 |

Difference, after − before: 9.57 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): 8.61 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 25419.7 | 0.0 | 5511.8 | 22349.5 | 0.0 | 5432.6 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 368.7 | 0.0 | 37.0 | 380.5 | 0.0 | 37.1 |
| onepipeline::commandstep::run | wait | 18.0 | 106.7 | 11.9 | 18.0 | 110.5 | 12.2 |
| onepipeline::dispatchenv::run | wait | 97.0 | 663.0 | 73.4 | 97.0 | 688.5 | 75.7 |
| onepipeline::driver::attach | sleep | 27717.0 | 0.0 | 3681.1 | 28706.0 | 0.0 | 3813.4 |
| onepipeline::driver::confirm_driving | sleep | 1399.0 | 0.0 | 183.2 | 1386.5 | 0.0 | 181.7 |
| onepipeline::driver::submit_offered | sleep | 2134.0 | 0.0 | 275.1 | 2113.5 | 0.0 | 276.1 |
| onepipeline::hooks::run | wait | 112.0 | 473.0 | 45.7 | 112.0 | 472.5 | 45.8 |
| onepipeline::planedit::run | wait | 32.0 | 146.3 | 11.3 | 32.0 | 149.5 | 11.3 |
| onepipeline::stopguard::consult | wait | 78.0 | 177.0 | 13.2 | 78.0 | 181.0 | 13.7 |
| onepipeline::sys::gone_within | sleep | 915.3 | 0.0 | 88.8 | 914.5 | 0.0 | 89.4 |
| onepipeline::vcs::follow | sleep | 23467.7 | 0.0 | 2458.4 | 24527.0 | 0.0 | 2553.7 |
| onevcs::git::bounded | wait | 373858.0 | 769458.3 | 4174.0 | 372609.5 | 766105.0 | 4212.5 |
| onevcs::pool::maintain::run | wait | 34.7 | 600.0 | 26.3 | 34.0 | 582.0 | 26.4 |
| onevcs::probe::read | wait | 359.3 | 723.7 | 4.9 | 349.0 | 702.5 | 4.3 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 12.0 | 9.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 7.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 31.3 | 30.5 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 2.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 2.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 5.0 | 2.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 5.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 5.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 6.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 9.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 8.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 8.0 |
| shipped::status_says_an_adopter_that_died_recorded_no_exit | 5.0 | 4.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 7.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 4.0 |
| views::a_run_with_work_a_fresh_driver_could_schedule_is_still_told_to_adopt | 4.0 | 3.0 |

### Tests

2121 e2e tests passed in a before run.
- before inventory-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before base-1: 2121 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after relaunch-1: 2120 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs; failed and not passed again: none.
- after relaunch-2: 2119 passed in the tier; of the before runs' passes, not run and passed here: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs, listing::a_host_sized_runs_root_lists_in_seconds_and_ten_times_the_journal_bytes_barely_moves_it; failed in the tier, passed on the job's re-run: adoption::a_held_release_is_asked_about_on_its_own_interval_however_fast_the_loop_runs, listing::a_host_sized_runs_root_lists_in_seconds_and_ten_times_the_journal_bytes_barely_moves_it; failed and not passed again: none.
