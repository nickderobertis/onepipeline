## 2 before run(s) against 1 after run(s)

### Runs

| side | run | GITHUB_SHA | head | processor (logical cores) | job log span min | pre-e2e min (compile, earlier tiers) | e2e nextest min | e2e passed/ran |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before | inventory-1 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 9V45 96-Core Processor (4) | 144.66 | 57.17 | 87.11 | 1832/1832 |
| before | inventory-2 | 37341b0a | 36237191db78133b709b3d893ccc11d91d2a5272 | AMD EPYC 7763 64-Core Processor (4) | 251.47 | 92.90 | 132.99 | 1832/1832 |
| after | 43736273251/1/132879453337 (base-1) | d1dcc5b7e02605051eebf05709688acf4e45f064 | 6a287ec218ffaf803d6f4b47b13fc327fb2d02a1 | AMD EPYC 9V74 80-Core Processor (4) | 171.91 | 68.60 | 102.62 | 1830/1832 |

### E2e tier minutes

| side | mean | range | spread |
| --- | ---: | ---: | ---: |
| before | 110.05 | 87.11–132.99 | 45.88 |
| after | 102.62 | 102.62–102.62 | 0.00 |

Difference, after − before: -7.43 min — undecided: ranges overlap or the mean difference does not exceed both spreads.
Typical pull request (estimate, the difference × 0.900 of pull requests reaching src/): -6.69 min.

### Waits at the changed sites, mean per e2e tier

| function | kind | before count | before polls | before s | after count | after polls | after s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| harness::waited_on | poll | 24414.5 | 0.0 | 6603.0 | 24346.0 | 0.0 | 5905.4 |
| onepipeline::agentgraph::GraphRun::stop | sleep | 240.5 | 0.0 | 5.0 | 243.0 | 0.0 | 5.0 |
| onepipeline::commandstep::run | wait | 13.0 | 163.0 | 8.3 | 13.0 | 154.0 | 8.1 |
| onepipeline::dispatchenv::run | wait | 81.0 | 313.0 | 12.3 | 82.0 | 302.0 | 11.6 |
| onepipeline::driver::attach | sleep | 168609.0 | 0.0 | 9003.1 | 158090.0 | 0.0 | 8337.8 |
| onepipeline::driver::confirm_driving | sleep | 1346.5 | 0.0 | 70.0 | 1306.0 | 0.0 | 67.6 |
| onepipeline::driver::submit_offered | sleep | 5267.5 | 0.0 | 273.3 | 5034.0 | 0.0 | 258.0 |
| onepipeline::hooks::run | wait | 65.0 | 834.0 | 39.7 | 65.0 | 844.0 | 40.2 |
| onepipeline::planedit::run | wait | 30.0 | 620.0 | 12.4 | 30.0 | 593.0 | 11.7 |
| onepipeline::sys::gone_within | sleep | 54.5 | 0.0 | 1.1 | 56.0 | 0.0 | 1.2 |
| onepipeline::vcs::follow | sleep | 232763.0 | 0.0 | 5559.8 | 229450.0 | 0.0 | 5288.5 |
| onevcs::git::PipeRead::await_readable | sleep | 2081824.5 | 0.0 | 24334.2 | 1911769.0 | 0.0 | 21882.4 |
| onevcs::git::bounded | wait | 383607.5 | 1649484.5 | 18341.0 | 380325.0 | 1513283.0 | 16042.0 |
| onevcs::pool::maintain::run | wait | 19.0 | 1613.5 | 24.8 | 19.0 | 1617.0 | 24.8 |
| onevcs::probe::read | wait | 379.0 | 1000.0 | 13.1 | 379.0 | 900.0 | 10.3 |

### CLI launches per changed journey, mean per recorded run (test-profile records)

| journey | before | after |
| --- | ---: | ---: |
| adoption::a_fast_local_direct_node_is_held_unlanded_until_its_release_and_then_lands_once | 15.5 | 12.0 |
| adoption::a_node_settled_at_a_change_request_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption::a_node_settled_at_a_squash_merge_commit_reads_landed_in_every_surface | 8.0 | 8.0 |
| adoption_check::every_live_edit_onevcs_says_can_never_complete_is_refused_whole_and_applied_repaired | 34.5 | 34.0 |
| command_step::a_command_exiting_non_zero_fails_with_its_status_and_stderr_and_holds_its_dependents | 4.0 | 4.0 |
| command_step::a_command_past_its_timeout_is_stopped_and_one_with_none_runs_to_its_end | 3.0 | 3.0 |
| command_step::a_command_that_cannot_start_says_too_much_or_is_signalled_settles_command_failed | 4.0 | 4.0 |
| command_step::a_schema_13_launch_and_a_plan_naming_none_of_the_primitives_run_as_before | 7.0 | 7.0 |
| landing::the_counting_views_report_what_a_read_taken_now_says | 6.0 | 6.0 |
| live_edit::a_run_wide_set_edit_is_replayed_when_a_driver_adopts | 7.0 | 7.0 |
| readjust::deferred_republications_are_read_by_the_next_trigger_green_or_repaired_red | 10.0 | 10.0 |
| readjust::every_deferred_verdict_word_is_recorded_and_only_pending_stays_outstanding | 10.0 | 10.0 |
| shipped::status_on_an_adopted_run_describes_the_driver_driving_it_now | 9.0 | 9.0 |
| unwatched::concurrent_watches_are_recorded_apart_and_hold_the_run_watched_until_the_last_returns | 8.0 | 8.0 |
| views::a_run_whose_unfinished_work_is_parked_reads_ended_unfinished_and_is_given_no_advice | 5.0 | 5.0 |

### Tests

1832 e2e tests passed in a before run.
- before inventory-1: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- before inventory-2: 1832 passed in the tier; failed in the tier, passed on the job's re-run: none; failed and not passed again: none.
- after base-1: 1830 passed in the tier; of the before runs' passes, not run and passed here: boundary::an_unusable_attempt_budget_falls_back_rather_than_disabling_the_recovery, store::a_project_larger_than_one_page_is_read_to_its_end; failed in the tier, passed on the job's re-run: boundary::an_unusable_attempt_budget_falls_back_rather_than_disabling_the_recovery, store::a_project_larger_than_one_page_is_read_to_its_end; failed and not passed again: none.
